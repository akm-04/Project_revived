# Pass78 Index

Machine-first: see 00_PASSMAP/MACHINE_BOOTSTRAP_PASS78.json.
