# Pass74.0 Index

- Current status: `00_PASSMAP/STATUS.json`
- Live checkpoint: `00_PASSMAP/PASS74_LIVE_CHECKPOINT.json`
- Pass73 runtime characterization: `00_PASSMAP/PASS73_RUNTIME_CHARACTERIZATION_20260822.json`
- Primary technical report: `00_PASSMAP/PHASE3_AWAKENING_MISSION_OWNERSHIP_PASS74.md`
- Implementation facts: `00_PASSMAP/PASS74_IMPLEMENTATION_FACTS.json`
- Source feedback: `00_PASSMAP/PASS74_SRC64_FEEDBACK_LOOP.json`
- Regression matrix: `00_PASSMAP/PASS74_REGRESSION_MATRIX.json`
- Focused self-test: `00_PASSMAP/PASS74_AWAKENING_SELFTEST.json`
- Backend delta manifest: `00_PASSMAP/PASS74_BACKEND_FILE_MANIFEST.json`
- Client test plan: `00_PASSMAP/PASS74_CLIENT_TEST_PLAN.md`
- Negative memory: `00_PASSMAP/CURRENT_NEGATIVE_MEMORY_PASS74.json`
- Machine memory: `00_PASSMAP/databases/GAME_KNOWLEDGE_CATALOG_PASS74.sqlite`
- Next-chat handoff: `00_PASSMAP/NEXT_CHAT_CONTEXT_PASS74.txt`

Backend authority: `gxb-backend-v0.9.6-pass74.0.zip` / `79d545d01db3ec8a11929e57b2d06fadb955d7993c68b29b639f6114188c75dd`.
