# Pass72.0 Index

Start at `00_PASSMAP/READ_FIRST.md`. Current machine database: `00_PASSMAP/databases/GAME_KNOWLEDGE_CATALOG_PASS72.sqlite`. Runtime gate: `00_PASSMAP/PASS72_CLIENT_TEST_PLAN.md`.
