# PASS65 INDEX

Status: FINAL canonical. Phase2 planning only; backend unchanged.

Primary: `00_PASSMAP/CORE_STATE_ECONOMY_CONTRACT_FREEZE_PASS65.md`
Registry: `00_PASSMAP/RESOURCE_REGISTRY_SCHEMA_PASS65.json`
Mutation/UoW: `00_PASSMAP/MUTATION_CONTRACT_SCHEMA_PASS65.json`, `00_PASSMAP/UNIT_OF_WORK_CONTRACT_PASS65.json`
Projection: `00_PASSMAP/RESPONSE_PROJECTOR_CONTRACT_PASS65.json`
Gates: `00_PASSMAP/CORE_STATE_CHARACTERIZATION_GATES_PASS65.json`
Master DB: `00_PASSMAP/databases/GAME_KNOWLEDGE_CATALOG_PASS65.sqlite`

Next recommended: Pass66 persistence/state-slice schema migration contract, no implementation.
