Pass76 = research/self-healing only. Backend unchanged Pass75. Machine startup: `00_PASSMAP/MACHINE_BOOTSTRAP_PASS76.json`; DB: `00_PASSMAP/databases/GAME_KNOWLEDGE_CATALOG_PASS76.sqlite`.
