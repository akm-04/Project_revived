# Pass 92.1 Index

Migration-only checkpoint; backend unchanged from Pass92.0.

Start here:
- `00_PASSMAP/READ_FIRST.md`
- `00_PASSMAP/MACHINE_BOOTSTRAP_PASS92_1.json`
- `00_PASSMAP/PASS92_1_LIVE_CHECKPOINT.json`
- `00_PASSMAP/PASS92_1_MIGRATION_HANDOFF.md`
- `00_PASSMAP/NEXT_CHAT_CONTEXT_PASS92_1.txt`
- `00_PASSMAP/NEW_CHAT_STARTUP_PROMPT_PASS92_1.txt`
- `00_PASSMAP/databases/GAME_KNOWLEDGE_CATALOG_PASS92_1.sqlite`

Implementation authority remains Pass92 MID116 in `gxb-backend-v0.11.1-pass92.0.zip`. Runtime smoke is pending.
