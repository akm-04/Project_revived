# Pass71.0 Index

Current state: **STATIC_ACCEPTED_RUNTIME_PENDING**. Pass70.1 is **RUNTIME_ACCEPTED**.

- `00_PASSMAP/READ_FIRST.md` — canonical startup.
- `00_PASSMAP/PASS70_1_RUNTIME_ACCEPTANCE_20260822.json` — accepted client smoke and MID59 exact Mana evidence.
- `00_PASSMAP/PHASE3_TEMPORAL_RESOURCES_PASS71.md` — implementation/architecture report.
- `00_PASSMAP/PASS71_IMPLEMENTATION_FACTS.json` — machine-readable Pass71 facts.
- `00_PASSMAP/PASS71_SRC64_FEEDBACK_LOOP.json` — effective-source feedback loop.
- `00_PASSMAP/PASS71_REGRESSION_MATRIX.json` — required static gates.
- `00_PASSMAP/PASS71_CLIENT_TEST_PLAN.md` — next runtime acceptance gate.
- `00_PASSMAP/PASS71_LIVE_CHECKPOINT.json` — resumable current state.
- `00_PASSMAP/CURRENT_NEGATIVE_MEMORY_PASS71.json` — anti-overclaim/deferred-bug shield.
- `00_PASSMAP/databases/GAME_KNOWLEDGE_CATALOG_PASS71.sqlite` — current machine-first memory, 197 non-system tables.

Backend: `gxb-backend-v0.9.3-pass71.0.zip` SHA-256 `fd52add4f136c07ccb898d9616a5c7d9bba58ee89b67163aab2e4acdeb261262`.

Roadmap after a clean Pass71 smoke: **Hero/Girls Progression + Gear/state preservation**, including the deferred MID52 Hero Evolve Mana migration; dependent gameplay features remain deferred.
