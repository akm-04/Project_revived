# Pass75 Index — Campaign Ownership Foundation

- `00_PASSMAP/READ_FIRST.md` — current startup authority.
- `00_PASSMAP/PASS75_LIVE_CHECKPOINT.json` — current implementation/runtime gate.
- `00_PASSMAP/PHASE3_CAMPAIGN_OWNERSHIP_PASS75.md` — technical design/changelog.
- `00_PASSMAP/PASS75_IMPLEMENTATION_FACTS.json` — machine-readable implementation facts.
- `00_PASSMAP/PASS74_RUNTIME_CHARACTERIZATION_20260822.json` — supplied smoke triage.
- `00_PASSMAP/PASS75_SRC64_FEEDBACK_LOOP.json` — effective-source reality check.
- `00_PASSMAP/PASS75_REGRESSION_MATRIX.json` — static + exact packaged-byte gates.
- `00_PASSMAP/PASS75_CAMPAIGN_OWNERSHIP_SELFTEST.json` — focused characterization.
- `00_PASSMAP/PASS75_CLIENT_TEST_PLAN.md` — next client smoke plan.
- `00_PASSMAP/CURRENT_NEGATIVE_MEMORY_PASS75.json` — rules that must not regress.
- `00_PASSMAP/databases/GAME_KNOWLEDGE_CATALOG_PASS75.sqlite` — 245-table machine memory.
