# Pass63 Index — Phase 2 Architecture Proposal & Readiness Audit

- `00_PASSMAP/BACKEND_ARCHITECTURE_PROPOSAL_PASS63.md` — high-level modular backend proposal.
- `00_PASSMAP/BACKEND_ARCHITECTURE_READINESS.md` — required five-category system readiness audit.
- `00_PASSMAP/BACKEND_SHARED_PRIMITIVES_PASS63.json` — machine-readable shared components.
- `00_PASSMAP/BACKEND_DOMAIN_ATTACHMENTS_PASS63.json` — domain-to-core attachment map.
- `00_PASSMAP/ARCHITECTURE_DECISION_LOG_PASS63.json` — accepted baseline decisions and hard constraints.
- `00_PASSMAP/BACKEND_DEPENDENCY_RULES_PASS63.json` — one-way dependency guardrails.
- `00_PASSMAP/BACKEND_ARCHITECTURE_RISKS_PASS63.json` — architecture failure modes.
- `00_PASSMAP/PHASE2_WORKPLAN_PASS63.json` — remaining planning sequence.
- `00_PASSMAP/databases/GAME_KNOWLEDGE_CATALOG_PASS63.sqlite` — 113-table machine-first knowledge/architecture catalog.

Backend code is unchanged.
