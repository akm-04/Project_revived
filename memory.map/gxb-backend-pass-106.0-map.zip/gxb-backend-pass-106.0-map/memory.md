# PASS106 MACHINE POINTER
START `00_PASSMAP/READ_FIRST.md`. Backend unchanged. RNG backbone next; use existing UoW receipts; MID50 standard Summon, MID305 Super-Hero; Campaign repeat moved ahead of unique-instance/Girls.
