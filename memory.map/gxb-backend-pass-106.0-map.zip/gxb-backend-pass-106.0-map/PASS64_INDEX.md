# Pass64 Index — Phase 2 Backend Migration Reality Audit

- `00_PASSMAP/BACKEND_MIGRATION_REALITY_AUDIT_PASS64.md` — current backend audit and migration verdict.
- `00_PASSMAP/ECONOMY_FOUNDATION_MIGRATION_PLAN_PASS64.md` — economy/inventory/gear-first strangler sequence.
- `00_PASSMAP/BACKEND_MIGRATION_INTERFACE_CONTRACTS_PASS64.md` — frozen planning responsibilities/persistence rules.
- `00_PASSMAP/BACKEND_MODULE_CLASSIFICATION_PASS64.json` — 45 module/system groups classified RETAIN/WRAP/REFACTOR/REPLACE/DEFER.
- `00_PASSMAP/PERSISTENCE_OWNERSHIP_MAP_PASS64.json` — current PlayerState slices -> target canonical owners.
- `00_PASSMAP/PHASE2_MIGRATION_INDEX_PASS64.json` — machine navigation.
- `00_PASSMAP/databases/GAME_KNOWLEDGE_CATALOG_PASS64.sqlite` — 119-table evidence + architecture/migration catalog.

Backend code is unchanged.
