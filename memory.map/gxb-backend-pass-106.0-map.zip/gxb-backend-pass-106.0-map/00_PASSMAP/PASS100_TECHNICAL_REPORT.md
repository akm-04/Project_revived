# Pass100.0 Technical Report — MID97 OTA Bridge and Exactly-Once Energy Purchase

Pass99 is **RUNTIME ACCEPTED** from the supplied `debug.zip` (SHA-256 `29b1295c0d5cee4daf4fba9b7afa4583c0d488cf91f446724e314a8625b4b443`). QA inventory, deterministic Energy consumables, direct Magic Liquid settlement, MID117 1x/10x Energy+Raid Ticket debit, and cold-restart persistence were observed. The stamina `+` failure is the expected Pass99 MID97 fail-closed gap.

Pass100 closes MID97 with a minimal OTA preservation bridge derived from effective `src_64`. `AddEnergy.lua` is the single request constructor; the patch adds `expected_buy_energy_times`, the canonical 05:00 GMT+8 `energy_day_id`, and `energy_op_id = p100-energy-{day}-{expected}-{xyd.generateUUID()}`. `Backend.lua` retries the same params table, so automatic retries retain the exact UUID while a later intentional click receives a fresh UUID.

`EnergyPurchaseService` validates the patched identity, source day, expected ordinal, VIP/Monthly allowance, Energy pre-purchase threshold and source ordinal cost. One `PlayerUnitOfWork` commits Crystal debit via `EconomyLedger`, +120 Energy via `TemporalPolicyService`, `buy_energy_times + 1`, and a durable receipt. Receipt replay is checked before day/counter guards and is read-only, so a lost-response retry cannot double-charge even if it arrives after a reset boundary.

Cumulative OTA advances to **1.631.4**. All 126 prior Pass99 overrides remain byte-identical and only the two AddEnergy overrides are added. Backend and OTA source generators reproduce byte-for-byte from canonical assets.

Validation: compileall, Pass100 focused exactly-once tests, historical regression spine through Pass99, cumulative OTA preservation, ZIP integrity, and clean fresh-extraction boundary tests all pass. Pass100 remains **CLIENT RUNTIME PENDING** until OTA 1.631.4 and MID97 are smoked on the real client.
