# Pass99 Index

- `00_PASSMAP/PASS99_TECHNICAL_REPORT.md` — reconciliation and implementation report.
- `00_PASSMAP/PASS99_RUNTIME_RECONCILIATION.json` — smoke evidence/MID114-vs-MID117 correction.
- `00_PASSMAP/PASS99_CAMPAIGN_SWEEP_FIX.json` — source MID117 costs.
- `00_PASSMAP/PASS99_QA_SEED.json` — one-shot UID13371337 seed.
- `00_PASSMAP/PASS99_MID97_RESEARCH.json` — source contract/retry blocker.
- `00_PASSMAP/PASS99_SRC64_FEEDBACK_LOOP.json` — source evidence.
- `00_PASSMAP/PASS99_VALIDATION.json` — validation gates.
- `00_PASSMAP/PASS99_CLIENT_TEST_PLAN.md` — runtime smoke.
- `00_PASSMAP/PASS99_PHASED_ROADMAP.json` — continuation.
- `00_PASSMAP/databases/GAME_KNOWLEDGE_CATALOG_PASS99_0.sqlite` — current database.

Backend v0.12.3; runtime pending; MID97 intentionally fail-closed.
