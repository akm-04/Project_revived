# Pass 88.0 Index — Commerce/VIP Phase 2

Backend: `gxb-backend-v0.10.1-pass88.0.zip`  
SHA256: `aa297fa2640112534599c8ece01f60cab33ed3f732e628498866023f311f9994`

## Start here

1. `00_PASSMAP/MACHINE_BOOTSTRAP_PASS88.json`
2. `00_PASSMAP/PASS88_LIVE_CHECKPOINT.json`
3. `00_PASSMAP/COMMERCE_IMPLEMENTATION_STATUS_PASS88.json`
4. `00_PASSMAP/PASS88_PURCHASE_BRIDGE_CONTRACT.json`
5. `00_PASSMAP/PASS88_SETTLEMENT_CONTRACT.json`
6. `00_PASSMAP/PASS88_SRC64_FEEDBACK_LOOP.json`
7. `00_PASSMAP/PASS88_VALIDATION.json`
8. `00_PASSMAP/CURRENT_NEGATIVE_MEMORY_PASS88.json`
9. `00_PASSMAP/databases/GAME_KNOWLEDGE_CATALOG_PASS88.sqlite`

## Current gate

Run Pass88 purchase bridge smoke and reconcile. Do not expand features until exactly-once, client completion injection and restart durability are runtime-proven.
