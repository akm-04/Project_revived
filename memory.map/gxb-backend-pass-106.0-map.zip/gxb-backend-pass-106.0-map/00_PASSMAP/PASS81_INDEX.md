# Pass 81.0 — Daily Reset & Super Campaign Corrections

## State
Bounded correction implementation complete. Static/offline validation and Pass68-Pass79 regressions are green; focused client smoke is pending.

## Start here
- `MACHINE_BOOTSTRAP_PASS81.json`
- `PASS81_LIVE_CHECKPOINT.json`
- `PASS81_TECHNICAL_CHANGELOG.md`
- `PASS81_SRC64_FEEDBACK_LOOP.json`
- `PASS81_CORRECTION_SELFTEST.json`
- `PASS81_REGRESSION_MATRIX.json`
- `PASS81_CLIENT_TEST_PLAN.md`
- `CURRENT_NEGATIVE_MEMORY_PASS81.json`

## Corrections
1. Path-aware canonical dictionary replacement makes Quick Enchant `counts={}` and Task `daily_cache={}` durable while preserving unrelated extension dictionaries.
2. Successful canonical Super MID114 consumes remaining `daily_limit` exactly once; duplicate receipt is idempotent.
3. Super MID113 fails closed at zero remaining attempts.

## Backend
`gxb-backend-v0.9.10-pass81.0.zip`

## Hard boundary
No MID116/117/118 or new domains. Super defeat/star=0 attempt consumption remains unresolved.

## Next gate
Focused client correction smoke and reconciliation. Only if clean may MID116 return as a separate bounded pass.
