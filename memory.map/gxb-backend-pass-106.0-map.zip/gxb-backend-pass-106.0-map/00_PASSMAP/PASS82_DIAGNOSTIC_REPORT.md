# Pass 82.0 — Cold-Start Daily Reset & MID99 Diagnostic Report

## Status
Pass 82 is **research/diagnostic only**. No Python backend code was changed. The backend remains frozen at `gxb-backend-v0.9.10-pass81.0.zip` SHA-256 `832caf3eafed087fbb84f32a8794fda39207d384e7013e3a1e390e72467fa56e`.

The supplied `debug.zip` SHA-256 is `672ad0e9905f1eade88a7c03954fdb0e11e5e63c08829964edbb3542f984b85a`. Effective `src_64` was rebuilt from the canonical asset archive and cross-checked for every diagnosis and Pass83 proposal.

## Runtime result
Pass81's Super correction is runtime accepted: the log shows the source-owned remaining count moving `3 -> 2 -> 1 -> 0`, surviving a same-time restart at `0`, and consuming Stamina normally. Pass81 persistence should therefore remain untouched.

The +1-day cold-start did **not** execute any DailyReset participant. The strongest proof is broader than Quick Enchant/Super: post-jump MID1 still returned `buy_skill_times=8`, and the next MID99 returned `buy_skill_times=9`. Quick Enchant remained `0|1|...` and MID112 still returned Super `1300022.daily_limit=0`. Temporal recovery, by contrast, independently restored Energy to 159 and Skill Point to 80.

## Root cause A — the smoke started behind a persisted source-day high-water marker
This specific +24h failure is explained by the lineage of the test state. Pass80's saved runtime evidence records the previous Pass79 time-travel login at `server_time=1787499087`, which maps to source day **20688**. That run successfully reset the Skill Point purchase counter; the DailyResetCoordinator writes `current_day_id` in the same rollover transaction.

Pass81 then began at `server_time=1787424958`, source day **20687** — the host clock had moved backward. The persisted `skill_time=1787499214` is itself in source day **20688**, independently proving that player state from the prior future-clock run survived this rollback.

The frozen coordinator intentionally implements a monotonic high-water rule: `stored_day > current_day` returns `CLOCK_REGRESSION_IGNORED`; `stored_day == current_day` is a same-day no-op. The new +1-day login reached `server_time=1787512061`, source day **20688**. In other words, it only **caught back up to a day already materialized in the prior smoke**. Under the current anti-double-grant contract, no new reset was due yet. Source day 20689 would be the next legitimate rollover.

This behavior is safe for a real server-clock rollback. Removing the high-water guard just to make OS time travel look intuitive would reopen Quick Enchant, purchase counters, and Super attempts twice for the same canonical day.

## Root cause B — MID1 has a real cold-start ordering defect
Independent of the time-travel contamination, the audit found a genuine bootstrap seam problem that must be fixed before considering Daily Reset complete.

`EngineDispatcher` invokes `evaluate_daily_reset()` before handler execution. But `StateRepository._bind_engine_request()` intentionally returns without binding a player for MID1/MID18. Therefore the pre-handler coordinator call on MID1 always sees `player is None` and returns without evaluating the day.

The MID1 handler then resolves/binds the player, immediately runs `temporal.materialize_all(persist=True)`, and builds the bundled login detail. It never invokes DailyResetCoordinator after player resolution.

`src_64` proves this ordering matters. The TOKEN event calls `SelfPlayer:loadGameStartInfoEvent_()`, where bundled detail 17 hydrates player counters/timestamps and detail 112 hydrates WorldMap/Super `dailyLimit`. Thus the server must canonicalize the source day **before** creating MID1 detail.

There is also a migration edge: if `daily_reset_state` is absent, a cold-start temporal recovery can write a current-day `persistence_state.last_commit` before coordinator migration logic runs. The later coordinator call can then see no durable stale proof and conservatively seed the current day, silently skipping the intended first rollover.

## MID99 / Skill Point quirk
The server did not lose purchased Skill Points. Before the time jump, MID99 responses were:

- purchase 6: `skill_point=20`
- purchase 7: `skill_point=30`
- purchase 8: `skill_point=40`

The problem was the timestamp sent to the client. Initial `server_time=1787424958`, while persisted `skill_time=1787499214` was **74,256 seconds (20.63h) in the future**. `src_64`'s `SelfPlayer:recoverByTime()` calculates `floor((serverTime-lastSkillPoint)/duration)` with no lower clamp. `misc.lua` defines the duration as 300 seconds, so the client computes `floor(-74256/300) = -248` recovery ticks. That can drive the local `skillPoint` negative/visually to zero even after MID99 correctly assigns 20/30/40.

The frozen backend's temporal service does clamp server-side elapsed with `max(0, now-anchor)`, so it does not subtract server resources — but it also leaves a future anchor unchanged and sends it to Lua. After the +1-day run caught up far enough to materialize Skill Point to cap 80, `skill_time` became 0 and client behavior normalized.

The post-jump MID99 still advanced `buy_skill_times=8 -> 9`; this is further proof that the daily reset did not occur.

## Source-verified Pass83 correction plan
1. **MID1 reset ordering:** after `resolve_or_create_player()` binds the player, evaluate DailyResetCoordinator before temporal materialization and before `build_detail()`. MID1's full detail should carry the canonical reset state; do not invent a MID1 `daily_updates` pulse without source evidence.
2. **Migration ordering protection:** Daily Reset initialization/rollover must precede any cold-start temporal save so `last_commit` cannot be freshened before migration stale-proof is evaluated.
3. **Preserve clock-regression safety:** keep `stored_day > current_day` fail-closed. Add clear diagnostic logging/metadata for stored/current day and mode. A real rollback must never reopen an already-materialized day.
4. **Future temporal-anchor hygiene:** if a supported temporal balance is below cap but its anchor is greater than server `now`, rebase the anchor to `now` without granting or removing balance. At/above cap retain source sentinel `0`. Apply generically to Energy/Spirit/Skill rather than patching MID99. This prevents src_64's negative `recoverByTime` path without giving free resources.
5. **Test discipline:** add deterministic injected-clock tests for normal offline rollover, MID1 hydration, no-marker migration, rollback high-water, catch-up, high-water+1 rollover, and future-anchor rebase. Manual OS time travel should start from clean monotonic state or advance beyond the persisted high-water day.

## Strict boundary
No backend modification was made in Pass82. MID116/117/118, Tasks/Activities, Sign, Shops, Arena, cards, Vows, Workshop, and Pet remain outside this correction pass.

## Gate
Recommended next pass: **Pass83 — bounded cold-start Daily Reset ordering + temporal future-anchor hygiene + observability/tests**, only after explicit authorization.
