# Phase 3 — Pass74.0 Awakening / Blood Awakening Mission Ownership

**Status:** STATIC_ACCEPTED_RUNTIME_PENDING. **Pass72.0 remains the last clean runtime-accepted pass.** Pass73.0 is runtime-characterized: the user confirmed major advanced-progression success, but four Lua response-contract errors were captured and are corrected in Pass74.

## Why Pass74 exists

The earlier assumption that an undefined `AWAKE_HERO` MID blocked Awakening was wrong. Effective `src_64` shows the live system is mission-driven. Clicking the Girl's Awakening gear opens a source mission, the task advances through Mission UI, battle results carry a bounded qualifying proof, and final claim applies canonical Hero awakening.

## Ordinary Awakening

Source graph: **465 rows across 164 Heroes**. Stage 1 is the exclusive Awakening-gear gate. Stage 2 is a Hero-specific Campaign objective. Objective families recovered across the 164 Hero chains are SELF_KILL (20), DAMAGE_ACHIEVE (3), ALONE_KILL (15), and ALL_ALIVE (126).

Pass74 implements persistent mission ownership for MID2738 open, MID2737 give-up, MID2561 list, MID2736 type load, MID161 claim, and the ordinary MID114 Campaign proof seam. The server does not pretend to reconstruct combat data the client never transmits; it validates the exact active mission/stage/source Campaign/win and accepts `awake_mission` only as the source-bounded client-attested proof that the local special-objective check passed.

Final ordinary claim applies bounded HERO ENTITY `AWAKEN_TABLE_ID` inside the one-player transaction boundary.

## Blood Awakening

Source graph: **162 rows = 81 Heroes × 2 stages**. Stage 1 is the Blood-exclusive gear requirement. Stage 2 uses the dedicated MID866/MID867 Unlimited fight route. Canonical `twice_awake_stage` progresses 0 → 1 → 2 → 3. Final claim persists stage 3 through bounded HERO ENTITY ownership.

## Client reconciliation contracts

`TASK_AWAKE_OPEN` must return `awake_mission_`/`twice_awake_mission_`; the Lua client does not locally insert the new row. Give-up must return the same mission as inactive (`is_going=0`, `is_complete=0`, `count=0`), because the Task UI retains the row and displays the Open button when it is not going. Stage claims return the next source mission delta.

## Runtime-neighbor corrections

### Emblem Dissolve
MID1404 now settles emblem STACK debit + the correct scalar certificate RESOURCE credit. IDs 19/20/21 are degree/graduate/patent certificate currencies. Observed emblem `160500603` resolves to `patent_cer +1420` each.

### Quick Enchant
MID28 now returns required `buy_times`. MID29 settles 20 Crystals + bounded 150 Fumo atomically, persists the source once-per-day counter, and returns cumulative `fumo`.

### Stone Evolution rejection
Because `Backend.lua` treats HTTP 200 as transport success before body `error_code`, rejected MID2608/MID2609 responses now include authoritative unchanged `evo_info` and commit nothing. This eliminates the nil dereference found in the Pass73 smoke.

## Boundaries

General Campaign ownership—including the ordinary 6-Energy stage cost—is intentionally still deferred. The debug inventory capacity warning is a test-seed side effect, not a production-cap rule. Hidden-random/server-generated advanced progression remains fail-closed.
