# Pass 95.0 — Economy/VIP Loose Ends Targeted Exploration

Timestamp: 2026-08-23T11:07:51+06:00

## Executive result

Pass94 PlayerProgressionService is now **RUNTIME ACCEPTED** from the supplied debug smoke. Pass95 intentionally makes **no backend changes**. The canonical backend remains `gxb-backend-v0.12.0-pass94.0.zip` (`8f535b9b7b68872e9ef944aca29c3fd9ad75b6a056108227304c30331c552e6f`).

Pass95 resolves four loose ends before the RNG phase:

1. SX/Soul Box purchase authorization is already correctly server-gated at VIP9; merely opening/seeing the SX UI at VIP0 is source-native. The next implementation should add an explicit VIP0/VIP9 purchase regression test, not a fabricated window-visibility restriction.
2. The targeted audit found two active implemented privilege gaps: Campaign **multi-sweep** does not enforce source `quick_sweep`/Monthly-Privilege eligibility, and Hero preset save does not enforce source `preset_num`.
3. Inventory capacity is **not universally 999**. `item.lua` defines heterogeneous per-item stack ceilings; the current StackInventory has no upper-bound invariant. The legacy 1000x developer seed therefore creates invalid state for 1,699 of its 1,717 unique seeded item IDs.
4. Academy maximum level is source-authoritative **100**, while the backend still advertises `max_lev=200`. This is a latent client-loop hazard even though Pass94 server-side progression clamps to recovered source level100.

## Pass94 runtime acceptance

The fresh `progressor` account began at level1/EXP0/Energy60. Eight Campaign settlements advanced cumulative EXP through 18,45,63,90,108,126,144,162 and level through 4,7,9,10,11,11,11,12 while level-up Energy correctly overflowed the normal cap. Cold restart restored level12/EXP162/Energy138 with max_energy72. No PlayerProgressionService defect was found.

The MID1 smoke also exposed the independent `max_lev=200` projection mismatch used in the Academy investigation below.

## VIP audit

### SX / Soul Box

`SummonWindow.lua` gates the **buy action** with `xyd.tables.vip:soulBox(vip) == 1`; recovered VIP rows use value2 for VIP0-8 and value1 beginning at VIP9. Pass94 MID50 type4 descriptors/private policy already encode `vip_min=9`, and `SummonRepository` checks `VipPrivilegeResolver.meets_level()` before dispatch. Therefore a canonical VIP0 SX purchase is statically denied even though the client may show/open the SX window.

### Active implemented gaps

- **Campaign MID117 multi-sweep:** `NewMapDetailWindow.lua` requires VIP `quick_sweep` (first enabled at VIP4) **or** active Monthly Privilege. `WorldRepository.sweep()` currently accepts `sweep_num` 1..100 without enforcing that entitlement. The future gate must distinguish multi-sweep from ordinary single sweep.
- **Hero preset save:** `HeroPresetWindow.lua` caps preset count using VIP `preset_num`: 10 at VIP0, then 12/14/16/18/20 at VIP3/6/9/12/15. `HeroRepository.save_presets()` currently persists the serialized payload without a server-side count check.

Already-correct active VIP integration includes MID116 `num_elite`, skill-point `skill_buy`/`skill_max`, VIP rewards, Commerce VIP progression, and SX purchase VIP9. MID96, MID97 and Arena ticket purchase are incomplete/fail-closed or non-mutating stubs, so they are not classified as active bypasses.

## Inventory stack authority

Decoded `data/tables/item.lua` contains 5,838 rows. Source stack values are heterogeneous: 3,175 rows cap at999; 1,258 at99; 600 at1; 444 at999999; 50 at9999; smaller groups use 5/10/99999/9999999; 298 rows carry 0. `Backpack.lua` clamps an existing local stack to `xyd.tables.item:stack(itemID)` and optionally displays `ITEM_EXCEED_TIP` when `stack_exceed_mail==1`.

The canonical backend `StackInventory` validates only that deltas do not make a stack negative. It does not currently enforce a source upper bound. Therefore the next implementation should introduce a source-derived item-stack catalog and enforce it in the UoW settlement path. Pass95 deliberately does **not** invent overflow-mail settlement because client metadata alone does not recover the original server delivery semantics.

## Developer account normalization

Pass72 and Pass73 one-shot migrations seed UID13371337 with minimum quantity1000. Across both catalogs there are 1,717 unique item IDs: 1,697 source-cap999, 18 source-cap9999, and two source-cap99. Thus 1,699 are invalid at quantity1000.

The future one-shot correction should only lower oversized persisted stacks and should preserve already-consumed quantities. Recommended QA headroom is 900 where the source cap is at least999, 90 for the two cap99 seeded items (`50001058`, `50001885`), and a source-aware lower target for any other cap. This requires a **new migration marker**; historical Pass72/73 markers must not be replayed or rewritten.

## Academy maximum

Recovered `player.lua` has exactly 100 rows. The English FAQ explicitly states that the maximum Academy level is100. Source row99 has total_exp579615; source row100 has Energy cap160 and total_exp613615.

`PlayerState.max_lev` still defaults to200 and MID1 advertises200. Pass94's progression service clamps internally to source level100, but `SelfPlayer.lua` also trusts the server's `max_lev` and increments level before checking the cap. A level100 sandbox with EXP at or above613615 can therefore step to101 even if max_lev is corrected to100.

For the legacy developer account the bounded target is: `lev=100`, `max_lev=100`, `exp=579615`, `max_energy=160`. EXP579615 is the source total required to have arrived at level100 from level99 and remains below the level100 threshold, avoiding the client increment-to101 hazard.

## Recommended Pass96 implementation order

1. Align canonical Academy `max_lev`/max-level EXP semantics to source level100.
2. Add source-derived item stack-limit authority and enforce the invariant in StackInventory/UoW.
3. Add the UID13371337 one-shot source-aware inventory + Academy normalization.
4. Enforce VIP/Monthly-Privilege entitlement for Campaign multi-sweep only.
5. Enforce VIP `preset_num` for Hero preset save.
6. Add explicit VIP0 rejection/VIP9 allowance regression coverage for SX purchase.

Then perform a focused client smoke/reconciliation. Only after this cleanup is accepted should the shared `RandomOutcomeService` phase begin.

## Commit

`Pass95.0: runtime-accept PlayerProgressionService smoke; map source-native VIP entitlement gaps, per-item stack ceilings, sandbox normalization, and Academy level-100 cap; backend unchanged`

## Machine-memory health

Promoted database: `GAME_KNOWLEDGE_CATALOG_PASS95_0.sqlite`; project tables: **473**; `PRAGMA integrity_check = ok`.
