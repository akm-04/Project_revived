# Pass 90.0 — VIP Completion & MID116 Architecture Reality Check

## Result

Pass89 is now fully runtime accepted end-to-end. The supplied debug shows the source MID2 updater advertising and serving `1.631.3`, the restarted client reporting `v=1.631.3`, and 25 direct-Crystal purchases authenticated exclusively to fresh account UID `20000002` / player `19700002` / region `197`. The first purchase reaches VIP1 at charge 100 and the run reaches VIP15 at charge 528600, ending at charge 560600. The user separately confirmed VIP and Crystal persist across restart.

No Python backend changes are made in Pass90. Backend authority remains `gxb-backend-v0.10.2-pass89.0.zip` (6ff3a674fdb8d8754dae2141f799769b01098c985dfd2566ee46fb92b9a8a913).

## VIP completion definition

The Commerce/VIP core is not complete merely because VIP progression works. Core completion requires: coherent charge→VIP progression, MID354 catalog, exactly-once direct Recharge, resolver-based policy access, source-shaped one-time VIP award state, and MID657 atomic claims. The first four are implemented/runtime accepted. MID657 is the only missing core VIP lifecycle mutation.

The active implemented VIP consumers are already centralized: Skill Point/Temporal policy and Summon/Soul Box. Other source VIP accessors belong mostly to domains that are still stubs/incomplete and should not be bulk-wired prematurely.

## Pass91

Implement the one-time VIP award lifecycle. Initialize canonical `vip_awards` as a fifteen-element 0/1 claim vector, preserve any existing non-empty statuses, load reward definitions from source-derived VIP/gift metadata, and commit reward + claim marker atomically through PlayerUnitOfWork. Duplicate claims naturally replay as no-grant because the claim marker is semantic idempotency.

## Pass92

Implement MID116 Super Campaign paid reset after Pass91 client acceptance. Campaign should compose `VipPrivilegeResolver.super_campaign_paid_reset_limit()` with the source-known Monthly Privilege +3 when `privilege_left_card_day > 0`. Debit the nth source reset cost and restore the source Super daily-limit baseline in one UoW while incrementing reset_count and preserving stars.

MID116 does not contain a source operation ID. Because Backend.lua can retry failed web requests and identical MID116 requests may also represent legitimate consecutive resets, Pass92 must not fabricate exact-once dedupe from request shape. Atomicity is required; fake idempotency is not.

## After VIP/Campaign reconciliation

Return to the existing core-closure roadmap: finish Global Economy strangler migration, build RandomOutcomeService/RNG receipts, close Girls/Equipment unique-instance ownership, then use that RNG spine for Campaign repeat drops/MID117. MID118 remains source-ready but deliberately parked.
