# Pass 86.0 — Commerce / VIP Technical Design Document

## 1. Status

Pass 86 is architecture-only. `gxb-backend-v0.9.12-pass83.0.zip` remains the implementation baseline with SHA-256 `eefee74fbf18707e1923cd26a70016440edefa76b5d2c0525c9df96c44888792`. No Python backend code is changed or repackaged.

## 2. Architectural thesis

Recharge is an external purchase-intent boundary feeding an ordinary one-player transactional domain. The private server may auto-authorize a purchase, but auto-authorization must not weaken catalog authority, idempotency, state ownership or durability.

The key split is:

`PurchaseIntentBridge -> AutoAuthorizePurchaseProvider -> CommerceSettlementService -> PlayerUnitOfWork -> committed receipt/outbox -> MID36857 completion`

Crystal remains `EconomyLedger` state. `charge`, `vip`, product purchase history and VIP claims are Commerce/VIP state. Other game domains consume VIP policy only through `VipPrivilegeResolver`.

## 3. Component communication

1. MID354 asks `RechargeCatalogService` for supported source-known products and player-specific `charge_count/last_buy_time`.
2. A preservation native/Lua bridge sends only a normalized authenticated purchase intent to `POST /preservation/v1/purchase-intents`.
3. `AutoAuthorizePurchaseProvider` validates that the selected product is currently advertised and returns a stable authorization receipt ID.
4. `CommerceSettlementService` checks an existing `commerce_purchase` receipt, resolves first-buy policy from pre-state, and enters one `PlayerUnitOfWork`.
5. Crystal is credited through `EconomyLedger`; cumulative `charge`, derived `vip`, and product history are changed by `CommerceEntitlementService`.
6. The final source-shaped RECHARGE body is staged into the durable purchase receipt and Commerce outbox before commit.
7. After commit, `GamePushGateway` delivers MID36857. Until native TCP framing is recovered, the preservation bridge may inject the committed returned event into the Lua event path. Transport retries never run settlement again.

## 4. UoW safety

One logical purchase has one idempotency key (`provider_receipt_id` / `intent_id`). The receipt fingerprint binds actor, region, product and platform. A duplicate with the same fingerprint replays. Reuse with a different product conflicts.

The UoW snapshot covers both ledger and entitlement state. Any exception between Crystal credit and VIP/product-state update restores the pre-purchase PlayerState. No completion event is emitted before commit.

The existing generic MutationPlan does not need to be widened in the first implementation merely to support Commerce. Crystal already has a typed owner. `charge/vip` can remain a tightly bounded Commerce aggregate mutation inside an active UoW until another domain proves a reusable entitlement-mutation family is worthwhile.

## 5. Mock SDK bridge

Effective `src_64` proves the tap crosses into Android/iOS native code and later receives server RECHARGE; it does not contain the native provider callback implementation. Therefore the preservation endpoint is explicitly a private transport policy, not recovered historical protocol.

The stable bridge wire contract is `POST /preservation/v1/purchase-intents` with `intent_id`, authenticated session/token context, region, `charge_id`, and platform. Price, Crystal payout, first-buy state, VIP and player ID are not trusted from the caller.

Two replaceable adapters may feed this endpoint: a native AppActivity/SdkIOS redirect, or a preservation Lua wrapper. Both consume the same committed response. The preferred eventual delivery is normal game TCP MID36857 once framing is recovered; the first preservation implementation can inject the returned committed event locally while MID1/MID354 remain durable reconciliation paths.

## 6. VIP autowiring

`VipPrivilegeResolver` is the single read facade for all dependent domains. Every new VIP dependency must register a resolver key mapped to canonical `vip.lua`, classify its semantics, state its lifecycle owner, declare source-proven card/activity composition, and add threshold tests. Commerce derives VIP but does not own Daily Mission sweep-card claims, Campaign MID116 state, Arena attempts, or other domain lifecycle mutations.

## 7. Established sandbox normalization

The legacy `13371337` profile must not remain canonical `vip=15, charge=0`. A one-time state migration should set `charge=500000`, the minimum source VIP15 threshold, and rederive VIP15 without granting Crystal, fabricating a purchase, filling product counters, or altering cards/skins. Per-product counters remain zero absent evidence. VIP reward claim state should become explicit rather than relying on an empty compatibility object.

Progression testing should use a fresh `vip=0/charge=0` commerce-lab account rather than downgrading the established compatibility profile.

## 8. Source/private-policy boundary

Recovered source owns the MID354/MID657/MID2981/MID36857 semantics, product tables, VIP thresholds/privileges and client completion behavior. Private-server policy owns the purchase-intent HTTP route, local auto-authorization, the direct-charge VIP delta until historical server code is recovered, and the temporary bridge-response injection mechanism.

Every implementation change must preserve that labeling.

## 9. Recommended implementation sequence

First establish coherent Commerce/VIP state, policy services, sandbox migration and MID354. Then add exactly-once direct Crystal auto-authorized settlement and RECHARGE completion. Next add MID657 and migrate existing Skill Point/Summon VIP consumers behind the resolver. Only after runtime smoke should MID116 be reconsidered. MID117 remains blocked by the separate RandomOutcomeService/Campaign RNG program.
