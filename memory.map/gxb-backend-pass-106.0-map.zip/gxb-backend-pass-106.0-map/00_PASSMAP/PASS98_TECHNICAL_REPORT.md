# Pass 98.0 — Deterministic Consumables Implementation

## Result

Pass97 research is accepted as canonical authority. Pass98 implements only the deterministic safety/QA-unblock slice it mapped. Canonical backend is `gxb-backend-v0.12.2-pass98.0.zip` (`c66071c7807bc89ccd651eb492406556e412f16147be88efb6899e94d285e9db`), **STATIC/SELF-TEST/FRESH-EXTRACTION ACCEPTED; CLIENT RUNTIME PENDING**.

## Source-derived consumable authority

`ConsumableEffectCatalog` is generated from canonical effective `src_64/data/tables/item.lua` SHA `59b668c28a372543da0c36d7a8d84291cc5b93fa0d92b7cc389a645e96e7b7cc`. It captures 5838 source item rows and 2034 consumables. Runtime effect interpretation is operation-scoped, not a generic application of arbitrary numeric columns.

## MID27

All 22 source Energy consumables are supported. Kanto Food (`50001015`) grants 18 Energy and Tonkatsu (`50001016`) grants 30. Settlement remains one UoW: Backpack debit + TemporalPolicyService Energy credit. Natural-cap overflow behavior remains source-compatible.

## MID87

All 12 source magic consumables now atomically debit Backpack stacks and credit `magic_energy`, `magic_dust`, or `magic_liquid` through EconomyLedger. The selection priority matches `EventCentreSellWindow.lua`. Invalid/mixed requests fail without partial settlement.

## MID1404

The metadata generator now completes concrete item mapping from `item.lua.inscript_id`: 240 -> 254 items, adding the fourteen valid Honor variants ending 11/12 for levels1..7. `inscription.lua` remains the resolve reward policy; certificate currencies are unchanged and no generic Emblem EXP was invented.

## Destructive-path safety

MID134 now explicitly fails closed because the source Pet client removes submitted EXP items after OK while canonical Pet EXP settlement is unresolved. MID241 remains fail closed because complete gift/chest support crosses random outcomes and missing recovered definitions; Pass98 does not invent a partial random policy.

## Validation

Compileall, focused Pass98 tests, the historical regression spine through Pass96, byte-for-byte metadata regeneration from canonical `src_64`, ZIP integrity, and fresh-extraction validation all pass. Client smoke remains required for runtime acceptance.

## Next gate

Run the focused Pass98 smoke: Kanto/Tonkatsu exact Energy + item debit/persistence; three MID87 resource classes; formerly missing Honor inscription resolution; MID134 fail-close/no item loss. After clean reconciliation, the strongest immediate QA-unblock candidate is bounded MID97 stamina purchase, followed by the shared RandomOutcomeService roadmap.

## Commit

`Pass98.0: add source-authoritative deterministic consumable effects, repair MID27/MID87 and complete MID1404 mapping, and fail-close unresolved destructive item-use paths; client smoke pending`
