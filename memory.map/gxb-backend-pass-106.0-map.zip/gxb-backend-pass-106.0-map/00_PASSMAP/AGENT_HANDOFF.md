# Pass100.0 Migration Handoff

Canonical backend: `gxb-backend-v0.12.4-pass100.0.zip` SHA-256 `ec255d1ed656fe72414972d7c0d113daed8725c0022ad294f050cb217a88bfd5`. Canonical source: `all-assest-rechecked.zip` SHA-256 `89f0f830508b92e5fff6ad53c6a9dae961a14042dbfdf5649008efb8353f5608`.

Pass99 is runtime accepted. Read READ_FIRST, MACHINE_BOOTSTRAP_PASS100_0, PASS100_LIVE_CHECKPOINT, runtime reconciliation, MID97 OTA/implementation/source/validation records, CURRENT_AUTHORITY_MAP, QUERY_ROUTER, then GAME_KNOWLEDGE_CATALOG_PASS100_0.sqlite.

Critical state: OTA `1.631.4` preserves 126 prior overrides and adds only AddEnergy.lua for both arches. Each MID97 click sends expected counter + canonical source day + source-native UUID. Backend settles Crystal debit/+120 Energy/counter/receipt atomically; committed retry is read-only; unpatched empty MID97 fails closed. Daily reset still exclusively owns `buy_energy_times=0` at 05:00 GMT+8.

Immediate gate: real client installs OTA 1.631.4 and smoke-tests MID97 including retry, restart and daily reset. After clean reconciliation, resume RandomOutcomeService. Mandatory src_64 feedback loop remains in force.
