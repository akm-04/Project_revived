# Pass96.0 Client Smoke

1. Cold-start legacy UID `13371337`; verify Academy level100, max level100, max Energy160.
2. Verify representative historic test items are now within source-aware headroom (999/9999 families <=900; IDs 50001058 and 50001885 <=90) and already-consumed lower rows were not replenished.
3. Craft/consume a formerly blocked item. If practical, test a source stack ceiling and verify failed overflow does not partially commit sibling economy changes.
4. VIP0: single Campaign sweep remains available; multi-sweep is rejected. VIP4+: multi-sweep succeeds. If an active Monthly Privilege test account exists, verify the alternate entitlement below VIP4.
5. VIP0: save up to10 Hero presets; the 11th must be rejected without overwriting existing presets. Verify a higher-VIP source-expanded limit.
6. Cold restart and verify normalization marker/state, Academy, inventory, and presets persist.

SX is intentionally out of scope because its VIP9 purchase block is already client-confirmed.
