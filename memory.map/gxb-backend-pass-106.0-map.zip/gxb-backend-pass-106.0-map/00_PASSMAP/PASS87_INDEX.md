# Pass 87.0 — Commerce/VIP Phase 1 Index

Pass87 is the current authority. Backend: `gxb-backend-v0.10.0-pass87.0.zip` SHA-256 `ddf02042430964cb4fd9f50dd92827cb4ca1d51e2422210e1b8979582fefc297`.

## Read first
1. `MACHINE_BOOTSTRAP_PASS87.json`
2. `PASS87_LIVE_CHECKPOINT.json`
3. `COMMERCE_IMPLEMENTATION_STATUS_PASS87.json`
4. `PASS87_IMPLEMENTATION_READINESS.json`
5. `VIP_INTEGRATION_POLICY.json`
6. `PASS87_SRC64_FEEDBACK_LOOP.json`
7. `CURRENT_NEGATIVE_MEMORY_PASS87.json`
8. `databases/GAME_KNOWLEDGE_CATALOG_PASS87.sqlite`

## Implemented
VIP progression/resolver, Commerce state/history envelope, MID354 direct Crystal catalog, legacy VIP15/charge0 normalization, and migration of Skill/Temporal/Summon VIP consumers.

## Not implemented
PurchaseIntent, auto-authorization, Crystal settlement, MID36857 completion/outbox, MID657, cards, Store, MID116/117/118.

## Next gate
Run Pass87 client smoke: login established 13371337, verify vip15/charge500000 and MID354 direct Crystal catalog; inspect no regression in Skill Point/Soul Box. Reconcile before implementing PurchaseIntent/settlement.
