# Pass 92.1 — Full Chat Migration Handoff

## Purpose

Pass92.1 exists only to make the project portable into a fresh chat window. It changes **no backend code**. It promotes the Pass92 machine-memory, repairs stale navigation metadata, and records the exact startup protocol for the next chat.

## Canonical state

Backend implementation authority: `gxb-backend-v0.11.1-pass92.0.zip`  
SHA-256: `6d6e447ef5a78e2d965e97d6832ade0ce41afa39197b9d433c4fafa8b94f4eaf`

Canonical source/assets authority: `all-assest-rechecked.zip`  
SHA-256: `89f0f830508b92e5fff6ad53c6a9dae961a14042dbfdf5649008efb8353f5608`  
Effective source inventory: 4,370 files. `src_64` is mandatory evidence for every backend change.

Prior map provenance: `gxb-backend-pass-92.0-map.zip`  
SHA-256: `68d83dde2ae347a1aba381a154b72a31e7d3bd43c6450f688971f869f3da2d29`

## Architectural chain that must not be forgotten

### Daily Reset / time foundation
Pass79 introduced the 05:00 GMT+8 `ServerDayClock` / `DailyResetCoordinator`; Pass80 diagnosed dictionary resurrection; Pass81 fixed canonical replacement semantics and Super attempt consumption; Pass82 diagnosed source-day high-water/cold-start ordering; Pass83 fixed MID1 reset ordering and future temporal anchors. Pass83 was subsequently runtime accepted. High-water clock rollback protection must remain fail-safe.

### Commerce / VIP
Pass84 reality-check identified source-incoherent VIP15/charge0 and the need for Commerce/VIP authority. Pass85 recovered the native SDK boundary, MID354 catalog, VIP policy blast radius, and active Skin Mall split. Pass86 froze the modular Commerce RFC. Pass87 implemented coherent Commerce/VIP state, `VipProgressionPolicy`, `VipPrivilegeResolver`, MID354, and the legacy normalization. Pass88 implemented exactly-once direct-Crystal PurchaseIntent settlement inside `PlayerUnitOfWork`. Pass89 activated source-native MID2 OTA resource update `1.631.3`, injected the preservation purchase bridge, hardened live-session authentication, and was runtime accepted from a fresh account progressing VIP0->VIP15. Do not regress to `local_token` as a generic account selector.

### VIP awards
Pass90 reconciled VIP dependencies and planned MID657 then MID116. Pass91 implemented source-backed VIP1-VIP15 award lifecycle using `vip.lua -> reward_item -> gift.lua`, canonical 15-entry `vip_awards`, atomic typed settlement + claim marker, duplicate no-grant, and was runtime accepted organically through VIP15 with restart persistence.

### Campaign
Campaign MID113/114 ownership, atomic battle settlement, Super attempts 3->2->1->0, idempotent committed result receipts, and 05:00 restore are established. Pass92 added MID116 paid Super resets. Campaign repeat RNG remains intentionally disabled pending a system-wide random-outcome architecture. Super defeat attempt consumption remains a historical unresolved semantic unless newer evidence supersedes it.

## Pass92 MID116 implementation authority

Request: `campaign_id`, `campaign_type=2`.

Eligibility:
- source-known unlocked Super stage;
- exhausted (`daily_limit <= 0`);
- `reset_count < VipPrivilegeResolver.super_campaign_paid_reset_limit() + monthly_bonus`;
- monthly bonus is source `monthly_privilege.lua` `num_elite=3` only while `privilege_left_card_day > 0`.

Cost: `refreshEliteCost(reset_count + 1)`.

Atomic transaction:
- debit exact Crystal through `EconomyLedger`;
- restore the source stage `daily_limit` baseline;
- increment `reset_count`;
- preserve `star` and `is_partner_drop`;
- commit through one `PlayerUnitOfWork`.

Retry reconciliation:
- MID116 has no source operation ID.
- do not create a permanent campaign-id dedupe receipt;
- a repeated request while the previously reset stage still has `daily_limit > 0 && reset_count > 0` is read-only reconciliation and charges nothing;
- after those attempts are consumed back to zero, another identical source request is a legitimate later paid reset and uses the next cost ordinal.

Daily rollover:
- VIP does not own ordinary restore;
- `DailyResetCoordinator` at 05:00 GMT+8 restores source `daily_limit` and sets `reset_count=0`.

Static validation at Pass92: 20/20 historical self-tests green; fresh extraction passed the high-risk Pass92/91/89/88/87/83/81/79/75 gates.

## Immediate next interaction

The next chat's **first** user prompt is only workspace initialization. Read/verify all three canonical uploads and reply with current status + next gate. Do not perform feature work.

The next chat's **second** user prompt will provide `debug.zip` from the MID116 smoke.

Runtime decision tree:
1. If clean: formal Pass92 runtime acceptance -> Pass93 reconciliation/reality check only.
2. If buggy: diagnose `server.txt` + client errors + persisted player state against effective `src_64`; execute a bounded correction pass before any new feature.
3. Never skip runtime reconciliation and jump directly to MID117/118 or unrelated domains.

## Post-Pass92 strategic roadmap

The project intentionally prioritizes completing foundations already implemented before broad feature expansion:

1. Global Economy strangler closure: eliminate legacy five-field/dual ownership; keep domain-owned economy fields fail-closed until their owner migrates.
2. System-wide RNG / `RandomOutcomeService`: separate entropy from game probability policy; namespaced operation sessions, deterministic test provider, UoW committed outcome receipts; migrate existing Summon RNG without changing behavior before Campaign uses it.
3. Girls/Equipment economy closure: treat normal gear/Fumo, Super enhancement, Practice, Inscription, Element Equipment, Horcrux unique instances, Stone Evolution, Dorm gear as bounded owners; add unique-instance mutation support rather than making one giant repository.
4. Campaign reward closure: only after RNG infrastructure, address repeat drops/MID117 and remaining semantics.
5. MID118 is relatively source-complete but intentionally parked.

## Permanent project rules

- `src_64` Architectural Feedback Loop is mandatory for every backend modification.
- Passmap is the machine-memory authority; update it every pass.
- Work sequence: research/source-check -> decide -> bounded implementation -> static tests -> client smoke -> reconcile -> next domain.
- `PlayerUnitOfWork`, typed mutation/settlement owners, and domain ownership boundaries are architectural invariants.
- Do not implement source-unknown server algorithms as recovered facts. Mark preservation/private-server policies explicitly.
- Do not broaden Daily Reset into Shop/Arena/cards/other schedulers without source proof.
- Do not broaden VIP resolver wiring into unfinished domains just to appear complete.
- Prefer fail-closed behavior to fabricated protocol semantics.
