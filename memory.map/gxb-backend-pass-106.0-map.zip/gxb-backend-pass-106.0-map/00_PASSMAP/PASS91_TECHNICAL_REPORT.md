# Pass 91.0 — VIP Core Finalization / MID657

## Result

Pass91 implements the source-backed one-time VIP1–VIP15 gift lifecycle. Backend authority is `gxb-backend-v0.11.0-pass91.0.zip` (`4fe16a0577a0423d624461272af9077629ae650d74ad59016ae890e0962c1f8b`). Pass89 OTA/Commerce behavior is unchanged.

## State

`detail[17].vip_awards` is canonicalized to exactly fifteen literal integer 0/1 values, VIP1 through VIP15. Empty/missing legacy state becomes fifteen zeroes because no earlier backend pass implemented MID657 claims. Explicit legacy claims are normalized and preserved.

## Settlement

MID657 validates the requested tier against canonical VIP, resolves `vip.lua.reward_item -> gift.lua`, credits Crystal through EconomyLedger and stack items through the existing typed RewardTransactionService, then marks the tier claimed in the same PlayerUnitOfWork. A durable-write failure rolls all planes back. Duplicate claims return an empty awards list and do not grant again.

## Source shape

The full gift is returned as `awards` rows of `table_id/item_num`. Crystal uses source asset pseudo-ID -1 for display while remaining a scalar EconomyLedger resource.

## Gate

Static regression is green. Client smoke must prove gift visibility, claim popup/items/Crystal, restart persistence, duplicate no-grant and a representative high-tier claim. MID116 remains blocked until that acceptance.
