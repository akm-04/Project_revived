# Pass97 Index

- `00_PASSMAP/PASS97_TECHNICAL_REPORT.md` — human research/reconciliation report.
- `00_PASSMAP/PASS97_RUNTIME_ACCEPTANCE_PASS96.json` — Pass96 runtime acceptance.
- `00_PASSMAP/PASS97_CONSUMABLE_MID_MAP.json` — item-use protocol/MID map and client commit hazards.
- `00_PASSMAP/PASS97_CONSUMABLE_CATALOG_RESEARCH.json` — source consumable/effect catalog, Kanto metadata drift, magic and gift boundaries.
- `00_PASSMAP/PASS97_INSCRIPTION_RESOLVE_RESEARCH.json` — MID1404 certificate semantics and 14 missing source-valid mappings.
- `00_PASSMAP/PASS97_STAMINA_UNBLOCK_ARCHITECTURE.json` — deterministic QA-unblock implementation order plus MID97 follow-up.
- `00_PASSMAP/PASS97_SRC64_FEEDBACK_LOOP.json` — mandatory source proof.
- `00_PASSMAP/PASS97_VALIDATION.json` — artifact/research/database/manifest validation.
- `00_PASSMAP/PASS97_PHASED_ROADMAP.json` — bounded continuation sequence.
- `00_PASSMAP/databases/GAME_KNOWLEDGE_CATALOG_PASS97_0.sqlite` — current machine database.

Pass97 is map-only; backend remains v0.12.1 Pass96 and is runtime accepted.

Database project tables: 495; integrity: ok.
