# Shared Coordination & Battle Session Contract — Pass67

**Status: FROZEN extension seams.**

## PlayerUnitOfWork
One outer durable transaction is scoped to one player-owned command. It never spans client battle time and is not extended across multiple player JSON files.

## BattleSessionRepository
Two-phase battle admission/result flows persist an opaque mode-owned session/ticket. Admission may reserve/record cost/attempt/reward-preselection facts as domain evidence requires; result validates and consumes that session idempotently in a fresh PlayerUnitOfWork. A repeated result returns/replays the settled outcome rather than applying it twice. The session is not a universal battle simulator; it is correlation and authority state.

Frozen base fields: **12**.

## SharedCoordinationPort
Multi-actor room state (Fantasy/Illusion team and future shared-world features) lives in a shared aggregate/store behind a late port. The player JSON UoW remains unchanged. Room membership, ready state, selections and reports are not duplicated as authoritative state into every participant file. Participant-owned rewards/economy changes use idempotent player commands/outbox delivery when this deferred domain is implemented.

This is intentionally not a distributed-transaction framework and does not block the Phase3 single-player foundation.
