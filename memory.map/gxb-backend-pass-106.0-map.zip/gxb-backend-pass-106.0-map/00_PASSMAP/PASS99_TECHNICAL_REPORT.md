# Pass99.0 Technical Report

The smoke confirms MID27 Kanto +18 and MID1404 certificates. It also proves MID114 normal battle already spends Energy: after observed Energy159, FIGHT_RESULT stage1300016 returned148 while source cost is12. Pass99 leaves MID114 untouched.

MID117 was the actual leak. Pass99 atomically persists `campaign.energy_cost * sweep_num` plus Raid Ticket50001013 per ITEM_SWEEP or one Crystal per CRYSTAL_SWEEP, together with deterministic sweep reward stacks. Existing VIP/Monthly-Privilege multi-sweep gate remains.

UID13371337 gets a one-shot source-bounded QA seed: RaidTicket900, all12 magic items900, Fries/Kanto/Tonkatsu90 because their source cap is99. It never replenishes after its marker.

MID97 remains fail-closed. AddEnergy.lua sends `{}` and Backend.lua retries the same mid+params; after commit, identical requests cannot distinguish lost-response replay from a legitimate next purchase. Source-only safe next step is an operation-identity preservation bridge before exactly-once server settlement.

Focused tests, full sandbox migration order, compileall, historical regressions through Pass98, ZIP integrity, and fresh-extraction tests pass. Pass99 runtime smoke is pending.
