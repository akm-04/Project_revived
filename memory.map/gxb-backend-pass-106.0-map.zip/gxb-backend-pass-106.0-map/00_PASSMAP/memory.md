GXB continuation state — Pass100.0
Canonical backend: gxb-backend-v0.12.4-pass100.0.zip SHA256 ec255d1ed656fe72414972d7c0d113daed8725c0022ad294f050cb217a88bfd5 — STATIC/SELFTEST/FRESH-EXTRACTION ACCEPTED, CLIENT RUNTIME PENDING.
Canonical source: all-assest-rechecked.zip SHA256 89f0f830508b92e5fff6ad53c6a9dae961a14042dbfdf5649008efb8353f5608; effective src_64 4,370 files.
Canonical database: GAME_KNOWLEDGE_CATALOG_PASS100_0.sqlite (530 project tables, integrity ok).
Pass99 is RUNTIME ACCEPTED from debug SHA256 29b1295c0d5cee4daf4fba9b7afa4583c0d488cf91f446724e314a8625b4b443.
OTA resource 1.631.4: 128 cumulative overrides, all 126 Pass99 overrides byte-exact plus AddEnergy.lua src32/src64.
MID97 patched request: expected_buy_energy_times + energy_day_id + p100-energy-{day}-{expected}-{xyd.generateUUID()}. Backend.lua retries same params, preserving op id.
Server MID97 one UoW: EconomyLedger Crystal debit + TemporalPolicyService Energy +120 + buy_energy_times increment + durable receipt. VIP num_energy + Monthly Privilege +4. Energy >=500 blocks starting a new purchase; 499 may end at619. Receipt replay occurs before day/counter guards. Empty/unpatched MID97 fails closed.
DailyResetCoordinator remains sole 05:00 GMT+8 buy_energy_times reset owner.
Immediate gate: OTA 1.631.4 + MID97 real-client smoke/reconciliation. Then RandomOutcomeService, unchanged-probability Summon migration, Girls/Equipment closure, Campaign repeat RNG/MID117.
