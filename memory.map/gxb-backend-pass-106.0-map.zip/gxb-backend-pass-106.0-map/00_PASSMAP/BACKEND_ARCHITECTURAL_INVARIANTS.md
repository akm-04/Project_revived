# Backend Architectural Invariants — Pass62

These are **Phase 2 hard constraints**, not implementation suggestions. Pass62 revalidated them against the canonical Pass42.14 backend and the unchanged effective `src_64`.

## 1. Preserve the three transport planes

- **SDK/native HTTP:** port **5000**.
- **Engine/game HTTP API:** port **9000**, current private-backend base `/api/v1`.
- **Chat TCP compatibility plane:** port **9100**.

Do not collapse these ports into one listener merely because a new architecture could technically multiplex them. The client and current compatibility backend treat them as distinct planes.

## 2. Preserve SDK session identity shape

Current backend SDK identity deliberately returns lowercase identity fields while also preserving uppercase aliases **`UID` / `SID` / `UNAME` / `TOKEN`**. Session cookies remain **`QQWUID` / `QQWSID` / `QQWUNAME` / `QQWTOKEN`**. Historical native-SDK evidence shows the uppercase/cookie forms are compatibility-significant.

SDK account UID/SID/session identity is distinct from the in-game `player_id`. Do not conflate those identifiers.

## 3. MID192 is HTTP room discovery, not a TCP-chat MID

Effective source declares `LOAD_CHAT_ROOM_INFO = 192`. `Backend:request()` sends only chat-bit-range MIDs to the TCP path; MID192 falls through ordinary web/HTTP request handling and returns `host`, `port`, and `room_id`, after which the client opens the socket.

The chat predicate is effectively `(mid & 0x9000) == 0x8000`. The GM/debug plane uses `(mid & 0x9000) == 0x9000`.

Therefore:
- keep **MID192** on engine HTTP;
- advertise the chat host/port from its response;
- keep chat-bit MIDs on the TCP/chat plane;
- do not expose chat-bit MIDs as ordinary Flask/API handlers unless intentionally building a diagnostic compatibility surface.

## 4. Preserve source precedence

Current Lua authority remains:

`downloaded-assets/output/src_64/` **overrides** `app-assets/output/assets/src_64/` path-by-path.

Pass62 reconstructed the source directly from canonical assets and matched all **4,370** Pass57 effective-source hashes exactly: **62 downloaded winners + 4,308 app winners**.

## 5. Phase 2 interpretation

These invariants constrain architecture boundaries. They do not require retaining the current monolithic internal implementation. Phase 2 may modularize aggressively as long as the externally observed transport/session semantics remain compatible.
