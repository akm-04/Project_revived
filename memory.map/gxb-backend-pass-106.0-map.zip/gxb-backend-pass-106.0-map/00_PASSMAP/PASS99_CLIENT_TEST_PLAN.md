# Pass99.0 Client Test Plan

1. Cold-start UID `13371337`; verify Raid Ticket ~900, Fries/Kanto/Tonkatsu ~90 each, and all twelve MID87 magic consumables ~900 each.
2. Run 1× ITEM_SWEEP: Energy decreases by source `campaign.energy_cost`, Raid Ticket by 1, rewards persist after restart.
3. Run 10× ITEM_SWEEP: Energy decreases by `energy_cost * 10`, Raid Tickets by10; insufficient input must leave no partial mutation.
4. If UI offers CRYSTAL_SWEEP, verify Energy cost plus exactly one Crystal per sweep.
5. Regression-check MID114 battle still spends source Energy.
6. Use seeded MID87 items for magic_energy, magic_dust, magic_liquid; verify exact debit/credit and persistence.
7. Consume seeded items, restart, confirm seed does not replenish them.
8. MID97 remains intentionally unsupported in Pass99.

After clean smoke, reconcile Pass99; next safest work is a minimal MID97 operation-ID preservation bridge design.
