# Pass98 Index

- `00_PASSMAP/PASS98_TECHNICAL_REPORT.md` — implementation/reconciliation report.
- `00_PASSMAP/PASS98_IMPLEMENTATION_FACTS.json` — bounded backend changes and invariants.
- `00_PASSMAP/PASS98_CONSUMABLE_EFFECT_CATALOG.json` — source-derived catalog authority.
- `00_PASSMAP/PASS98_MID27_ENERGY_CONSUMABLES.json` — Energy consumable contract.
- `00_PASSMAP/PASS98_MID87_MAGIC_CONSUMABLES.json` — magic-resource item contract.
- `00_PASSMAP/PASS98_MID1404_MAPPING_REPAIR.json` — complete Inscription item mapping.
- `00_PASSMAP/PASS98_SAFETY_BOUNDARIES.json` — MID134/MID241 fail-closed decisions.
- `00_PASSMAP/PASS98_SRC64_FEEDBACK_LOOP.json` — mandatory source evidence.
- `00_PASSMAP/PASS98_VALIDATION.json` — static/regression/fresh-extraction gates.
- `00_PASSMAP/PASS98_CLIENT_TEST_PLAN.md` — runtime acceptance smoke.
- `00_PASSMAP/PASS98_PHASED_ROADMAP.json` — continuation sequence.
- `00_PASSMAP/databases/GAME_KNOWLEDGE_CATALOG_PASS98_0.sqlite` — current machine database.

Pass98 backend: v0.12.2. Runtime acceptance pending client smoke.
