# Pass 80.0 — Diagnostic & Correction Research Report

## Status
Research complete. **No Python backend files were modified.** The frozen backend remains `gxb-backend-v0.9.9-pass79.0.zip` SHA-256 `9ba93e85337366dddc940a94ed2c9d849f79eae2a53eb57c4cec91ebc2ed6dd9`.

## Runtime reconstruction
The supplied `debug.zip` (SHA-256 `3f3d5ca15f843865741142a7ade10a7813f20d23f142beb603ec713e6f409eb6`) confirms a partial-successful daily rollover. Before the jump, MID29 Quick Enchant consume ID 2 succeeded once. Two successful Super MID114 results for campaign 1300022 each returned `daily_limit=3`. After the approximately +24h jump and client restart, bootstrap showed recovered temporal resources and reset `buy_skill_times`; MID99 then used the first-day purchase price again. However MID28 still returned `buy_times=0|1|...`, proving the server-visible Quick Enchant consume state remained used.

## Bug 1 — Quick Enchant
**Root cause: persistence ownership, not clock math.** `QuickEnchantDailyResetParticipant` correctly sets `daily_consume_state.counts={}`. `JsonPlayerDatabase.merge_preserving_extensions()` recursively merges dictionaries so unknown nested keys survive. An authoritative empty dictionary therefore cannot delete the preexisting `counts["2"] = 1`; persistence reconstructs it. A direct frozen-code reproduction yields existing `{"2":1}` + canonical `{}` -> merged `{"2":1}`. Scalar `buy_skill_times=0` replaces cleanly, explaining the observed split.

The same mechanism is a latent risk for `mission_state.daily_cache`, which Pass79 also clears to an empty dictionary. The correction should therefore be a path-aware canonical replacement policy, not a Quick-Enchant-specific delete hack.

## Bug 2 — Super Campaign MID114
**Root cause: missing settlement mutation.** `WorldRepository._commit_fight_result_mutation()` performs canonical battle validation, stars/rewards/unlocks/energy settlement, and returns touched campaign rows, but never decrements the Super row's `daily_limit`. The debug log proves this twice: successful campaign_type=2 results return 3 both times.

The effective Lua source makes the ownership contract clear: `SelfPlayer.lua`, `BattleCreate.lua`, and `BattleCreateReport.lua` replace local `worldMaps_[campaign_id].dailyLimit` from the server response. `NewMapDetailWindow.lua` displays that number as remaining attempts, shows `/3` for Super, gates battle when it reaches zero, and exposes MID116 reset only at exhaustion. There is no normal MID114 local decrement. Thus `campaign.lua`/Pass75 `daily_limit=3` is the daily reset baseline, while persisted Super `world_map` `daily_limit` is the mutable remaining count.

One semantic remains intentionally unresolved: the effective client source does not conclusively prove whether a **defeat** consumes an attempt. The supplied smoke proves the successful-clear path. That distinction must not be guessed.

## Client timer and Tasks
Tasks/Activities remain intentionally unimplemented/stubbed. MID2736 returned empty lists, and the only decoded Lua error is `AlertAwardWindow.lua:337` reached through the Task claim path; its timestamp precedes the 24-hour jump. Separately, `ServerTime.lua` advances an internal `serverTime_` using scheduler delta and dispatches the 05:00 daily fanout only when seconds-of-day equals exactly `18001`. A discontinuous whole-OS time jump is therefore an adversarial client test, not a faithful substitute for naturally crossing the source boundary.

## Correction architecture for the next pass
1. Introduce path-aware canonical-replacement semantics in JSON persistence. At minimum `player.domains.daily_consume_state.counts` must replace rather than recursively merge; audit `player.lobby.mission_state.daily_cache` and any other reset-owned authoritative container. Preserve unrelated extension dictionaries.
2. On the first canonical **successful** Super MID114 settlement, require remaining `daily_limit > 0`, decrement exactly once, persist it, and return the decremented campaign row. Use the existing committed receipt to keep duplicate MID114 retries idempotent. Add a fail-closed MID113/start guard at zero.
3. Keep `reset_count` untouched by ordinary fights. Pass79 05:00 rollover continues restoring source max and `reset_count=0`. MID116 remains out of scope.
4. Resolve defeat-consumption semantics before applying any decrement to star=0.
5. Re-run persistence, retry, boundary, Normal/Super campaign, and Pass68–79 regressions, then client smoke.

## Gate
Pass80 authorizes **no implementation**. The recommended next pass is a bounded Pass81 correction of only these Pass79 defects. MID116/117/118 and Task/Activities remain halted.
