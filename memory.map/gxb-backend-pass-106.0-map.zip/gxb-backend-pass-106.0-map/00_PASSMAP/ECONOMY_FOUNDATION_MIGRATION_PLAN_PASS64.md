# Economy Foundation Migration Plan — Pass64

**Planning only. No backend implementation is authorized in this pass.**

## Decision

Prioritize Global Economy synchronization + Backpack + Hero/Girls Gear + progression before expanding Campaign/Workshop/Vows/Pet/Store implementation. Use an **incremental strangler migration** around the current `PlayerState`; do not rewrite the backend or persistence layer first.

## Current reality

- Canonical Phase1 catalog defines **47** global economy synchronization keys.
- `PlayerState.player_info_payload()` directly represents **44/47** of them; missing are control envelopes `daily_updates`/`updates` and intentionally suppressed `invitation`.
- `EconomyRepository` has only **5** mutation/progression fields.
- `RewardTransactionService` exposes only **4** economy grant categories.
- `ResponseProjector` automatically reconciles only **5** fields.
- Of the 47 canonical fields, `global_economy_fields` classifies **30** as `scalar_ledger`; the rest require typed regeneration/progression/entitlement/mode/reset/social semantics.

The storage shape is therefore not the main migration blocker. Ownership/routing is.

## Non-negotiable semantic split

`GlobalEconomyProjection` is the wire synchronization plane. It may read many owners.

`EconomyLedger` owns only descriptors that actually belong to scalar balance/material semantics. It must not become owner of `lev`, `exp`, `vip`, `charge`, Conquest state, reset envelopes, or unresolved `point` merely because the client places them in `economy_`.

`ResourceRegistry` is the routing authority and is populated from the frozen `global_economy_fields` catalog.

## Incremental sequence

### E0 — Characterize without mutation
Load the 47-field ResourceRegistry from canonical catalog; assert current PlayerState wire coverage and field ownership.

**Preserves:** No runtime behavior changes.  
**Gate:** 47 descriptors classified; unknown/conflicting fields fail closed.

### E1 — Introduce compatibility economy facade
Keep EconomyRepository public methods but delegate mana/crystal/energy to typed EconomyLedger; move exp/lev delegation to PlayerProgressionService.

**Preserves:** Existing handler/repository call sites.  
**Gate:** Pass42.14 characterization tests unchanged; no duplicate owner.

### E2 — Generalize scalar ledger
Add keyed mutations for the 30 scalar_ledger descriptors while persisting the same PlayerState fields.

**Preserves:** JSON storage and bootstrap payload.  
**Gate:** Every scalar key has one owner and insufficient-balance policy; no universal caps.

### E3 — Upgrade settlement
Let MutationPlan settle typed scalar debits/credits plus StackInventory changes and Hero/entity mutations inside UoW.

**Preserves:** RewardPlan adapter remains.  
**Gate:** No durable command can partially spend/grant across owners.

### E4 — Temporalize regenerating fields
Adapt Energy/Spirit/Skill/Invitation semantics to TemporalPolicy using persisted anchors; keep dormant/version-drift rules explicit.

**Preserves:** Existing PlayerState amount/time fields.  
**Gate:** Offline catch-up and natural-cap behavior match Pass61; no device clock.

### E5 — Projection migration
Project economy_ from committed mutation/semantic journal; retain legacy five-field diff as temporary compatibility fallback.

**Preserves:** Wire payload shape.  
**Gate:** All touched global fields reconcile cumulatively; reset envelopes remain explicit.

### E6 — Gear/progression dependency migration
Move Hero promotion/equip/compose costs and grants onto EconomyLedger/StackInventory/Settlement.

**Preserves:** Existing Hero state representation and MIDs.  
**Gate:** Gear/progression commands commit atomically and preserve stats/state.

### E7 — Dependent domain onboarding
Only after E0-E6, attach Campaign, Workshop, Vows, Pet and Store one at a time.

**Preserves:** Frozen Phase1 domain contracts.  
**Gate:** Each new domain uses no direct PlayerState economy/inventory mutation.

## Dependency rule

No newly implemented Campaign/Workshop/Vows/Pet/Store mutation may write a global economy field or Backpack quantity directly. Until its canonical owner is migrated, the domain remains on the legacy adapter or deferred.

## Why Hero/Gear follows immediately

Hero promotion/equipment is the first large consumer that simultaneously touches Mana, Backpack recipes, Hero progression and combat-relevant persistent state. Migrating it after the resource backbone provides an early proof that the architecture can preserve the exact player-stat/equipment invariants Phase1 recovered.
