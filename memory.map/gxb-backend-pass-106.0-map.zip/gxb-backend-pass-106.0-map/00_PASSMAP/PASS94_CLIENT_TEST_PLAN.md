# Pass94 Client Runtime Test Plan

Goal: runtime-accept only the Player EXP/level ownership migration. Do not use this smoke to validate RNG or MID97.

1. Start from a fresh or low-level account and capture MID1 `exp`, `lev`, `energy`, and `max_energy`.
2. Clear a source-known Normal Campaign stage and record the exact Campaign Energy debit and cumulative EXP award.
3. If the award crosses one or more source `total_exp` thresholds, verify level increments for every threshold and the sum of each crossed level's `award_energy`.
4. Verify current Energy is allowed above the ordinary regeneration cap after level-up, while `max_energy` matches the resulting level's source row.
5. Retry/reload only in ways already supported by Campaign idempotency and confirm no duplicate EXP/Energy grant.
6. Cold restart server/client and verify `exp`, `lev`, current Energy, `max_energy`, and Function state persist.
7. Clear one additional Campaign stage to prove progression continues from cumulative persisted EXP.

Canonical source example: from level 1, cumulative EXP 18 crosses thresholds 6/12/18, reaches level 4, and awards 6+6+6 = 18 Energy. If a Campaign clear costs 6 Energy and starts at 60, the expected current Energy after settlement is 72. Use actual captured stage/account values as authority.

Acceptance: no Lua error, correct cumulative values, exactly-once settlement, restart persistence. Clean smoke -> formal Pass94 runtime acceptance + reconciliation. Bug -> bounded Pass94 correction against effective `src_64` only.
