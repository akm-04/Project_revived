# Pass65 — Core State & Economy Contract Freeze

**Status: FINAL canonical.**  
**Phase:** Phase 2 Architecture Planning.  
**Implementation:** prohibited; the Pass42.14 backend is not modified.

## Executive decision

Pass65 freezes the contracts needed to implement the incremental economy/state strangler later without reinterpreting Phase1 evidence. The key decision remains: **`economy_` is a synchronization/projection plane, not one universal persistence owner.** `ResourceRegistry` routes each of its 47 keys to a semantic owner and policy.

The target runtime flow is:

`compatibility adapter -> RequestContext -> domain command -> MutationPlan -> Reward/Mutation Settlement -> UnitOfWork -> logical owners -> one durable commit -> committed journal -> ResponseProjector`

The current `PlayerState`/JSON storage shape remains legal as the initial physical commit unit. Pass65 changes no Python code and requires no flag-day persistence rewrite.

## ResourceRegistry — exact descriptor contract

`ResourceRegistry` is immutable metadata. It stores **zero balances**. Each descriptor freezes: wire key, current client attribute, semantic/domain classification, target owner service, current storage locator, mutation capability, timer/reset/cap policy, response projection strategy, evidence class, migration readiness, and fail-closed behavior.

The registry contains exactly **47 unique descriptors**. Phase1's adapter distribution remains intact: **30 scalar-ledger**, **4 regenerating**, 2 player-progression, 2 recharge/VIP entitlement, 3 Conquest mode-state, 2 daily-reset envelope, and one each for social resource, mode-entry token, progress metric, and unresolved metric.

Important non-equivalences are contractually explicit:

- `mana`/`crystal` and the other fungible scalar balances use `EconomyLedger`.
- `energy`, `spirit_energy`, `skill_point`, and `invitation` must materialize elapsed server-time recovery before mutation. Natural caps are not automatically hard holding caps.
- `exp` and `lev` belong to `PlayerProgressionService`.
- `charge` and `vip` belong to `CommerceEntitlementService` and cannot be spent as currencies.
- `conquer_*` fields belong to the Conquest aggregate.
- `daily_updates`/nested `updates` are control envelopes only.
- `glue` remains a scalar crafting resource but carries its proven 05:00 GMT+8 floor/top-up policy; 100 is not a clamp and the 300 purchase gate is not a universal hard maximum.
- `invitation` retains its frozen source-drift classification and compatibility suppression until Arena/PvP is deliberately migrated.
- unresolved `point` is `FAIL_CLOSED`: no generic credit/debit and no generic response projection.

The full 47-row contract is machine-readable in `RESOURCE_REGISTRY_SCHEMA_PASS65.json` and table `resource_registry_pass65`.

## MutationPlan

`MutationPlan` is a declarative, immutable statement of a proposed durable command. It is not a repository and performs no mutation itself. It contains a traceable origin, bound actor, expected logical state version, explicit operation-specific idempotency policy, typed preconditions, typed mutation operations, and explicit semantic events.

The frozen leaf operation families are: `RESOURCE`, `STACK`, `ENTITY`, `GENERATED_INSTANCE`, `TEMPORAL`, `COUNTER`, `FUNCTION`, and `RECEIPT`. Arbitrary `PlayerState` dictionary patches are not a supported mutation operation.

All debits and preconditions are validated before a durable commit. Domain code may authorize *why* Mana should be spent or a Hero should evolve; it cannot bypass the registered leaf owner to mutate unrelated state.

## MutationResult and semantic journal

A `MutationResult` exists only for committed, replayed, or defined no-op outcomes. It includes before/after logical versions, authoritative commit time, a committed semantic journal, optional owner-version facts, and an idempotency receipt reference when applicable.

The journal is not an audit-log replacement. It is the request-scoped semantic mutation record needed for deterministic response projection. Resource entries carry both signed delta where meaningful **and canonical post-balance**; the latter is what `economy_` projects.

Staged journal entries are discarded on rollback and cannot leak to the client.

## UnitOfWork contract

The upgraded UoW retains the useful Pass32.6 behavior but freezes stronger semantics:

1. One durable command has exactly one outer commit boundary.
2. Nested service/repository calls join it and cannot independently persist.
3. Validation failure, domain exception, or persistence failure rolls back all staged state, journal and receipts.
4. The current whole-`PlayerState` snapshot can remain the rollback mechanism initially. Physical mechanism may change later without changing the semantic contract.
5. Idempotency receipts/claim markers commit atomically with the corresponding mutation.
6. Idempotency is operation-specific. Universal payload-hash dedupe is forbidden because identical repeat purchases/summons may both be legitimate.
7. A logical `state_version` increments once per successful outer durable commit. Pass65 freezes this target contract; Pass66 should freeze its physical persistence/schema migration.
8. Authoritative time comes from `ServerClock` captured in the request context.

## ResponseProjector contract

`ResponseProjector` is read-only. Its primary input becomes the **committed** MutationResult journal plus canonical post-commit snapshots.

For ordinary global-resource mutations, it emits only touched/explicit fields and uses cumulative post-commit values: `economy_.mana = current_mana`, never `mana_delta`. It must not manufacture a 47-key zero-filled payload.

`daily_updates` remains a separately staged server-authored reset/control envelope. Inventory awards and aggregate deltas remain their proper protocol/domain channels instead of being disguised as economy fields. `new_funcs_` comes from committed function-state semantics.

During incremental migration the old five-field before/after projector may remain as a fallback for not-yet-migrated fields. **Committed journal semantics win on collision.**

## Idempotency freeze

Four modes are frozen:

- `NONE` — repeatable commands without a stable replay key.
- `REQUEST_KEY` — protocol provides a stable operation identity.
- `DOMAIN_RECEIPT` — domain owns a durable transaction/claim receipt.
- `CONTENT_CLAIM` — one-shot persisted claimable state itself proves whether settlement already occurred.

No generic payload hash is allowed to turn repeatable purchases, summons, or upgrades into accidental replays.

## Characterization gates

Pass65 defines **26 mandatory gates** covering the 47-key registry, typed plan semantics, UoW rollback/journal/idempotency, cumulative response projection, compatibility invariants and no-storage-rewrite migration. These gates are implementation acceptance criteria for the later Phase3 foundation work; they are not Python tests written in this pass.

## What this deliberately does not freeze yet

Pass65 does **not** choose a new database engine, split `PlayerState` into physical tables, or add a persisted state-version field. It freezes the logical contracts that the next Phase2 persistence/schema pass must realize safely while preserving JSON compatibility.

It also does not onboard Campaign, Workshop, Vows, Pet, Store, PvP or events. Those domains remain consumers of this future foundation.

## Recommended next Phase2 pass

**Pass66 — Persistence / State-Slice Schema Migration Contract.** Freeze physical slice versions, `state_version`/receipt persistence, generated-instance storage seam, JSON backward compatibility and migration/rollback procedures—still without implementation code.
