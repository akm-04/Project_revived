# Pass102.0 — Mutation Safety Firewall Exploration & Architecture

## Runtime reconciliation
Pass100 MID97 is now RUNTIME ACCEPTED from the supplied debug smoke. Requests carry OTA `energy_op_id`, `energy_day_id`, and expected counters; observed successful counters advanced 0→1→2→3→4 with source ordinal charging and persisted state across reconnect/cold-start behavior. The user's VIP0→VIP1 limit and full-Energy blocking observations are consistent with the trace and Pass100 contract.

## Core finding
The firewall is not an EconomyLedger feature. It is a **dispatcher contract-safety layer** protecting all authoritative mutations—economy, entity, social, progression, session, and domain state—from legacy compatibility handlers that return OK without settlement.

`src_64` proves that many success callbacks mutate the client immediately. Examples: Shop adds purchased items/removes stone; Battle Pass advances point/claim state; SelfPlayer expands hero capacity or deletes a hero; Pet callbacks consume items and mutate progression/equipment; Market checkout consumes coupon items; GET_AWAKE_ITEM removes an awake item; World Boss sweep decrements attempts; Guild drinks mutate counters; dynamic-card commands alter persistent hero state.

## Three classes
1. **QUERY / bootstrap read model** — safe to return source-shaped empty/default structures when no authoritative mutation is implied.
2. **TELEMETRY/READ ACK** — safe OK only when callback has no state transition.
3. **MUTATION / SESSION COMMAND** — may return OK only if the backend has a declared durable owner/session authority. Otherwise it must fail closed.

Response shape is not a valid classifier: `{}` can be a harmless telemetry response or a destructive fake success. Handler names are also insufficient. Source behavior is the authority.

## Tier A: proven dangerous false-success families
The Pass102 machine matrix records source-proven local mutation-on-OK routes across Shop, Market checkout, Battle Pass, hero capacity/dismissal, dynamic cards, Pet Practice/lifecycle/campaign, Guild drinks, GET_AWAKE_ITEM, housing, Arena-mode ticket purchase, World Boss sweep and competitive progression.

These are the first quarantine set once implementation is authorized.

## Tier B: server-mutation/session commands needing final contract audit
A second set includes shop refresh/market cart commands, Arena fight/ticket/defense flows, mission/pet-awake commands, social relationship commands, guild rent/chapter/reward commands, March/World Boss commands, and several battle-result ACK routes. They are not safe to leave as synthetic success, but some are multi-step/session protocols where blindly converting every MID to a generic error could break navigation or battle teardown. Their exact request/response/error boundary should be frozen before code.

## Proposed modular architecture
Introduce a `MutationContractRegistry` keyed by MID/name. Each route declares source effect class, risk tier, required capability, implementation state, fallback policy and response contract. The dispatcher invokes a `MutationSafetyFirewall` after MID resolution but before the handler.

Handlers declare capabilities such as `READ_ONLY_COMPAT`, `TELEMETRY_ACK`, `DURABLE_MUTATION`, `EXPLICIT_FAIL_CLOSED`, or `SESSION_AUTHORITY`. If a source mutation/session contract is bound to a synthetic compatibility capability, the firewall blocks it before the old handler executes.

Add a startup/static validator: every routed MID classified as mutating must be either durably owned, explicitly fail-closed, or a separately audited session authority. Future route additions without a contract should fail validation. This makes the firewall self-healing rather than another hand-written blacklist.

## Why no implementation yet
I am **not ready to implement the full firewall after Pass102**, by design. Tier A is sufficiently proven, but Tier B contains battle/session and event-driven flows whose correct fail-closed point needs one more source-contract pass. The next architecture pass should finish that matrix, choose the canonical blocked-operation error contract, and define regression tests protecting login/navigation from accidental quarantine.

After that design freeze, firewall implementation should be small and mechanical. RandomOutcomeService remains behind it.
