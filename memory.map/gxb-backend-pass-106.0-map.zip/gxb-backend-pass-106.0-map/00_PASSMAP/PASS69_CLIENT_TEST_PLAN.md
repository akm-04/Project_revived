# Pass69 Client Runtime Test Plan

Use the existing account/server data and existing client app data. **Do not clear player state unless a separate corruption is being diagnosed.** Reuse the same `local_assets/res` workflow used for Pass68/68.1.

1. Start `gxb-backend-v0.9.1-pass69.0` and confirm normal boot/login/lobby.
2. Open Girls and perform one inexpensive action that debits Mana (for example a skill upgrade if available). Confirm the UI shows the correct remaining cumulative Mana.
3. Perform one currently working summon path (Small, paid Medium, or Medium Free if it is ready). Confirm rewards appear once and balances are not double-adjusted.
4. Run at least one Campaign battle/reward path. Confirm scalar rewards and Backpack items appear normally.
5. Open Backpack/Girls after the reward and confirm item quantities remain consistent.
6. If convenient, perform another operation that changes Crystal or another already-wired scalar balance.
7. Restart the backend/client and log in again. Confirm Mana/Crystal/Backpack state persisted and no reward duplicated or vanished.
8. Record any odd UI/error in `server.txt`; profile-card MID1829/PersonDisplayWindow remains unrelated known noise unless behavior materially changed.
9. Return the new `debug.zip` before Pass70 begins.

Acceptance targets: zero Python traceback, zero HTTP 5xx, no missing/doubled reward, no incorrect scalar debit, no Backpack count regression, and normal restart persistence.
