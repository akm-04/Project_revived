# Pass103.0 Mutation Safety Firewall — Final Architecture

## State
Pass100 MID97 is runtime accepted. Backend v0.12.4-pass100.0 remains frozen. Pass103 changes machine-memory only.

## Final Tier-B resolution
The 49 Pass102 Tier-B MIDs are now fully classified. Ordinary shop/market, mission, social, guild, Arena state, March reward/state and World Boss purchase commands are authoritative server mutations and must fail closed unless durably owned. Arena PRE/FIGHT_PRE plus START/FIGHT, March START_FIGHT and World Boss START_FIGHT are explicit session preflight/start boundaries and should be quarantined before entering battle. Battle result MIDs are terminal settlements and receive separate family-specific policy.

## Canonical generic block
A JSON error over HTTP200 is unsafe: Backend.lua still invokes the callback with xyd.error.OK. The firewall therefore requires a transport-aware result capable of HTTP 409 with `{error_code=1,msg=mutation_contract_unimplemented}` and no `error_msg`. Completed non-200 responses return xyd.error.ERROR, remove LoadingProxy and do not enter the network-failure retry prompt.

## Session terminal rule
Do not generic-block terminal battle results. Source explicitly permits errorIdFightExist=30005 as completion for ARENA_FIGHT_RESULT, TREASURE_SAVE_BATTLE_RESULT, MARCH_FIGHT_RESULT and WORLD_BOSS_FIGHT_RESULT. That drain is allowlisted only and must be payload-tested before activation. REARENA_END_FIGHT and REGION_FIGHT_RESULT do not have equivalent recovered proof; block new unsupported sessions upstream and do not invent 30005 for them.

## Implementation readiness
No additional architecture-only pass is required before Phase1. Pass104 may implement MutationContractRegistry, a transport-aware firewall decision, startup/static validation and non-session quarantine. Session preflight/start quarantine may follow in the same bounded pass or a second implementation slice; terminal settlement/drain remains explicit per-family policy.

## Regression
The Pass103 regression matrix protects all runtime-accepted foundations and specifically asserts HTTP200+error_code1 is forbidden for firewall blocks, query/navigation stubs remain navigable, session starts fail before BattleLoading, and only source-proven terminal families may use 30005.
