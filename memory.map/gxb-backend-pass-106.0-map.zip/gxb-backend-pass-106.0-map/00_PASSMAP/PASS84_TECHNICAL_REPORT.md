# Pass 84.0 — Self-Healing & Architectural Reality Check

## Runtime acceptance
Pass83 is runtime accepted for its scoped goals. `server.txt` line 1102 shows MID1 materializing source day 20688 -> 20690 with all four DailyReset participants before bootstrap. MID1 then returns `buy_skill_times=0`, `skill_point=80`, `skill_time=0`, and Super campaign 1300022 at `daily_limit=3/reset_count=0`. MID28 later returns all-zero daily consume counts and MID29 consume_id=2 succeeds. No backend Traceback/ERROR/Exception/CRITICAL line was found in the supplied server log.

## Reality check
Daily Reset and temporal recovery are now stable foundations. The remaining risk is no longer the clock; it is ownership consistency above that clock.

### Global Economy
The 47-key `economy_` contract is correctly classified as heterogeneous. The backend has a strong ResourceRegistry/MutationSettlement foundation, but the strangler migration is incomplete: `EconomyRepository` still advertises itself as a legacy five-field facade; `RewardTransactionService` still special-cases player EXP through that facade; and Commerce/VIP has registry metadata without a canonical runtime owner. Keep metadata-only mode currencies fail-closed until their domains migrate.

### VIP / Commerce / Store
MID116's *purchased* Super reset is source-gated by VIP `num_elite` plus the Monthly Privilege bonus; the 05:00 restoration is not VIP-owned. The current established sandbox forcing VIP15 while `charge=0` is source-incoherent and already leaks into implemented Skill Point and SX summon policies. Normalize VIP/charge/privilege authority before MID116. A full Store implementation is not required first: Store has independent stock, buy-limit and scheduler semantics. Effective `shop_config.lua` also corrects prior memory: main Shop id=1 refreshes at 09:00, 12:00, 18:00 and 21:00, not merely 12/18/21.

### System-wide RNG
The user's proposed system RNG layer is the correct next infrastructure direction. Campaign repeat drops remain blocked because source gives pool topology but not the historical server sampler. Summon already has a separate random-source abstraction, while Campaign has another. Before adding Campaign RNG or hidden Gear samplers, introduce one request-scoped RandomOutcome/Entropy spine with domain namespaces, policy versioning, deterministic test providers, UoW integration and committed outcome receipts so retries never reroll. Domain policies must remain separate from entropy.

### Girls / Equipment
Girls Gear is still a multi-plane aggregate. The ordinary HeroEquipment repository explicitly covers only the early NormalHero path; advanced code intentionally fails closed on hidden random/instance algorithms. Do not expand that class into a universal owner. Split NormalGear/Fumo, Super enhancement, Practice, Inscription, Element Equipment, Horcrux instances and Stone Evolution behind shared UoW contracts. Add a unique-instance mutation family for `spirit_list`-style state and route Inscription/Practice/Horcrux random generation through the shared RNG spine.

### Campaign
Campaign state ownership is much healthier: MID113/114 session settlement, Super 3->2->1->0 consumption, idempotent receipt and 05:00 restore are accepted. Remaining debt is reward generation: repeat RNG is disabled, MID117 is therefore still blocked, and Super defeat attempt-consumption remains unresolved. MID118 is source-contract complete but intentionally deferred while core closure is prioritized.

## Recommended ordering
1. VIP/Commerce authority normalization (core correction, not full Store).
2. Global Economy strangler completion.
3. Shared RNG/outcome receipt infrastructure and migration of existing Summon RNG without changing behavior.
4. Girls/Equipment aggregate closure + unique-instance settlement + approved RNG policies.
5. Campaign reward closure (repeat RNG + defeat semantics), then reassess MID116/MID118/MID117.

Feature expansion remains paused.

## Memory compaction
Pass84 repairs stale authority pointers from Pass78/82, promotes a single Pass84 SQLite authority, and prunes the redundant Pass82 and Pass83 SQLite snapshots after a schema/row-count subsumption proof. Historical JSON/source evidence is retained as cold provenance. The current database has 329 non-system tables and `PRAGMA integrity_check = ok`.
