# Pass94 Index

- `00_PASSMAP/PASS94_TECHNICAL_REPORT.md` — human technical report.
- `00_PASSMAP/PASS94_IMPLEMENTATION_FACTS.json` — exact bounded backend changes.
- `00_PASSMAP/PASS94_SRC64_FEEDBACK_LOOP.json` — mandatory source proof.
- `00_PASSMAP/PASS94_GLOBAL_ECONOMY_CLOSURE.json` — ownership closure state.
- `00_PASSMAP/PASS94_VALIDATION.json` — static/regression validation.
- `00_PASSMAP/PASS94_CLIENT_TEST_PLAN.md` — immediate runtime gate.
- `00_PASSMAP/PASS94_PHASED_ROADMAP.json` — continuation sequence.
- `00_PASSMAP/databases/GAME_KNOWLEDGE_CATALOG_PASS94_0.sqlite` — current machine database.

Database project tables: 462; integrity: ok. Pass94 runtime acceptance is pending client smoke.
