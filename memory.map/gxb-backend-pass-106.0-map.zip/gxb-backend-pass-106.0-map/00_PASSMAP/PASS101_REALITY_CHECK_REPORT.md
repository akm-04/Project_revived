# Pass101.0 — Self-Healing and src_64 Reality Check

Backend unchanged: `gxb-backend-v0.12.4-pass100.0.zip` SHA-256 `ec255d1ed656fe72414972d7c0d113daed8725c0022ad294f050cb217a88bfd5`. Pass100 MID97 remains runtime pending.

## Reality verdict
The modular-monolith/UoW architecture remains the right direction. Global Economy work was foundational rather than scope drift: implemented verticals now share explicit scalar, stack, temporal, progression, VIP/commerce, daily-reset and transaction owners. Do not interpret this as every one of the 47 client economy keys being implemented; deferred mode currencies should migrate with their source domain.

## Critical new risk
The largest correctness risk is no longer the core economy spine. It is old explicitly-routed compatibility handlers that return synthetic success for source-side mutations without durable settlement. `Shop.lua` and `BattlePass.lua` prove that an OK can cause immediate local item/progression mutation. A dedicated mutation-safety firewall should therefore precede new RNG feature expansion.

## RNG roadmap correction
Shared RandomOutcomeService remains necessary. But repeatable paid Summon MID50/MID70 stock payloads have no operation token, while the current backend uses a short retry-window receipt heuristic. Summon migration must include an OTA per-click UUID identity bridge (same preservation pattern as Pass100) so committed outcomes are truly exactly-once.

## Revised sequence
0. Pass100 MID97 client smoke/reconciliation.
1. Mutation Safety Firewall / synthetic-OK quarantine.
2. RandomOutcomeService foundation.
3. Summon operation-identity OTA + unchanged-probability migration.
4. Generated/unique-instance settlement primitive.
5. Girls/Equipment closure by deterministic then random planes.
6. Campaign repeat rewards/MID117 RNG.
7. Parked domains remain fail-closed until implemented.

## Self-healing changes
Pass101 introduces `00_PASSMAP/HOT/` as the exclusive compact startup kernel. Historical pass files remain cold provenance; startup must not scan them. SQLite remains the accumulated canonical evidence bank.
