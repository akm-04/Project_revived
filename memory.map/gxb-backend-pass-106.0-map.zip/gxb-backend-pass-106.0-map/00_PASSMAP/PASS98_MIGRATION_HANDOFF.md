# Pass98.0 Migration Handoff

Canonical backend: `gxb-backend-v0.12.2-pass98.0.zip` SHA-256 `c66071c7807bc89ccd651eb492406556e412f16147be88efb6899e94d285e9db`. Status: static/self-test/fresh-extraction accepted, client runtime pending. Canonical source: `all-assest-rechecked.zip` SHA-256 `89f0f830508b92e5fff6ad53c6a9dae961a14042dbfdf5649008efb8353f5608`, effective src_64 4,370 files.

Read `READ_FIRST.md`, `MACHINE_BOOTSTRAP_PASS98_0.json`, `PASS98_LIVE_CHECKPOINT.json`, implementation/catalog/MID/safety records, `CURRENT_AUTHORITY_MAP.json`, `QUERY_ROUTER.json`, then `GAME_KNOWLEDGE_CATALOG_PASS98_0.sqlite`.

Immediate gate is Pass98 client smoke. Do not expand into MID97 or RNG until that smoke is reconciled. After clean acceptance, the strongest next QA-unblock candidate is a separately bounded MID97 paid-Energy slice; RandomOutcomeService remains required before random MID241 gifts and Campaign repeat RNG.

Permanent rule: every behavioral backend modification must be cross-checked against effective src_64 first.
