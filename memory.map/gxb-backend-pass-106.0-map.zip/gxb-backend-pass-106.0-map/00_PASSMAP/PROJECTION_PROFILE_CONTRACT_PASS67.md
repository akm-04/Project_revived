# Projection Profile Contract — Pass67

**Status: FROZEN.** The client does not expose one universal response schema. Projection is separated into (1) optional global web envelope and (2) MID/transport-specific domain profiles.

Rules:

1. `GlobalEnvelopeProjector` may emit only proven optional cross-cutting fields such as `economy_`, `new_funcs_`, `server_time`, `flag_`, `extra_drops_`, `act_item_change_`, and redmark/update fields when semantically triggered.
2. `ProjectionProfileRegistry` is keyed by protocol/transport operation. It whitelists exact domain body fields and whether the client locally reconciles inventory/state from them.
3. Never synthesize generic `awards` merely because the server granted an item; Store and PetCampaign show that doing so can double-apply client-local reconciliation.
4. `economy_` values are cumulative canonical post-commit values, not deltas. Absent keys remain absent.
5. Recharge is a transport-specific nested push profile (`params.params.*`, nested `economy`) and must not be forced into ordinary web-response shape.
6. Internal metadata (`state_version`, receipts, slice revisions) is never projected.
7. Journal facts are projection inputs; protocol shape remains owned by the compatibility adapter/profile.

Frozen profiles: **8**.
