# Pass70.1 — Focused Client Re-test Plan

**State:** STATIC_ACCEPTED / FOCUSED RUNTIME RE-SMOKE REQUIRED  
**Purpose:** close only the MID59 source-defined Mana-settlement defect found in the otherwise healthy Pass70.0 smoke.

Use `gxb-backend-v0.9.2-pass70.1.zip` with the existing accepted player/client state.

1. Login and enter the lobby normally.
2. Open Girls and perform **one fragment/scroll Girl summon** (MID59) for any not-yet-owned Girl with enough fragments.
3. Verify the Girl is created and the fragment count reconciles normally.
4. Verify Mana decreases by the exact `star.lua` price: 1★ 1,000; 2★ 50,000; 3★ 200,000; 4★ 500,000; 5★ 1,300,000.
5. Optional but useful: perform one paid Mana Vending Machine pull to confirm the unchanged MID50 projection path.
6. Close/reopen once if convenient and confirm the new Mana value persists.
7. Return the resulting `debug.zip`.

Acceptance evidence: MID59 response succeeds and includes cumulative post-commit `economy_.mana`; no duplicate fragment application; no fallback, traceback, nonzero engine error, or HTTP 5xx. Do not begin Temporal Resources until this focused gate is accepted.
