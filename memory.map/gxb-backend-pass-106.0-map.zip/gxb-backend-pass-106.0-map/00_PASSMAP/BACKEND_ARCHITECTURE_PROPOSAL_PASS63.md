# Backend Architecture Proposal — Pass63

**Phase:** Phase 2 — Architecture Planning.  
**Pass status:** planning baseline only; **no backend implementation code is authorized or changed**.  
**Canonical predecessor:** Pass62.0 Master Reality Check / Phase 1 closeout.

## Executive decision

Adopt a **compatibility-first modular monolith with ports/adapters and request-scoped atomic transactions**. The current client-visible transport/session invariants stay fixed, while the internal backend is decomposed into domain modules and a small shared kernel. This is intentionally *not* a microservice split: the current game is dominated by atomic per-player mutations, and introducing distributed transactions now would add risk without evidence-driven benefit. Late shared-world/PvP modules get explicit ports so they can grow without forcing the single-player core to be rewritten.

The backbone is designed so Workshop, Vows, Campaign, Pet, Store, Gacha, Missions and Evaluation modes attach to the same transaction/economy/inventory/time/reward seams **without sharing their domain rules**.

## 1. Architecture layers

### Compatibility edge
- **SDK/native HTTP 5000** adapter.
- **Engine/game HTTP 9000** MID dispatcher.
- **Chat TCP 9100** adapter; MID192 remains HTTP room discovery.
- Session/cookie/identity compatibility stays isolated here.

The edge converts wire requests into application commands and converts committed results through a `ResponseProjector`. It must not own game rules or directly mutate arbitrary PlayerState fields.

### Application layer
A request creates one `RequestContext / RequestServices` graph: actor/session/player binding, immutable catalog, server clock, UoW factory and domain services. Application use cases orchestrate commands but do not become canonical data owners.

### Shared kernel
The shared kernel is deliberately small:
1. `GameDataCatalog`
2. `UnitOfWork` / future `MultiEntityUnitOfWork`
3. `ResourceRegistry` + `EconomyLedger`
4. `InventoryService` for stacks
5. `GeneratedInstanceRepository` for non-stack instances/candidates
6. `RewardSettlementService / MutationPlan`
7. `OperationReceipt / IdempotencyService`
8. `ServerClock` + `TemporalPolicyService`
9. `RngPolicyProvider`
10. `BattleAuthorityAdapter` interface
11. `ResponseProjector`
12. synchronous progression/domain hooks

Shared code may expose interfaces used by domains, but it must never import specific Campaign/Pet/Vows/Workshop/Gacha/Event rules.

### Domain modules
Each domain owns its persistent aggregate/state machine and validates its own commands. Examples: `Campaign`, `Workshop`, `Pet`, `SuperPartner`, `Hero`, `Store`, `Gacha`, `Mission`, `Evaluation`, `Dorm`. Domains use shared leaf owners for economy/inventory/rewards/time/RNG rather than mutating other domains directly.

### Infrastructure
Infrastructure implements persistence, clock, policy configuration, catalog loading and protocol transport. Pass42.14's current PlayerState/MultiUserDatabase can remain the first persistence adapter during migration; Phase 2 does **not** require a flag-day database rewrite.

## 2. Core primitives

### GameDataCatalog
Retain the Pass32.5 concept, now backed by the much larger Pass62/63 master catalog. IDs are always resolved with namespace/context; arithmetic/prefix guesses remain diagnostic only. Source provenance is attached to compiled rows.

### ResourceRegistry + EconomyLedger
Do **not** create a currency-only service. Pass54/61 prove the global economy channel contains ordinary balances, regenerating resources, counters, progression fields and reset payloads. `ResourceRegistry` identifies the semantic policy for each field; `EconomyLedger` owns scalar mutations.

### Stack Inventory + Generated Instances
Backpack stack quantities stay in `InventoryService`. Horcrux-like generated items, pending Practice/Inscription candidates and other instance state live in dedicated instance repositories. This prevents the most damaging class of item-model conflation.

### Unit of Work
Every durable command stages all domain/economy/inventory/reward/receipt changes inside one UoW. No repository independently persists during an active UoW, and no success response is emitted before commit. The first implementation may still snapshot/commit the existing player blob; the boundary matters more than the storage technology.

### Settlement
Domain logic builds typed mutation/reward plans; a shared settlement service validates and applies leaf mutations through canonical owners. Reward display rows are response projections, not a second durable ledger. Domain-owned receipts provide idempotency.

### TemporalPolicyService
Pass61 rules out a universal `TimerService` with one reset algorithm. The service must expose explicit policy classes for rolling regeneration, rolling cooldown, game-day reset, subsystem week/cycle, start-duration job, absolute window, floor/top-up and usage counters. `ServerClock` owns time truth.

### RNG policy
`RngPolicyProvider(domain, operation, version)` is a seam, not a universal sampler. Recovered source rules, runtime-confirmed policies and `PRIVATE_SERVER_POLICY` implementations remain independently labeled. `rate`, `drop_rate`, `increase_rate` and `weight` are never normalized without domain proof.

### Battle authority
A `BattleAuthorityAdapter` lets a mode explicitly choose among:
- client simulation + server settlement,
- server-authored report playback,
- seeded/deterministic audit commit,
- or unsupported/fail-closed.

This lets Campaign, Illusion, Occult, Dodgeball and later PvP share an interface without pretending they share an authority model.

## 3. Domain attachment examples

### Campaign
`CampaignCommand -> ModeAggregate -> BattleAuthorityAdapter -> UoW -> cost/attempt policy -> campaign-specific RNG policy -> RewardSettlement -> Mission/Function progression hooks -> commit -> ResponseProjector`. Exact repeat-drop generation remains behind a scoped policy seam.

### Workshop
Start, cancel and claim are distinct commands on a `ProductionJob` state machine. Start commits inputs; time changes readiness; claim settles awards. Workbench and Cabin share job mechanics but use different input economies. Recycle is not a reverse compose operation; it owns regenerated energy and server/policy output generation.

### Vows
`SuperPartner` owns its persistent state. The summon use case reads the fixed Hero prerequisite roster, validates eligibility and creates the Vow through settlement/UoW. It must not consume prerequisite Girls unless new authoritative evidence explicitly proves that side effect. Star/equipment costs transact through Economy/Inventory.

### Pet
`Pet` is a full aggregate with progression, three-slot gear, Practice pending-candidate state and mission-awakening linkage. Pet-specific policies attach to common inventory/economy/reward seams without importing NormalHero Fumo semantics.

### Store and Gacha
Both spend resources and produce awards, but their selection policies remain domain-specific. Store owns stock/limits/refresh state; Gacha owns operation matrix, pity/hotspot state and its own RNG policy. They share settlement and receipts, not generation formulas.

## 4. Progression coupling

Mission progress, function announcements and similar same-request consequences should use **synchronous domain/progression hooks within the active UoW** when the client expects one atomic result. Noncanonical side effects (logging, metrics, optional notifications) may run after commit. This avoids both circular service dependencies and eventual-consistency bugs in core progression.

The reward service may mutate only leaf canonical owners; it never calls Mission/World orchestrators. Mission/domain hooks may invoke reward settlement, preserving dependency direction.

## 5. Persistence and migration doctrine

Phase 2 should use a **strangler migration**, not a rewrite. Keep runtime-confirmed Pass42.14 compatibility seams while moving one ownership boundary at a time behind the new interfaces. Existing `PlayerState` can remain the first storage representation, with repositories owning slices and schema versions.

Generated-instance stores, multi-entity UoW, ranking/season, guild/shared-world and mail/delivery are explicit ports so later features can be added without modifying the core contracts. Concrete shared-world implementation remains late priority.

## 6. Hard anti-patterns

- No giant `GameModeService`, `InstituteRepository`, `CurrencyService`, or universal item service.
- No handler-side arbitrary `player.economy[field] += x`.
- No independent repository saves inside a UoW.
- No response success before commit.
- No generated instances encoded as stack counts.
- No device-local time authority or universal reset calendar.
- No universal RNG interpretation.
- No event-specific rules in the shared kernel.
- No PvP/ranking dependencies inside core PvE modules.
- No conversion of unknown/private behavior into claimed recovered source truth.

## 7. Phase 2 status after Pass63

Pass63 freezes the **architecture baseline**, dependency direction and domain attachment model. It does **not** freeze concrete Python class signatures, database schema, migration code or deployment topology. The recommended next Phase 2 pass is a **Pass42.14 backend migration reality audit**: classify existing modules as RETAIN / WRAP / REFACTOR / REPLACE / DEFER, then deepen interface/command/result contracts before any Phase 3 coding authorization.
