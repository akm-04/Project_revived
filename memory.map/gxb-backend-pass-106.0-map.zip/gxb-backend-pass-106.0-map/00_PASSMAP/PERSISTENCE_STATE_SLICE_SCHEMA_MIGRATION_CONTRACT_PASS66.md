# Pass66 — Persistence & State-Slice Schema Migration Contract

**Status: FINAL canonical.**  
**Phase:** Phase 2 Architecture Planning closeout.  
**Implementation:** still prohibited in this pass; Pass42.14 backend is unchanged.

## Executive freeze

Pass66 freezes the physical persistence seam needed by the Pass65 mutation contracts without forcing a database rewrite. The first Phase3 foundation may continue to persist one human-readable per-player JSON document. Logical ownership is separated into slices, while the file remains one atomic commit unit.

The existing backend already provides the useful starting properties: same-directory temp writes + `os.replace`, request serialization under an `RLock`, legacy flat/nested JSON reads, new `PlayerState` fields falling through to `player.domains`, and whole-PlayerState UoW snapshot rollback. Pass66 keeps those strengths and specifies what must be added around them.

## 1. `state_version`

The authoritative logical commit version is stored inside player-owned state at `player.domains.persistence_state.state_version`; root `_meta` may mirror schema diagnostics but is not the concurrency authority. A legacy file with no persistence envelope reads as version **0**.

Exactly one successful outer durable **gameplay** command advances the version once. Read-only requests, failed validation, rollback, receipt replay, defined no-op, and schema-only migrations do not advance it. The first successful durable command on a legacy file therefore moves `0 -> 1`.

`MutationPlan.expected_state_version` is an optional optimistic precondition. A mismatch fails before any mutation, receipt or journal becomes durable. Current request locking already serializes the local backend, but the version is still required because it becomes the stable contract for future adapters, retries and storage engines.

## 2. Slice revisions versus schema versions

Pass66 distinguishes three concepts that must never be conflated:

- `state_version`: one global logical player commit version.
- `slice_revisions`: per-slice **mutation** revisions; each touched slice increments once in the successful outer commit.
- `slice_schema_versions`: per-slice **structural format** versions; these change only through explicit schema migrations.

The registry defines **20 logical slices**. They remain physically co-located initially. Economy scalar fields, temporal resources, Hero state, Backpack stacks, Campaign world state and the other existing data can keep their current JSON paths while ownership migrates behind repository/service interfaces.

## 3. Atomic receipts and claims

Idempotency receipts and one-shot claim markers are persisted in the same player document and the same atomic replace as the mutation they protect. A receipt is only durable in `COMMITTED` state.

Crash safety follows from that boundary: if the process dies before the replace, neither mutation nor receipt is authoritative. If it dies after the durable replace but before sending the response, both are already present; the retry reads the matching receipt and replays the frozen result without spending or granting twice.

Receipt identity is domain/operation-specific. A request fingerprint may detect an incompatible reuse of the same stable key, but it is **not** the idempotency identity and never becomes a universal payload-hash dedupe scheme.

There is no generic receipt TTL. Claim markers remain while the content identity can be retried. Receipt compaction is allowed only when a domain-specific rule proves replay safety.

Current scattered Mission, Campaign and Summon receipt patterns are migration inputs, not separate permanent receipt authorities. They may be adopted into this store domain by domain.

## 4. Generated instances

`GeneratedInstanceRepository` receives an additive slice at `player.domains.generated_instances`. It uses opaque backend-stable internal `instance_key` values, namespaced monotonic allocators, and typed domain payloads. Those internal keys are architecture choices and are never presented as recovered official IDs.

Generated objects are categorically separate from Backpack stack quantities. Horcrux-like owned generated gear and server-generated Practice/Inscription candidates use records with lifecycle state, provenance, owner reference and state-version stamps. Pending candidates survive reconnect/crash and must not reroll merely because the client inspects them again. Saving/cancelling/superseding a candidate is a domain mutation under the same UoW.

## 5. JSON compatibility

The current per-player JSON file remains the first Phase3 physical commit unit. New persistence metadata and generated instances begin under `player.domains`, which fits the existing serializer's “new PlayerState field” fallback and avoids a flag-day section rewrite.

The loader must continue accepting the currently supported nested, legacy-flat and `domains` layouts. Schema migrations are additive, named, monotonic and idempotent. A schema-only migration emits no gameplay journal and does not change `state_version`.

One weakness of the current serializer is now explicitly corrected by contract: arbitrary unknown JSON keys are not guaranteed to survive a deserialize/reserialize cycle merely because new `PlayerState` fields do. Phase3 migrations therefore must use merge-on-write/extension preservation or fail closed. **Unknown state may not be silently discarded.**

## 6. Durable write ordering

The target JSON adapter contract is: serialize complete player state -> write same-directory temp -> flush/fsync temp -> atomic replace -> fsync parent directory where supported -> only then publish committed journal/response.

The existing `.tmp + os.replace` behavior is retained as the core mechanism; fsync/durability barriers become explicit Phase3 acceptance requirements. The UoW still snapshots the whole in-memory PlayerState initially, so a persistence exception restores memory as well as withholding staged semantics.

## 7. Rollback fence

Logical economy-owner migration remains intentionally easy to reverse because E0-E6 keep the existing physical gameplay fields. No second copy becomes authoritative.

However, once receipt-backed commands start committing, an uncontrolled rollback to the old serializer is **forbidden**. The older binary does not understand the new persistence metadata and can drop it on its next save. That can erase replay/claim safety even while preserving balances.

Crossing this fence requires maintenance/read-only mode plus an explicit downgrade/export procedure. A downgrade preserves the **current** gameplay values, archives the new metadata, and blocks receipt-sensitive operations until the forward-capable binary is restored. An old pre-migration backup may recover corruption, but must never be copied over legitimate newer progress as a casual rollback.

## 8. Crash-window semantics

The crash matrix is frozen in `JSON_SCHEMA_MIGRATION_ROLLBACK_CONTRACT_PASS66.json`. The most important window is “commit durable, response not sent”: retry must replay from receipt/content-claim state, not repeat the mutation. Journal publication before persistence is forbidden.

## 9. Phase2 closeout

Pass63 froze the modular-monolith architecture, Pass64 froze the incremental migration path, Pass65 froze ResourceRegistry/MutationPlan/UoW/ResponseProjector semantics, and Pass66 now freezes the physical persistence seam, version/receipt/claim contracts, state-slice registry, generated-instance storage, migration compatibility and rollback procedure.

No unresolved **foundational** architecture contract remains that requires another Phase2 pass. Domain-specific hidden RNG, refund algorithms and late PvP/event semantics remain bounded policy/domain gaps and do not block foundation implementation.

Therefore **Phase 2 is COMPLETE** and the project is **READY FOR PHASE 3 IMPLEMENTATION when explicitly authorized by the user**. This Pass66 package does not itself authorize coding.

The first Phase3 work should be foundation-only: characterization -> additive persistence metadata -> upgraded UoW durable version/receipt/journal -> ResourceRegistry/Economy compatibility façade -> scalar ledger + StackInventory settlement -> journal ResponseProjector -> temporal resources -> Hero/Girls Gear -> dependent domains. Campaign/Workshop/Vows/Pet must not jump ahead of the foundation gates.
