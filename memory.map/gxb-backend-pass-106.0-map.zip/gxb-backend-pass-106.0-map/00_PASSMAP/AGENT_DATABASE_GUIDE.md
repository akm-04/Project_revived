# Pass106 Database Guide
Current DB: `00_PASSMAP/databases/GAME_KNOWLEDGE_CATALOG_PASS106_0.sqlite`; **554** project tables; integrity=ok. Query pass106_reality and pass106_runtime_reconciliation first.
