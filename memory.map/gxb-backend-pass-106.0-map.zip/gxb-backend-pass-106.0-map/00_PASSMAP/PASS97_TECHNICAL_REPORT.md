# Pass 97.0 — Consumables & Item Usage Targeted Research

Timestamp: 2026-08-23T12:35:00+06:00

## Executive result

Pass96 is **RUNTIME ACCEPTED** from the supplied QA smoke. Pass97 intentionally makes **no backend changes**. Canonical backend remains `gxb-backend-v0.12.1-pass96.0.zip` (`b6b0f7a9df9f408bddfca5cf84c31f3fbfa754cd021d25796496ce00dab3028c`).

Pass97 maps the consumable/item-use plane before any new implementation. The central findings are: MID27 already has the correct atomic Backpack-debit + TemporalPolicyService-credit shape but reads a stale generic item catalog; MID87 and MID134 have false-success hazards because the source client deletes submitted items on OK; MID1404 already grants source certificate currencies but has fourteen missing valid item mappings; and generic gift/chest use spans deterministic plus random semantics, so complete MID241 support remains downstream of RandomOutcomeService.

## Pass96 runtime acceptance

The supplied runtime evidence and user QA confirm the Pass96 cleanup. The legacy UID13371337 bootstrap projects `lev=100`, `exp=579615`, `max_lev=100`, and `max_energy=160`. Inventory normalization removed the old capacity/crafting blocker, and the Pass96 privilege gates behaved correctly. No Pass96 defect was found.

## MID27 Energy consumables

`SelfPlayer.useEnergyItem()` sends MID27 `USE_ENERGY_ITEM` with `item_id` and `item_num`, and removes the submitted Backpack stack only when the server returns OK. Pass96's handler already settles one UoW containing a stack debit plus a Temporal Energy credit.

The failure is metadata provenance. Effective `item.lua` has **22 Energy-bearing items**. Kanto Food (`50001015`) is **18 Energy**, Tonkatsu (`50001016`) is **30 Energy**, and Fries (`50001014`) is 6 Energy. The current generic `game_data_catalog.json` represents only Fries correctly; the other 21 source Energy rows are zero-effect placeholders. Its recorded item source SHA (`3d26da6005e27b283de4d637034a4b76c2c2aea7406e8c0379482083315ead9e`) differs from the current effective item table (`59b668c28a372543da0c36d7a8d84291cc5b93fa0d92b7cc389a645e96e7b7cc`).

This precisely explains the runtime MID27 `error_code=1` for Kanto Food. The next implementation should repair catalog authority, not rewrite the UoW semantics.

## Consumable catalog

Effective `item.lua` contains **5838 item rows**, including **2034 type-4 Consumables**. Source subtypes route to domain-specific operations rather than one universal consume algorithm. Relevant recovered subtypes include EXP, Fumo, Mana, Energy, Awake, Activity, skin, Pet, Pet drink, Love/Favor, Activity Center magic resources, Skill Point, and Open Activity.

The source has **12 magic consumables** whose effects are explicitly `magic_energy`, `magic_dust`, or `magic_liquid`. `EventCentreSellWindow` sums those exact fields and calls MID87. Pass96 MID87 currently returns success with no effects, so the client can delete items while the server awards nothing.

## Inscription / Emblem dissolve

MID1404 `INSCRIPTION_RESOLVE` does not produce generic Emblem EXP. Source `inscription.lua` maps resolve materials 19/20/21 to the three certificate balances `degree_cer`, `graduate_cer`, and `patent_cer`. Runtime successful calls already returned cumulative values such as `graduate_cer=760`, `2180`, `5980`, `6740` and `degree_cer=760`.

The real defect is metadata coverage: source `item.lua` has **254** item rows carrying `inscript_id`, while backend metadata maps **240**. The missing **14** source-valid items are the Honor variants ending `11` and `12` for levels 1–7 (`160200111/112` through `160200711/712`). This directly explains the mixed success/error runtime trace.

## Gift/chest boundary

`GiftbagUseWindow` uses MID241 `EXCHAGE_CODE_HERO`, removes the input item on OK, then applies returned awards. The recovered item table references **2781 unique gift IDs** from 1052 items. Of those references, **189** recovered gift definitions contain nonzero `drops` and **426** referenced IDs are absent from effective `gift.lua`.

Therefore complete generic gift/chest support should not be implemented before shared RandomOutcomeService. Random or source-missing rows must remain fail-closed.

## Pet EXP safety

`Pet.selfDrink()` sends MID134 `PET_USE_EXP_ITEMS` and removes every submitted item after OK. Pass96 routes MID134 to a generic pet mutation response that does not settle the Pet EXP/item transaction. This is a false-success risk and should be fail-closed until the Pet EXP domain is implemented.

## Stamina unblock strategy

Pass98 should remain deterministic and bounded: build a source-authoritative `ConsumableEffectCatalog`; repair all 22 MID27 Energy consumables; implement the 12 MID87 magic-resource items atomically; regenerate the complete MID1404 source mapping; fail-close MID134; and keep random/missing MID241 gifts closed.

After that smoke, implement MID97 separately. Source shows MID97 sends an empty request, expects cumulative `buy_energy_times`, grants 120 Energy, uses the nth `refreshCost` Crystal price, and uses VIP `num_energy` plus active Monthly Privilege allowance. It needs its own atomic price/count/Energy/retry design rather than being folded into MID27.

RandomOutcomeService remains paused only until these deterministic Global Economy loose ends are accepted; it is still mandatory for random gift/chest settlement, Summon migration, and Campaign repeat RNG.

## Commit

`Pass97.0: runtime-accept Pass96; map source-native consumable MIDs/effects, identify MID27 catalog drift and silent-loss paths, and freeze deterministic stamina-unblock architecture; backend unchanged`

## Machine-memory health

Promoted database: `GAME_KNOWLEDGE_CATALOG_PASS97_0.sqlite`; project tables: **495**; `PRAGMA integrity_check = ok`. Backend remains frozen at Pass96.
