# PASS85 INDEX

Current authority: `00_PASSMAP/MACHINE_BOOTSTRAP_PASS85.json` and `00_PASSMAP/databases/GAME_KNOWLEDGE_CATALOG_PASS85.sqlite`.

Targeted research only: Recharge purchase transport, source charge catalogs, VIP progression/privileges/claims, current Skin Shop purchase planes, frozen-backend reality, and a bounded future architecture blueprint. Backend remains Pass83.
