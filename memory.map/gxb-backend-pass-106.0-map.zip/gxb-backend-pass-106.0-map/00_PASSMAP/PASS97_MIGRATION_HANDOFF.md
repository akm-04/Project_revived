# Pass97.0 Migration Handoff

Canonical backend remains `gxb-backend-v0.12.1-pass96.0.zip` (b6b0f7a9df9f408bddfca5cf84c31f3fbfa754cd021d25796496ce00dab3028c) and is runtime accepted. Canonical source remains `all-assest-rechecked.zip` (89f0f830508b92e5fff6ad53c6a9dae961a14042dbfdf5649008efb8353f5608); effective src_64 has 4,370 files.

Pass97 is research-only. Read `READ_FIRST.md`, `MACHINE_BOOTSTRAP_PASS97_0.json`, `PASS97_LIVE_CHECKPOINT.json`, the consumable MID/catalog/inscription/stamina records, `CURRENT_AUTHORITY_MAP.json`, `QUERY_ROUTER.json`, then `GAME_KNOWLEDGE_CATALOG_PASS97_0.sqlite`.

Immediate next pass is a bounded deterministic consumables safety/QA-unblock implementation: source ConsumableEffectCatalog -> MID27 -> MID87 -> complete MID1404 mapping -> MID134 fail-close -> keep random/missing MID241 closed. MID97 is a separate follow-up stateful stamina-purchase slice. RandomOutcomeService remains on hold until these deterministic Global Economy seams are accepted.

Permanent rule: every behavior change must be checked against effective src_64 before implementation.
