# PASS-MAP COMMIT RULES — AGENT / MACHINE CONTRACT

This file is a mandatory repository contract for every future LLM/session. The pass-map ZIP is the handoff mechanism and must behave like a cumulative version-controlled repository.

## A. Canonical repository invariants

- `CANONICAL_INPUT = latest attached gxb-backend-pass-<P>[.<R>]-map.zip`
- `LINEAGE_ID = gxb-backend-pass-map`
- `MUTATION_MODEL = unpack -> inspect -> merge/update -> validate -> repack`
- `NO_PARALLEL_ROOT_MAP = true`
- `NO_TOUCHED_FILES_ONLY_ZIP = true`
- `LOOSE_INTERNAL_FILE_DELIVERY_DEFAULT = false`
- `PASS_ARCHIVE_NAME = gxb-backend-pass-<planning_pass>[.<revision>]-map.zip`
- `PLANNING_PASS_INCREMENT = normally for an explicit planning/extrapolation/reality-check mapping pass`; Pass32.5 is an explicit user-requested blueprint subpass exception and does not change the default convention.
- `IMPLEMENTATION_OR_MAINTENANCE = keep planning pass; increment revision suffix`
- `REVISION_ORDER = integer tuple semantics; 30.10 follows 30.9 (never parse suffix as a decimal fraction)`
- `ID_RESOLUTION = field/API context -> explicit table membership -> item type/sub_type/cross-refs -> asset evidence -> prefix hint`; never assign canonical owner from digits alone.

The attached canonical ZIP wins over chat memory, loose folders, and older fragmented pass archives. Never reconstruct a new root map from remembered context.

## B. Mandatory start-of-session hook

When the canonical ZIP is supplied:

1. unpack that exact ZIP;
2. read `00_PASSMAP/READ_FIRST.md`;
3. read `00_PASSMAP/STATUS.json` for current dashboard metrics;
4. read `memory.md`, the latest planning-pass index plus latest revision index (when present), and `AGENT_HANDOFF.md`;
5. use `00_PASSMAP/NAVIGATION.json` to open only relevant architecture/evidence paths;
6. establish a pre-edit inventory and retain the existing SHA-256 manifest;
7. only then begin new mapping or implementation-adjacent analysis.

Never answer a repository-continuation task from prior conversation history alone when the canonical ZIP is available.

## C. Historical / rolling / generated classes

### C.1 Historical pass evidence — append-only

Planning-pass and revision-specific evidence (`PASS##_*.md/json`, `PASS##_#_*.md/json`, or equivalent explicit pass/revision snapshots) is retained append-only. Do not rewrite an older snapshot to match a newer belief. Add corrections in a later planning pass/revision or rolling reference.

### C.2 Rolling canonical references — synchronize

Examples: `memory.md`, `AGENT_HANDOFF.md`, `CLIENT_ARCHITECTURE.md`, `SRC64_COMPLETE_MAP.md`, `API_SURFACE_MAP.md`, and `00_PASSMAP/*` controls. Newest verified evidence may update these after reconciliation.

### C.3 Generated/protected evidence — preserve

`api_contracts/**`, `tools/**`, inventories, source-fact corpora, validation files, and generated audits must not disappear merely because a later pass touched fewer files.


### C.4 Legacy synthesis/reference — preserve, query selectively

Large legacy syntheses such as `PROTOCOL_NOTES.md` and `BACKEND_DESIGN_FROM_SRC64.md` are retained as provenance/reference rather than mandatory rolling state. Do not preload or rewrite them on every pass; use targeted search and newer focused maps first. Historical measurements inside them are snapshots, not the current dashboard.

## D. Merge/conflict rules

1. Preserve existing paths by default.
2. Older fragmented archives are recovery inputs, never canonical replacements.
3. Import missing pass-specific evidence; never overwrite a newer rolling file with an older checkpoint without explicit reconciliation.
4. Same-name conflicts require content/provenance/evidence comparison; timestamp or filename alone is insufficient.
5. Deletion requires an explicit reason, changelog entry, manifest update, and anti-regression validation. Unexplained archive shrinkage blocks release.
6. Corrections are documented; never silently normalize historical claims.

## E. Memory cap — standing rule

`memory.md` is a **rolling working-state file**, not a transcript archive.

- Keep the **current planning pass plus the previous three planning passes** at full operational fidelity. Implementation/maintenance revisions (for example 30.1, 30.2) are summarized inside the current planning-pass window rather than consuming another historical-pass slot.
- Every older pass must be compressed on every commit to a compact summary table with at most one or two bullets/clauses plus pointers to retained historical documents.
- Persistent rules that remain active across many passes belong in a short `Standing invariants` section, not duplicated under every historical pass.
- Historical detail is never deleted from the repository merely because it leaves `memory.md`; it remains in pass-specific evidence files.

## F. STATUS.json — current metric single source of truth

`00_PASSMAP/STATUS.json` is the **only authorized dashboard for current/global repository progress metrics**, including source inventory coverage, MID catalog/trace/ownership/implementation coverage, and current repository validation totals when recorded.

Rules:

1. Rolling documents must link to `00_PASSMAP/STATUS.json` instead of repeating current global progress counts.
2. This rule does **not** forbid protocol constants, MID numbers, table IDs, rates, levels, reward quantities, source row counts needed to explain a specific finding, historical snapshot measurements, or local evidence values. Those are evidence, not dashboard progress metrics.
3. Historical pass/fact files are immutable snapshots and may retain the measurements that were true/reported at that pass.
4. If a dashboard metric changes, update `STATUS.json` and the metric definition/source together.
5. Never copy user- or model-suggested metric values without recomputing them from retained evidence.


## C.5 Authorized lossless historical compaction (Pass39+)

Historical evidence remains append-only in substance. An explicit user-authorized repository-maintenance/self-heal pass may move old narrative Markdown/TXT snapshots from active paths into a **lossless internal archive** only when all of the following hold: original bytes are preserved, every original path/member/size/SHA-256 is indexed in `00_PASSMAP/HISTORICAL_ARCHIVE_INDEX.json`, archive integrity is validated before originals are removed, machine registries/source facts/runtime captures/API contracts are not compacted by this rule, and rolling references are synchronized so active retrieval does not silently depend on removed paths. This is archival relocation, not evidence deletion.

## G. LLM-first documentation rules

- Prefer deterministic paths and strict headings.
- Separate `source-confirmed`, `user-runtime-confirmed`, `architecture inference/local policy`, and `unresolved` explicitly.
- State ownership, persistence boundary, response shape, and unresolved fields where relevant.
- Prefer compact JSON for machine state/indexes; prose documents explain reasoning, not duplicate registries.
- Cross-link strongest evidence rather than repeating large protocol explanations.
- Do not read the entire repository by default. Use `NAVIGATION.json`, then targeted grep/search and generated per-MID contracts.
- Raw tables prove configuration, not hidden server algorithms. Client-local storage is not canonical server state unless independently established.
- Source resolution is layered: if a recovered writable `downloaded-assets/output/src_64/<path>` exists, it supersedes the same APK baseline path for runtime-behavior mapping. Use `00_PASSMAP/CLIENT_SOURCE_LAYERS.json`; do not silently mix layers.
- Source-derived backend metadata must follow the same layered resolution. If a generator accepts one source root, provide an effective merged root or prove every consumed overridden row equivalent; track current provenance in `00_PASSMAP/BACKEND_METADATA_PROVENANCE.json`.
- Compatibility/fallback OK responses are discovery evidence only. Never promote a durable mutation to “implemented” because the fallback lets the client continue; optimistic client mutation can hide canonical divergence.
- The supplied src_32/src_64 trees are byte-identical snapshots for analysis. Inspect src_64 only unless new evidence shows divergence; force-update packaging may still need both architecture directories.

## G2. Commit workflow

### G2.0 Planning pass versus revision

The repository version is an ordered pair `(planning_pass, revision)`, not a floating-point number.

- **Planning/extrapolation/reality-check commit:** increment `planning_pass` by exactly 1 and reset `revision=0`. Delivery name omits `.0`, e.g. `gxb-backend-pass-31-map.zip`. This class is reserved for deliberate backend/client extrapolation, architecture planning, ownership/gap analysis, or comparable research that establishes the next implementation plan.
- **Implementation, runtime-fix, maintenance, packaging, documentation, or synchronization commit:** keep the current `planning_pass` and increment `revision` by exactly 1, e.g. `30 -> 30.1 -> 30.2 -> ... -> 30.9 -> 30.10`.
- Never use semantic size alone to bump the integer; the integer denotes a new planning/extrapolation cycle.
- Never parse `30.10` numerically as `30.1`; store/display the version as a string plus explicit integer `planning_pass` and `revision` fields in machine controls.

A planning pass normally adds a new integer-pass index/source/findings/facts set, synchronizes rolling references, updates memory, and updates repository controls.

A revision commit adds a revision-specific status/facts/index when useful, updates `memory.md`, `CHANGELOG.md`, handoff/current controls, and affected rolling references, while preserving the integer planning-pass evidence unchanged.

### G2.1 Incremental hashing / validation

`FILE_MANIFEST.sha256` remains a full-repository hash index, but commit work must be incremental:

1. retain the previous manifest before edits;
2. maintain an explicit touched/new/deleted path set during the commit;
3. hash only touched/new files;
4. copy stored hashes for untouched paths after verifying their paths still exist and were not marked touched;
5. remove manifest rows only for explicitly deleted paths;
6. compare the final path set against the prior path set and block unexplained deletion/shrinkage;
7. full re-hashing is allowed for recovery/corruption audits, but is not the default per-pass workflow.

ZIP integrity and JSON parsing may still scan the packaged archive; the expensive content re-hash should remain incremental.

## H. Pre-ship checklist

- **H.1** Required control files exist: `READ_FIRST.md`, `COMMIT_RULES.md`, `STATUS.json`, `NAVIGATION.json`, `MID_OWNERSHIP.json`, `MANIFEST.json`, `CHANGELOG.md`, `FILE_MANIFEST.sha256`.
- **H.2** Protected/generated corpus remains present.
- **H.3** All modified/new JSON parses.
- **H.4** Source inventory reconciles when source is available.
- **H.5** Incremental `FILE_MANIFEST.sha256` update has no unknown path loss and touched hashes verify.
- **H.6** ZIP contains one canonical root matching `gxb-backend-pass-<P>[.<R>]-map/`, with `.0` omitted for a fresh planning pass.
- **H.7** ZIP integrity passes.
- **H.8** `MANIFEST.json` reports lineage/current pass/archive and links to `STATUS.json` for dashboard metrics.
- **H.9** Chat response contains one short commit message and one ZIP link; do not emit loose internal map artifacts unless explicitly requested.
- **H.10** No **current/global repository progress metric** is duplicated in a rolling document; it must link to `00_PASSMAP/STATUS.json`. Protocol/evidence numbers and immutable historical snapshots are exempt.

## I. Handoff success criterion

A fresh LLM receiving only the latest canonical ZIP must be able to reconstruct current research state, current backend line, evidence hierarchy, unresolved boundaries, architecture, and next-step context without prior chat history—and must be able to do so without loading the whole archive into context.

## Infrastructure blueprint contract — Pass32.5

For the next structural backend revision, preserve these contracts unless newer source/runtime evidence supersedes them explicitly:

- `GameDataCatalog` is immutable source/config meaning generated from effective writable-over-APK inputs; runtime mutation code never chooses owner from decimal digits alone.
- construct one request-scoped `RequestServices` dependency graph after player binding; do not independently reconstruct nested repositories per getter.
- `RewardTransactionService` consumes typed RewardPlans created by domain-specific adapters; it does not guess raw reward IDs.
- `UnitOfWork` coordinates staged mutation/rollback/one commit; domain repositories keep formulas and canonical ownership.
- Function eligibility and announcement/open state are separate. `PlayerState.func_ids` is an announced compatibility mirror during migration.
- `ResponseProjector` may derive cumulative `economy_`/`exps`; semantic event/control keys (`new_funcs_`, mission deltas, `extra_drops_`, redmarks, etc.) require explicit owner output.

Machine contracts: `00_PASSMAP/BACKEND_INFRASTRUCTURE_BLUEPRINT.json`, `00_PASSMAP/GAME_DATA_CATALOG_CONTRACT.json`, `00_PASSMAP/REQUEST_SERVICES_CONTRACT.json`, `00_PASSMAP/REWARD_TRANSACTION_CONTRACT.json`, `00_PASSMAP/FUNCTION_STATE_CONTRACT.json`, `00_PASSMAP/UNIT_OF_WORK_CONTRACT.json`.


## J. Required external artifact availability

The canonical map is long-term memory but is not a substitute for artifacts that a task explicitly requires. Use `00_PASSMAP/REQUIRED_EXTERNAL_INPUTS.json`.

1. Every continuation requires the latest canonical pass-map ZIP.
2. Backend inspection/modification requires the current backend ZIP.
3. Lua/effective-source/metadata/update analysis requires the canonical layered asset recovery (`all-assest-rechecked.zip` or a newer explicitly reconciled equivalent containing both APK baseline and writable downloaded overrides).
4. New runtime bug analysis requires the user-supplied relevant logs/debug bundle.
5. If a required artifact is unavailable in the active session, **stop and ask the user for it**. Do not reconstruct or implement from model memory alone.
6. If the task can be completed from the pass map without a missing artifact, continue only within that supported scope and state any limitation.

## J.1 Fresh-chat halt semantics — Pass41.2 continuity hardening

For a fresh project chat, artifact availability is a **precondition**, not a soft warning. If the requested task requires the canonical pass map, current backend, layered `all-assest-rechecked.zip`, or current runtime logs and that artifact is absent from the active session, the agent must halt project analysis/implementation and ask for the exact missing artifact. It must not continue from model/chat memory, an older archive, a stale extracted tree, APK-only source when writable overrides matter, or an older debug bundle. The intended next-session sequence is defined in `00_PASSMAP/NEXT_SESSION_WORKFLOW.json`.

### G2.0a Explicit user-authorized map-only subrevision exception (Pass42.5.1+)

Default repository ordering remains `(planning_pass, revision)` with integer revision. When the user **explicitly requests** a map-only secondary synchronization/self-heal that must preserve an already-reserved next implementation revision, a third integer `subrevision` is allowed: `(planning_pass, revision, subrevision)`, e.g. `42.5.1`. This exception is never inferred from task size. Machine controls must keep `planning_pass=42`, `revision=5`, `subrevision=1`, `display_revision="42.5.1"`; compare lexicographically as integer tuples and never as decimals. The next reserved normal revision after the subrevision family remains `42.6` unless the user changes the roadmap. Archive naming becomes `gxb-backend-pass-<P>.<R>.<S>-map.zip` for this explicit exception. Backend implementation commits should continue using the normal two-component revision unless the user explicitly authorizes otherwise.
