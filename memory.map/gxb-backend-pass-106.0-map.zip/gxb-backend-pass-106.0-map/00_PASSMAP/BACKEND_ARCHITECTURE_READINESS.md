# Backend Architecture Readiness — Pass63

**Required Phase 2 readiness audit. Implementation remains prohibited.**

## Category semantics

- **CONFIRMED** — architecture-relevant behavior is directly supported by current effective `src_64` and/or runtime evidence.
- **HIGH CONFIDENCE** — multiple independent current evidence surfaces agree on the state/transaction boundary; bounded hidden details may remain.
- **INFERRED** — a reasonable architecture interpretation needed to organize mapped evidence, but not itself recovered server code.
- **UNKNOWN** — intentionally unresolved original-server logic or side effects; must be isolated behind policy/fail-closed seams.
- **CONFLICTING** — current/historical/versioned evidence disagrees; preserve the conflict and scope by version rather than inventing a single truth.

**Important:** this rating is about the architecture-relevant contract of the listed system, not a claim that every hidden original-server algorithm is recovered. A HIGH CONFIDENCE system can contain explicitly UNKNOWN sub-policies.

## Major Phase 1 system audit

| System | Category | Evidence basis | Architecture disposition |
|---|---|---|---|
| Effective source + content catalog | **CONFIRMED** | 4,370/4,370 exact source fingerprint; normalized catalogs in master SQLite. | Source is stable authority; architecture may compile/import it but must preserve provenance. |
| Transport / SDK session / MID routing / chat | **CONFIRMED** | Pass62 direct source/backend reality check plus runtime history. | Hard invariant: 5000/9000/9100 split, uppercase aliases/cookies, MID192 HTTP discovery. |
| Player bootstrap and global response synchronization | **CONFIRMED** | Bootstrap/runtime history and Backend global response/economy wiring. | Use request-scoped state owner + post-commit projection; do not duplicate canonical state in projections. |
| Function unlock and tutorial announcement | **HIGH CONFIDENCE** | Source eligibility + runtime-confirmed Function33 milestone + trust-boundary mapping. | Keep eligibility distinct from announced/open; unresolved historical gates remain policy holds. |
| Global economy/resource synchronization | **CONFIRMED** | 47 current wired fields and economy_ channel mapped. | Typed resource policies required; fields are not semantically interchangeable currencies. |
| Backpack / stack inventory / item deltas | **CONFIRMED** | Replacement snapshot + delta semantics, 5,845-item catalog, runtime-backed repositories. | Stack counts have one canonical owner; generated instances are separate. |
| Reward/award settlement and projection | **HIGH CONFIDENCE** | Multiple reward channels and existing typed reward blueprint agree. | Use typed settlement atoms/plans inside UoW; display awards are projections. |
| Gacha / Summon current activated scope | **CONFIRMED** | Current source + Pass41/42 runtime-confirmed slices. | Preserve current operation matrix; unresolved variants fail closed; RNG policy is family-specific. |
| Store / shop stock and purchase lifecycle | **HIGH CONFIDENCE** | Pass52 current source mappings across stock, limits, costs, refresh ownership. | Server owns concrete stock; exact stock generator remains UNKNOWN/PRIVATE_SERVER_POLICY. |
| Recharge / VIP / entitlement lifecycle | **HIGH CONFIDENCE** | Pass53 independent source surfaces and economy linkage. | Separate commerce receipt from entitlement settlement; some historical/native details remain bounded. |
| Normal Girls/Hero progression and ownership | **HIGH CONFIDENCE** | Source + runtime-confirmed summon/evolve slices + canonical Girl catalog. | Hero aggregate owns persistent progression; do not universalize native-star/acquisition rules. |
| Girls gear / Fumo / Practice / Inscription / Element / Horcrux | **HIGH CONFIDENCE** | Pass56 maps distinct equipment planes and transaction boundaries. | Keep specialized gear services and generated-instance/candidate state; exact candidate RNG is UNKNOWN. |
| Pet full lifecycle | **HIGH CONFIDENCE** | Pass58 2,848 source checks and 54-row lifecycle freeze. | Pet aggregate + three-slot gear + practice candidate + mission awakening; Pet Fumo currently noncombat. |
| Vows / Super Partner | **HIGH CONFIDENCE** | Pass59 fixed roster, star/equipment/economy transactions mapped. | No prerequisite sacrifice may be invented; hidden MID305 side effects remain UNKNOWN. |
| Workshop / timed production / compose / recycle | **HIGH CONFIDENCE** | Pass60 576 source checks; start/cancel/claim and economy planes mapped. | Timed jobs distinct from instant compose; refund/crit formulas remain UNKNOWN; L6 recycle prose conflict is preserved. |
| Daily/weekly reset, regeneration, buy counters and timers | **HIGH CONFIDENCE** | Pass61 233 source checks; server clock and temporal taxonomy mapped. | 05:00 GMT+8 core day boundary is strong; weekly and some counter carriers remain subsystem-specific/UNKNOWN. |
| Campaign Normal / Elite / Challenge | **HIGH CONFIDENCE** | Pass44/48 transaction/content boundary and source topology. | Battle/settlement shape is ready; exact repeat-drop entitlement sampler remains UNKNOWN. |
| Mission/task progression and reward claims | **HIGH CONFIDENCE** | Mission state/reward paths mapped across campaign/economy progression. | Prefer synchronous progression hooks in same UoW; architecture interpretation is stronger than exact hidden trigger ordering. |
| Evaluation family: Voyage / Illusion / Occult / Dodgeball / Memoir | **HIGH CONFIDENCE** | Pass45-51 per-mode authority matrices map client-sim, server-report and audit styles. | One visible family can use multiple BattleAuthorityAdapters; some generators remain UNKNOWN. |
| Work Place/Treasure / March / Conquest generated PvE | **HIGH CONFIDENCE** | Persistent state, command and settlement boundaries are mapped. | Exact encounter/map/modifier generators are UNKNOWN and belong behind domain RNG policies. |
| Dorm/Housing personal slice | **HIGH CONFIDENCE** | Mode census and personal persistent-state/economy mappings are sufficient for interface placement. | Shared/social extensions should remain outside the personal aggregate until needed. |
| Hidden original-server RNG / generation policies | **UNKNOWN** | Client/server trust boundaries are known but exact algorithms are absent for several systems. | Explicit PRIVATE_SERVER_POLICY plug-ins; never present reconstructed policies as official code. |
| PvP / guild / social shared-world lifecycle | **INFERRED** | Phase1 census maps protocol/state surfaces but intentionally did not deep-target full shared-world implementation. | Design ports now; defer concrete aggregates/multi-player semantics until late planning. |
| Seasonal / temporary event packages | **CONFLICTING** | Current source contains event-specific version drift, duplicated/rebound MIDs and stale/current table mixtures. | Treat each event package/version separately; no universal event engine semantics beyond shared infrastructure. |

## Explicit UNKNOWN policy surfaces

- Campaign Normal/Elite repeat-drop entitlement sampler and quantity semantics.
- Store concrete stock pool/slot generation and irregular rate normalization.
- Work Place/Treasure encounter/chest generator; March map/chest/enemy/reward generator; Conquest random modifier selection.
- Practice/Alchemy, Pet Practice, Inscription/Emblem and Horcrux generated-attribute samplers.
- Workshop production-cancel refund formula and Recycle critical sampler.
- Mana free-count replenishment calendar and Glue purchase-counter reset carrier.
- Vows MID305 hidden original-server rejection/side-effect details; there is no authority to invent prerequisite Girl sacrifice.
- Event-specific hidden RNG where current source exposes only transaction/state boundaries.

These unknowns do **not** block architecture because the ownership and transaction seams are already known. They block claims of exact original-server fidelity and must be represented by `PRIVATE_SERVER_POLICY`, explicit unsupported behavior, or new evidence.

## Explicit CONFLICTING/version-drift surfaces

- Recycle Bin level-6 prose says 10% cost reduction while the live parsed field/UI computes 8%; architecture stores machine-readable current behavior and preserves stale prose as conflict metadata.
- Vows broad Chapter 21 acquisition text is wider than the five current nonzero `stone_campaign` pointers; direct-stage acquisition and Essence exchange stay separate edges.
- Seasonal event packages contain duplicate/rebound MIDs and stale/current table mixtures (for example Sakura); events must be version-scoped modules.
- Historical function labels and current wired model names can diverge; protocol/model authority wins over name similarity.

## Architecture-readiness verdict

All core single-player/economy/progression domains needed to design the shared backbone are **CONFIRMED or HIGH CONFIDENCE at the ownership/transaction level**. The remaining UNKNOWN and CONFLICTING surfaces are bounded behind explicit seams. PvP/guild/social are intentionally INFERRED/late and must not block core architecture.

**Verdict:** Pass63 architecture planning can proceed to backend migration/interface-contract design. This document does not authorize backend implementation.
