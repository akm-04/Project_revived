# Pass78 Daily Reset Blast Radius Research

Research-only. Backend remains gxb-backend-v0.9.7-pass75.0.zip (51ad2d70202896bc0c47f703712530bca0f670bd9accb6a5f244e2b4b41c1d7f).

## Core conclusion
The source day is 05:00 GMT+8. The coordinator core should own durable one-player day counters, not every domain that reloads at 05. Direct 05 client fanout is Daily Missions + Activities + Auction. Separately, the server daily_updates economy signal invalidates WorldMap, Trial, Sign, and March caches and synchronizes buy_mana_times/buy_energy_times/buy_skill_times.

## Already-owned backend retrofit
P0: Quick Enchant UTC-midnight counter; MID99 buy_skill_times; Super/Elite campaign daily_limit/reset_count. P1 compatibility: persisted buy_mana_times/buy_energy_times. Explicit exclusion: buy_spirit_energy_times is not in the source daily_updates updates object.

## Requested examples
- Daily Sign-in: yes, client explicitly resets isSigned=0 and invalidates sign info on daily_updates. Current backend Sign is a stub; implementation remains later.
- Monthly/Week/Energy/Privilege cards: their claim rows are Daily Missions, so claim availability is day-bound. Entitlement remaining-day fields are commerce-owned and are not proven safe for generic decrement.
- VIP daily rewards: no generic daily VIP gift found. vip_free_gift is one-time by VIP threshold; VipWeekGift is weekly.
- Shops: normal Shop refresh is 12:00/18:00/21:00, not 05:00. Activity shops may have their own daily policies under Activities.
- Arena: core attempt state uses its own recharge/reset protocol; only the DAILY.ARENA_BATTLE_COUNT mission is in the 05 mission plane.

## Implementation decision
Ready for the next implementation pass, but narrower than Pass77: ServerDayClock + DailyResetCoordinator + only already-owned participants (Quick Enchant, mana/energy/skill buy counters, Super Campaign rollover) and a bounded one-shot daily_updates projection seam on source-triggered reset requests. No MID116/117/118 in the same pass.
