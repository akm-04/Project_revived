# Pass69 — Economy Backbone Part 2: Scalar Ledger & StackInventory

**Phase:** Phase 3 implementation  
**Backend:** `gxb-backend-v0.9.1-pass69.0.zip`  
**Static/offline implementation status:** **FINAL**  
**Runtime client acceptance:** **PENDING USER `debug.zip`**  
**Game-feature expansion:** **NONE**

Pass69 consumes the Phase2/Pass65-67 contracts and the runtime-accepted Pass68.1 foundation. It installs typed scalar and Backpack settlement while preserving the existing wire protocol, PlayerState layout, JSON database, handler APIs, and compatibility façades.

## Implemented backbone

### EconomyLedger
The new `EconomyLedger` is the logical owner for exactly the **30** ResourceRegistry descriptors classified `scalar_ledger`:

`mana, crystal, arena_coin, march_coin, top_coin, guild_coin, region_coin, honor_coin, king_coin, lucky_coin, paradise_coin, god_war_coin, spirit_stone, magic_dust, magic_liquid, magic_energy, friendship_coin, friend_medal, summon_coin, lvbu_coin, magic_exp, degree_cer, graduate_cer, patent_cer, team_dungeon_coin, ice_core, skin_fragment, tutor_coin, skin_coin, glue`

It validates registry ownership/storage at composition time, preflights mixed-resource deltas before mutation, rejects negative resulting balances, preserves the existing `PlayerState.<wire_key>` storage fields, and touches the `scalar_economy` slice inside an active PlayerUnitOfWork. It does not invent caps.

The legacy `EconomyRepository` remains callable. Mana and Crystal delegate to EconomyLedger; Energy remains on the regenerating/temporal compatibility path; EXP/level remain Player progression. This prevents Pass69 from falsely turning all 47 `economy_` keys into currencies.

### StackInventory
`StackInventory` centralizes signed Backpack stack arithmetic over the existing `player.backpack_items` representation. Mixed debits are preflighted before mutation, positive grants retain the legacy stack payload shape, and successful UoW mutations touch the `backpack_stacks` slice.

`InventoryRepository` remains a compatibility façade/subclass, so existing handlers and repositories continue to work without a flag-day rewrite.

### MutationPlan settlement
Pass69 adds the frozen MutationPlan dataclasses and `MutationSettlementService`. The executable operation families in this wave are intentionally only **RESOURCE** and **STACK**. Settlement requires an existing PlayerUnitOfWork, validates actor and expected state version, validates all resource/stack changes first, then applies both owners under one durable command boundary.

Legacy `RewardTransactionService` remains available, but scalar rewards and Backpack rewards are now converted into immutable typed MutationPlan leaves. Energy, player EXP and entity/partner grants deliberately remain on their current specialized owners until later backbone waves.

Pass69 does **not** fabricate a frozen `MutationResult(status=COMMITTED)` before durability. It returns an internal `SettlementDraft`; the outer UoW publishes the typed mutation journal only after the player file commits successfully.

### UoW journal seam
PlayerUnitOfWork now has first-class staged/committed mutation journal queues. Journal rows are invisible before commit and are discarded on rollback or persistence failure. This is the installation seam for the next journal-aware ResponseProjector wave.

The existing semantic `economy_` staging path remains in place for compatibility in Pass69.

## What did not change
Client-facing engine/SDK routes, dispatcher, ResponseProjector, global response semantics, PlayerState, PlayerDatabase and MultiUserDatabase remain byte-identical to the runtime-accepted Pass68.1 backend. No Campaign/Vows/Workshop/Pet/Store/VIP feature was added. No temporal-resource migration or Hero/Girls Gear migration was started.

## Static validation
- `compileall`: PASS
- Pass42.12 validator: PASS
- Pass42.14 validator: PASS
- Pass68 foundation self-test: PASS
- Pass68.1 Medium-free self-test: PASS
- Pass69 Economy Backbone Part2 self-test: PASS
- new static regressions versus Pass68.1: **0**

Three historical standalone tests with stale expectations continue to fail on Pass68.1 and Pass69 identically; they are not new regressions.

## `src_64` Architectural Feedback Loop
The canonical assets reconstruct **4,370** effective source files (**62 downloaded winners + 4,308 app winners**) and remain an exact Pass57 fingerprint match: 0 missing, 0 extra, 0 hash mismatches. Pass67 architectural assertions remain **48/48 PASS**. The runtime ResourceRegistry remains an exact **47/47** Pass65 descriptor match, including exactly **30** scalar ledger resources.

This confirms that Pass69 changes internal mutation ownership/transaction mechanics without changing the Lua-observed protocol/storage synchronization contract.

## Remaining bridges / next gate
Pass69 remains a strangler migration, not a rewrite. Legacy façades and some legacy immediate-save normalization paths still exist. The ResponseProjector is intentionally unchanged until the next wave.

Before any Pass70 implementation, the user should run the client against this backend with preserved player/server data and return a new `debug.zip`. The next recommended wave after runtime acceptance is **journal-aware ResponseProjector + per-MID ProjectionProfile integration**, not a new gameplay feature.
