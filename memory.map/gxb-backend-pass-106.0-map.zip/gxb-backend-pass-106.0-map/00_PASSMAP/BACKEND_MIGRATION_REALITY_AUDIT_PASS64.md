# Backend Migration Reality Audit — Pass64

**Phase:** Phase 2 — Architecture Planning.  
**Backend audited:** `gxb-backend-v0.8.34-pass42.14.zip` (`410fd08716c3e06cd788a4d3123f519af4c97537fb1b8ad7d765002efbcec5cb`).  
**Implementation status:** **PROHIBITED / unchanged.** No Python backend source was edited in Pass64.

## Executive conclusion

The Pass42.14 backend does **not** need a full rewrite. It is a partially migrated architecture: several of the Pass63 target primitives already exist in embryonic form (`GameDataCatalog`, `RequestServices`, `UnitOfWork`, `RewardTransactionService`, repositories, response projection and explicit private-policy objects), while compatibility transport/session code is stable enough to keep.

The central weakness is ownership breadth, not storage technology. The current `PlayerState`/bootstrap representation already carries **44/47** current Global Economy wire keys directly; the three missing keys are `daily_updates` and nested `updates` control envelopes plus intentionally suppressed/version-drifted `invitation`. By contrast, `EconomyRepository` explicitly mutates only **5** fields (`mana`, `crystal`, `energy`, `exp`, `lev`), `RewardTransactionService` recognizes only **4** economy grant types, and `ResponseProjector` automatically reconciles only **5** fields.

Therefore the correct migration is a **strangler expansion around the current state representation**, not a replacement of the entire backend or PlayerState database.

## Your economy-first priority

Your instinct is correct and Pass64 makes it the recommended migration order. Economy, Backpack inventory, Hero/Girls Gear and Hero progression should be stabilized **before** Campaign/Workshop/Vows/Pet/Store are allowed to expand their implementations.

The reason is dependency centrality: Campaign spends Energy and grants EXP/items; Hero promotion/equipment consumes Mana/items and changes combat state; Workshop crosses scalar EventCentre resources and Backpack items; Vows/Pet use their own item/currency/progression edges; Store/Gacha spend and grant through the same canonical owners. If these domains each invent their own resource writes first, Phase2 architecture collapses back into ad-hoc PlayerState mutation.

However, "Global Economy" must be modeled as a **synchronization/projection plane**, not one giant CurrencyService. The canonical 47 fields classify as roughly **30 scalar-ledger fields**, **4 regenerating resources**, **3 mode-progress fields**, **2 player-progression fields**, and entitlement/reset/social/metric special cases. `ResourceRegistry` must route each key to its rightful owner while `ResponseProjector` emits one compatible `economy_` envelope.

## Existing strengths to preserve

1. **Compatibility edge:** ports 5000/9000/9100, SDK identity aliases/cookies, MID routing and MID192 chat discovery remain proven and are RETAIN/WRAP, not rewrite targets.
2. **GameDataCatalog:** namespace-aware content lookup is already close to the Phase63 target and should be retained.
3. **RequestServices/UoW:** the correct concepts already exist. They need broader coverage and cleaner composition, not replacement by a framework.
4. **Stack Inventory:** current `InventoryRepository` is a credible ordinary Backpack owner and can retain its persisted list shape.
5. **RewardTransactionService:** typed grants are the seed of `RewardSettlementService`; evolve rather than throw away.
6. **FunctionState/Tutorial:** these are already separated from generic PlayerState enough to retain.
7. **Gacha policy decomposition:** cost/result/counter/receipt/private-policy modules are comparatively mature and should be preserved while the 1,724-line `SummonRepository` is split later.
8. **Current storage:** JSON `PlayerState` persistence is adequate as the first infrastructure adapter. Storage migration is not the first problem.

The canonical backend still compiles cleanly and its shipped Pass42.14 static validator passes.

## Primary migration defects

### 1. Five-field economy owner versus 47-field synchronization reality — REPLACE abstraction, preserve storage

`EconomyRepository.PHASE1_FIELDS` is `mana/crystal/energy/exp/lev`. That was an appropriate earlier spine but is now architecturally obsolete.

Pass64 classifies **the EconomyRepository abstraction as REPLACE**, but this does **not** mean a backend rewrite. Its public methods should become a compatibility façade. `mana/crystal/energy` delegate to a typed scalar/regenerating resource owner; `exp/lev` move to PlayerProgression. Existing call sites can continue working while new generic keyed APIs are introduced behind them.

### 2. Partial UoW adoption — REFACTOR

The code contains **16** detectable UoW transaction sites, but also **14** direct handler `state.save()` calls. Transaction discipline therefore exists but is not universal.

Phase3 must make one request-scoped UoW mandatory for every durable command before new domains depend on shared state. The current deep-copy-whole-PlayerState UoW is acceptable as the first commit mechanism; it can later become repository journaling without changing application contracts.

### 3. Reward settlement is too narrow — REFACTOR

Current `RewardTransactionService` is typed but grant-oriented. The target `MutationPlan` must support typed debits, credits, entity create/patch operations, receipts and projection facts in one UoW. Old `RewardPlan` remains an adapter so Campaign/Missions/Gacha do not need a flag-day rewrite.

### 4. PlayerState is broad storage, not the domain architecture — REFACTOR

`PlayerState` is useful and already carries much of the client bootstrap shape. It should remain the first storage representation, but handlers and unrelated repositories should stop treating it as a global mutable object. Ownership contracts assign slices to Economy, Hero, Function, Campaign, Gacha and later domains.

### 5. Hero/Gear is important but only partially modeled — REFACTOR

Current Hero repositories already support ownership, skill points, EXP, ordinary equip and one-click promotion. That code should be preserved as a migration seed. It does not yet express the complete Girls Gear planes frozen in Phase1, so a Gear domain boundary must be introduced after the economy/inventory settlement foundation.

This ordering protects the exact concern you raised: persistent Girl stats, equipment and promotion become stable before Campaign is expanded around them.

### 6. Campaign `WorldRepository` is over-composed — REFACTOR

`WorldRepository` mixes map state, battle start/result, drops, rewards and mission interactions. It should split into CampaignAggregate + BattleAuthorityAdapter + Campaign RNG policy + application commands, but only after the economy/hero/gear primitives are stable.

### 7. SummonRepository is large but should not be rewritten — REFACTOR

The 1,724-line repository is orchestration-heavy, yet its surrounding policy modules and receipts are among the most deliberate parts of the current backend. Preserve them. Later split operation commands around the new UoW/Settlement interfaces.

## Classification summary

Pass64 audited **45 major module/system groups**:

- **RETAIN:** 16
- **WRAP:** 9
- **REFACTOR:** 15
- **REPLACE:** 2
- **DEFER:** 3

`REPLACE` means retire a wrong/superseded abstraction behind a compatibility façade. It does **not** mean a flag-day backend rewrite.

The two important replacement targets are the narrow Phase-1 `EconomyRepository` ownership model and the superseded duplicate `FunctionUnlockRepository`. Everything else is predominantly retain/wrap/refactor/defer.

## Recommended migration waves

### M0 — Freeze compatibility and characterization
Keep transport/session/protocol/catalog/observability behavior fixed and build regression gates around it.

### M1 — Transaction/composition skeleton
Refactor RequestContext/RequestServices and make UoW coverage universal while preserving PlayerState/JSON persistence.

### M2 — Economy + Inventory + Settlement backbone **(highest priority)**
Introduce ResourceRegistry, scalar EconomyLedger compatibility façade, StackInventory interface, typed MutationPlan/Settlement and committed semantic projection.

### M3 — Player/Hero/Gear progression
Move player EXP/level out of generic economy; stabilize HeroAggregate, Girls Gear planes, promotion/equipment and Skill Point temporal adapter.

### M4 — Temporal/reset foundation
Generalize the Pass61 clock/policy families without inventing one universal timer/reset job.

### M5 — Campaign + Missions
Only now split WorldRepository and attach Campaign/Missions to stable leaf owners.

### M6 — Gacha cleanup
Split SummonRepository orchestration but retain current source/private policies and receipts.

### M7 — Pet / Vows / Workshop / Store
Attach the frozen Phase1 domains to the established primitives.

### M8 — PvP / Guild / Social / Events
Remain late.

## Persistence doctrine

Do **not** migrate storage technology first. Keep the current PlayerState JSON representation and MultiUserDatabase behind a `PlayerStore` adapter. The architectural migration is ownership-first:

- scalar balances → EconomyLedger;
- player EXP/level → PlayerProgression;
- regenerating amounts/anchors → resource owner + TemporalPolicy;
- Backpack stacks → StackInventory;
- generated/pending instances → GeneratedInstanceStore;
- Hero state → HeroAggregate;
- Function/Tutorial → existing canonical repositories;
- Campaign/Gacha mode state → their aggregates.

Once these slices are stable and versioned, a later physical storage migration can happen without changing the domain contracts.

## Readiness verdict

Pass42.14 is **migration-ready**. It is not clean enough to accept more ad-hoc feature code safely, but it contains enough useful structure that a full rewrite would destroy working compatibility and tested behavior unnecessarily.

The recommended Phase2 next pass is **Core State & Economy Contract Freeze**: finalize ResourceRegistry descriptors, MutationPlan/MutationResult schemas, UoW persistence/versioning contracts, response-projection journal semantics, and characterization-test gates. No Python implementation should begin until those contracts are frozen and reviewed.
