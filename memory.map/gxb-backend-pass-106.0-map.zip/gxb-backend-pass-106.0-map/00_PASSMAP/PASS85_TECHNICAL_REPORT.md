# Pass 85.0 — Recharge, VIP and Skin Commerce Targeted Extrapolation

## Status
Research only. Backend remains byte-identical `gxb-backend-v0.9.12-pass83.0.zip` (eefee74fbf18707e1923cd26a70016440edefa76b5d2c0525c9df96c44888792).

## Main conclusion
The user's distinction is correct: Recharge/VIP commerce is not the ordinary Shop. The Crystal `+` UI queries server-advertised products with MID354, but purchase initiation leaves Lua through Android/iOS native SDK bridges. The authoritative game-state update arrives later as server RECHARGE event MID36857. Therefore a robust private server needs a PurchaseIntentBridge plus a transactional CommerceSettlementService; pretending MID36857 is a purchase request would contradict src_64.

## Charge catalog
`charge.lua` has 23 rows. The default show_type=0 set contains 14 rows: 7 direct Crystal packs, 3 standard card rows and 4 privilege/card rows including one hidden discount SKU. MID354 is server-authoritative availability; static table presence alone does not make a product purchasable. Per-product `charge_count` owns first-buy status and `last_buy_time` is also server data.

## VIP
`vip.lua` defines VIP0..VIP15. Thresholds run from VIP1=30 to VIP15=500000 cumulative charge. A source scan finds 72 direct `xyd.tables.vip:*` calls across 45 Lua files and 23 accessor families. VIP therefore must become a central policy service/PrivilegeResolver before dependent features. Raid-ticket quantity is a VIP field, but Daily Mission/Task UI owns the daily claim lifecycle.

## VIP rewards
VIP1..15 each map to one `reward_item` gift and are claimed via MID657 `GET_VIP_AWARD` with request `{id=vip_level}`. The client persists/reads `vip_awards[level]` and requires a non-empty status table.

## Separate progression delta
`charge_list.lua` has 23 special purchase rows and explicitly separates `vip_exp`, `diamond`, and price/charge. This proves the settlement layer must carry an independent VIP-progression delta rather than deriving VIP progress from awarded Crystal globally.

## Skin commerce
The current effective avatar mall has 32 rows: 16 Crystal rows and 16 skin-fragment/skin-coin rows. It has zero active real-money rows and zero charge IDs. Non-cash skin purchases use MID2981. Generic code for native real-money skin purchases still exists and RECHARGE can carry `items + skin_ids`, but current source does not advertise a cash skin SKU; do not invent one by default.

## Backend reality
The frozen backend already has player fields for `vip`, `charge`, card days and `vip_awards`, plus a special RECHARGE projection profile, but MID354 is an empty stub and the established profile forces `vip=15` without coherent cumulative `charge`. Existing Skill Point and Summon policies already consume raw VIP.

## Recommended implementation architecture (not authorized in Pass85)
1. RechargeCatalogService (MID354 + charge_count/last_buy_time).
2. PurchaseIntentBridge (native/external boundary; missing from current canonical bundle).
3. AutoAuthorizePurchaseProvider for private-server policy.
4. CommerceProductPolicy with independent Crystal/VIP/entitlement effects.
5. CommerceSettlementService with exactly-once UoW receipt.
6. VipProgressionPolicy + VipPrivilegeResolver.
7. VipAwardService (MID657).
8. SkinMallService (MID2981) separate from cash recharge.
9. Existing RECHARGE_PUSH projector for client-compatible completion.

The safest first implementation slice, if later authorized, is direct Crystal recharge + coherent VIP progression/privilege authority + VIP claims. Full ordinary Store, giftbags/cards and nonexistent current cash-skin SKUs should remain separate.
