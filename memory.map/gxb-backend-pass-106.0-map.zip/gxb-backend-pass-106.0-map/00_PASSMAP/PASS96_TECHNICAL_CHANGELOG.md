# Pass96.0 Technical Changelog

Pass96 implements the bounded Global Economy/VIP cleanup mapped in Pass95. Backend artifact: `gxb-backend-v0.12.1-pass96.0.zip` (b6b0f7a9df9f408bddfca5cf84c31f3fbfa754cd021d25796496ce00dab3028c). Status: **STATIC/SELF-TEST ACCEPTED — CLIENT RUNTIME PENDING**.

## Implemented

- Academy authority is source level 100, not 200. Max-level EXP is kept at or below 613614 to avoid `SelfPlayer.lua` transiently stepping to level101.
- A 5,838-row source `item.lua` stack catalog now enforces positive stack ceilings in canonical InventoryRepository/PlayerUnitOfWork settlement. Legacy-overfull stacks remain consumable downward; no overflow-mail behavior was invented.
- UID `13371337` receives one-shot `pass96_debug_account_normalization_v1`: level100 / EXP579615 / max_lev100 / max_energy160, existing seeded 999+ stacks lowered only when above900, cap99 stacks lowered only when above90, and consumed lower quantities preserved.
- Campaign multi-sweep requires VIP `quick_sweep` (VIP4+) or an already-active Monthly Privilege. Single sweep is unchanged.
- Hero preset save enforces source `preset_num` (10 at VIP0 through20 at VIP15).
- SX/Soul Box is unchanged because client QA confirmed the existing mutating purchase path already correctly requires VIP9.

## Validation

Focused Pass96 tests, a real fresh-sandbox import simulation, compileall, and historical Pass68/69/70/72/73/75/83/87/89/91/92/94 suites pass. The old broad `selftest_campaign_economy.py` still fails at the same pre-existing Summon assertion on untouched Pass94 and is not a Pass96 regression.

## Next gate

Run focused client smoke for the Pass96 cleanup and reconcile it. Only after clean runtime acceptance resume shared `RandomOutcomeService`, then Summon migration, Girls/Equipment economy closure, and finally Campaign repeat RNG/MID117.
