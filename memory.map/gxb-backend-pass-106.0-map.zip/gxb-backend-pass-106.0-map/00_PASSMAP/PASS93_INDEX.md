# Pass93 Index

- `00_PASSMAP/PASS93_TECHNICAL_REPORT.md` — human technical report.
- `00_PASSMAP/PASS93_RUNTIME_ACCEPTANCE_PASS92.json` — MID116 runtime acceptance.
- `00_PASSMAP/PASS93_DEBUG_RECONCILIATION.json` — debug findings, including separate MID97 gap.
- `00_PASSMAP/PASS93_GLOBAL_ECONOMY_REALITY_CHECK.json` — next architecture seam.
- `00_PASSMAP/PASS93_SRC64_FEEDBACK_LOOP.json` — source proof used in this pass.
- `00_PASSMAP/PASS93_RNG_RECONCILIATION.json` — RNG dependency status.
- `00_PASSMAP/PASS93_PHASED_ROADMAP.json` — continuation sequence.
- `00_PASSMAP/PASS93_VALIDATION.json` — validation record.
- `00_PASSMAP/databases/GAME_KNOWLEDGE_CATALOG_PASS93_0.sqlite` — current machine database.

Database project tables: 452; integrity: ok.
