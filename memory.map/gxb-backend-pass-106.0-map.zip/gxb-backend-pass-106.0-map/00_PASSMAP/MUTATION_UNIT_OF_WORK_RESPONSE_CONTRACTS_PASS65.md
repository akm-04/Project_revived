# Pass65 — Mutation, UnitOfWork & Projection Contracts

## MutationPlan

A `MutationPlan` is immutable planning data. It contains origin, bound actor, expected logical state version, operation-specific idempotency specification, typed preconditions, typed leaf operations, and explicitly staged semantic events. It never persists state.

Supported operation families are RESOURCE, STACK, ENTITY, GENERATED_INSTANCE, TEMPORAL, COUNTER, FUNCTION and RECEIPT. Arbitrary dictionary patches and direct cross-owner writes are excluded by contract.

## MutationResult

A committed result exposes status, authoritative server commit time, before/after logical versions, committed journal, optional owner versions, receipt reference and non-authoritative projection hints. Validation/rollback paths do not masquerade as committed results.

## Journal

Each journal entry is sequenced and identifies logical owner, category, typed subject, action, minimal before/after state, optional delta and projection tags. Resource projection consumes the canonical `after` value; a delta alone is never enough to construct `economy_`.

## UnitOfWork

The one-player `PlayerState` blob remains the first physical commit unit. The UoW requires one outer commit, joined nested operations, rollback on any failure, atomically persisted receipts, post-persistence journal publication and one logical version increment per durable command.

Idempotency modes are NONE, REQUEST_KEY, DOMAIN_RECEIPT and CONTENT_CLAIM. Do not deduplicate repeatable operations using payload hashes.

## ResponseProjector

Projection is read-only and post-commit. Journal semantics are primary; the Pass42.14 five-field state-diff projection is only a temporary fallback. `economy_` uses cumulative post-state and touched fields, reset envelopes are explicit, inventory/entity rewards stay on their own channels, and rolled-back semantics are silent.
