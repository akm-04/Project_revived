# Pass100 Index

- `00_PASSMAP/PASS100_TECHNICAL_REPORT.md` — runtime reconciliation and implementation report.
- `00_PASSMAP/PASS100_RUNTIME_RECONCILIATION.json` — Pass99 runtime acceptance evidence.
- `00_PASSMAP/PASS100_MID97_OTA_BRIDGE.json` — patched request identity/retry contract.
- `00_PASSMAP/PASS100_MID97_IMPLEMENTATION.json` — server ownership, authorization, and atomic settlement.
- `00_PASSMAP/PASS100_SRC64_FEEDBACK_LOOP.json` — effective source authority and hashes.
- `00_PASSMAP/PASS100_OTA_CUMULATIVE_PRESERVATION.json` — cumulative 1.631.4 package preservation facts.
- `00_PASSMAP/PASS100_VALIDATION.json` — static/self-test/fresh-extraction gates.
- `00_PASSMAP/PASS100_CLIENT_TEST_PLAN.md` — runtime acceptance smoke.
- `00_PASSMAP/PASS100_PHASED_ROADMAP.json` — continuation after MID97.
- `00_PASSMAP/databases/GAME_KNOWLEDGE_CATALOG_PASS100_0.sqlite` — current authoritative machine database.

Backend `v0.12.4`; OTA `1.631.4`; Pass99 runtime accepted; Pass100 client runtime pending.
