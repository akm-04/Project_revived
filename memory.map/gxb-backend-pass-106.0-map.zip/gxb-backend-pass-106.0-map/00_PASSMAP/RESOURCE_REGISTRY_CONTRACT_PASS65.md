# Pass65 — ResourceRegistry 47-Field Matrix

This matrix is architecture policy, not recovered original-server code. Source-derived semantics remain in the Phase1 evidence tables.

| # | wire key | owner | mutation | temporal/reset/cap | projection | evidence |
|---:|---|---|---|---|---|---|
| 1 | `exp` | PlayerProgressionService / player | GRANT_ONLY_VIA_PROGRESSION | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 2 | `charge` | CommerceEntitlementService / recharge_vip | GRANT_ONLY_VIA_COMMERCE | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 3 | `mana` | EconomyLedger / global | CREDIT_DEBIT | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 4 | `crystal` | EconomyLedger / global | CREDIT_DEBIT | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 5 | `vip` | CommerceEntitlementService / recharge_vip | DERIVED_CANONICAL_ONLY | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 6 | `arena_coin` | EconomyLedger / pvp | CREDIT_DEBIT | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 7 | `march_coin` | EconomyLedger / march | CREDIT_DEBIT | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 8 | `top_coin` | EconomyLedger / pvp | CREDIT_DEBIT | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 9 | `guild_coin` | EconomyLedger / guild | CREDIT_DEBIT | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 10 | `region_coin` | EconomyLedger / pvp | CREDIT_DEBIT | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 11 | `honor_coin` | EconomyLedger / guild_war | CREDIT_DEBIT | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 12 | `king_coin` | EconomyLedger / region_arena | CREDIT_DEBIT | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 13 | `lucky_coin` | EconomyLedger / scratch_card_event | CREDIT_DEBIT | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 14 | `paradise_coin` | EconomyLedger / fantasy_illusion | CREDIT_DEBIT | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 15 | `god_war_coin` | EconomyLedger / academy_arena | CREDIT_DEBIT | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 16 | `spirit_stone` | EconomyLedger / horcrux_gods_trial | CREDIT_DEBIT | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 17 | `energy` | EnergyResourceOwner / global_pve | MATERIALIZE_THEN_CREDIT_DEBIT | regen.energy.300s; NATURAL_CAP_TABLE_DERIVED_NOT_HARD_MAX | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 18 | `spirit_energy` | SpiritEnergyResourceOwner / gods_trial | MATERIALIZE_THEN_CREDIT_DEBIT | regen.spirit_energy.360s.fixed180; NATURAL_CAP_180_NOT_HARD_MAX | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 19 | `skill_point` | SkillPointResourceOwner / hero_progression | MATERIALIZE_THEN_CREDIT_DEBIT | regen.skill_point.300s.vip_cap; NATURAL_CAP_VIP_DERIVED_NOT_HARD_MAX | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 20 | `magic_dust` | EconomyLedger / event_centre | CREDIT_DEBIT | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 21 | `magic_liquid` | EconomyLedger / event_centre | CREDIT_DEBIT | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 22 | `magic_energy` | EconomyLedger / event_centre | CREDIT_DEBIT | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 23 | `friendship_coin` | EconomyLedger / social | CREDIT_DEBIT | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 24 | `friend_medal` | EconomyLedger / tea_talk | CREDIT_DEBIT | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 25 | `summon_coin` | EconomyLedger / summon | CREDIT_DEBIT | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 26 | `lvbu_coin` | EconomyLedger / lvbu_event | CREDIT_DEBIT | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 27 | `magic_exp` | EconomyLedger / event_centre | CREDIT_DEBIT | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 28 | `degree_cer` | EconomyLedger / inscription | CREDIT_DEBIT | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 29 | `graduate_cer` | EconomyLedger / inscription | CREDIT_DEBIT | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 30 | `patent_cer` | EconomyLedger / inscription | CREDIT_DEBIT | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 31 | `conquer_lev` | ConquestAggregate / conquest | DOMAIN_COMMAND_ONLY | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 32 | `conquer_loop_id` | ConquestAggregate / conquest | DOMAIN_COMMAND_ONLY | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 33 | `conquer_region` | ConquestAggregate / conquest | DOMAIN_COMMAND_ONLY | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 34 | `team_dungeon_coin` | EconomyLedger / guild_team_campaign | CREDIT_DEBIT | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 35 | `occult_ticket` | SorceryWarAggregate / sorcery_war | DOMAIN_GUARDED_CREDIT_DEBIT | MODE_CAP_UNKNOWN_FAIL_CLOSED | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 36 | `ice_core` | EconomyLedger / ice_event | CREDIT_DEBIT | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 37 | `skin_fragment` | EconomyLedger / ultra_skin | CREDIT_DEBIT | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 38 | `tutor_coin` | EconomyLedger / tutor | CREDIT_DEBIT | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 39 | `skin_coin` | EconomyLedger / skin | CREDIT_DEBIT | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 40 | `daily_updates` | DailyResetCoordinator / global_reset | CONTROL_ENVELOPE_ONLY | SERVER_DAILY_UPDATE_ENVELOPE_05_GMT8 | EXPLICIT_CONTROL_ENVELOPE | CONFIRMED |
| 41 | `updates` | DailyResetCoordinator / global_reset | CONTROL_ENVELOPE_ONLY | SERVER_DAILY_UPDATE_ENVELOPE_05_GMT8 | EXPLICIT_CONTROL_ENVELOPE | CONFIRMED |
| 42 | `invitation` | ArenaInvitationResourceOwner / arena | DOMAIN_GUARDED_MATERIALIZE_CREDIT_DEBIT | regen.invitation.1800s.source_drift; NATURAL_CAP_SOURCE_DRIFT_FAIL_CLOSED | COMPATIBILITY_SUPPRESS_UNTIL_ARENA_SOURCE_DRIFT_RESOLVED | CONFLICTING_SOURCE_DRIFT |
| 43 | `social` | SocialResourceOwner / social | DOMAIN_GUARDED_CREDIT_DEBIT | HARD_CAP_1000_SOURCE_CONFIRMED | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 44 | `lev` | PlayerProgressionService / player | DERIVED_SET_BY_PROGRESSION_ONLY | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 45 | `glory` | ArenaAggregate / arena_legacy | DOMAIN_METRIC_UPDATE_ONLY | domain/default | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
| 46 | `point` | UNKNOWN / unknown | FAIL_CLOSED | domain/default | NO_GENERIC_PROJECTION_UNTIL_OWNER_PROVEN | UNKNOWN |
| 47 | `glue` | EconomyLedger / dormitory | CREDIT_DEBIT | daily_floor.glue.100@05:00+08; DAILY_FLOOR_100_AT_05_GMT8; PURCHASE_HOLDING_GATE_300_NOT_HARD_MAX | ECONOMY_CUMULATIVE_POST_COMMIT_VALUE | HIGH_CONFIDENCE |
