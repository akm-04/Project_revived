# Pass95 Index

- `00_PASSMAP/PASS95_TECHNICAL_REPORT.md` — human research/reconciliation report.
- `00_PASSMAP/PASS95_RUNTIME_ACCEPTANCE_PASS94.json` — Pass94 client-smoke acceptance evidence.
- `00_PASSMAP/PASS95_VIP_AUDIT.json` — implemented VIP enforcement/gap audit.
- `00_PASSMAP/PASS95_INVENTORY_STACK_LIMIT_RESEARCH.json` — source per-item cap facts and backend invariant gap.
- `00_PASSMAP/PASS95_DEV_ACCOUNT_NORMALIZATION_PLAN.json` — source-aware sandbox correction design.
- `00_PASSMAP/PASS95_ACADEMY_LEVEL_RESEARCH.json` — source max-level authority and safe dev target.
- `00_PASSMAP/PASS95_SRC64_FEEDBACK_LOOP.json` — mandatory source proof.
- `00_PASSMAP/PASS95_VALIDATION.json` — Pass95 research validation.
- `00_PASSMAP/PASS95_PHASED_ROADMAP.json` — bounded continuation sequence.
- `00_PASSMAP/databases/GAME_KNOWLEDGE_CATALOG_PASS95_0.sqlite` — current machine database.

Pass95 is map-only; backend remains v0.12.0 Pass94 and is runtime accepted.

Database project tables: 473; integrity: ok.
