# Backend Migration Interface Contracts — Pass64

**Planning contracts only; no Python implementation in Pass64.**

These contracts freeze ownership/dependency direction for the migration. Method names are conceptual and may be adjusted before Phase3, but responsibilities and persistence boundaries are authoritative unless a later architecture pass explicitly supersedes them.

## RequestContext

**Layer:** application  
**Responsibility:** Carries actor/session/player binding, MID, operation/idempotency identity, server clock, catalog and request-scoped services.  
**Inputs:** wire request + authenticated binding  
**Outputs:** immutable command context  
**Persistence:** Must not persist game state.  
**Compatibility/migration:** Preserve SDK/engine/chat compatibility edge semantics.

## UnitOfWork

**Layer:** shared_kernel  
**Responsibility:** Single durable mutation boundary for one player now; future multi-entity port.  
**Inputs:** OperationContext + repository views  
**Outputs:** commit/rollback + committed semantic journal  
**Persistence:** No repository persists independently while active; current PlayerState blob may remain physical commit unit.  
**Compatibility/migration:** Old save callbacks delegate to request_save during migration.

## ResourceRegistry

**Layer:** shared_kernel  
**Responsibility:** Maps economy wire key to semantic class, owner domain, mutation/reset/cap policy and projection key.  
**Inputs:** wire/resource key  
**Outputs:** ResourceDescriptor  
**Persistence:** Metadata only; no balances.  
**Compatibility/migration:** Populate from canonical global_economy_fields; unknown point remains fail-closed.

## EconomyLedger

**Layer:** domain_service  
**Responsibility:** Owns fungible scalar balances and scalar crafting materials only.  
**Inputs:** ResourceDelta/ResourceDebit/Credit for descriptors classified scalar_ledger  
**Outputs:** canonical cumulative balances + mutation result  
**Persistence:** Persist current PlayerState scalar fields initially; no hard storage rewrite.  
**Compatibility/migration:** Legacy grant_mana/spend_mana/etc delegate here.

## PlayerProgressionService

**Layer:** domain_service  
**Responsibility:** Owns player EXP/level and level-up effects.  
**Inputs:** progression grants  
**Outputs:** level/exp/function/energy side-effect plan  
**Persistence:** Own exp/lev; energy award settles through resource owner in same UoW.  
**Compatibility/migration:** Replaces progression portion of EconomyRepository.

## TemporalPolicyService

**Layer:** shared_kernel  
**Responsibility:** Materializes rolling regeneration/cooldown/reset/job/counter policies from server time.  
**Inputs:** TemporalPolicyKey + persisted anchor/state + server_now  
**Outputs:** materialized state + staged transition  
**Persistence:** Owner persists anchors/counters; service never uses device-local authority.  
**Compatibility/migration:** SkillPointPolicy becomes adapter to this contract first.

## StackInventory

**Layer:** domain_service  
**Responsibility:** Owns ordinary Backpack stack quantities.  
**Inputs:** typed item refs + quantities  
**Outputs:** stack deltas/snapshots  
**Persistence:** Only stackable Backpack rows; atomic in UoW.  
**Compatibility/migration:** Current InventoryRepository storage shape retained.

## GeneratedInstanceStore

**Layer:** domain_service  
**Responsibility:** Owns unique/generated items and pending candidates.  
**Inputs:** instance/candidate commands  
**Outputs:** instance identifiers/state  
**Persistence:** Separate from Backpack stacks.  
**Compatibility/migration:** New seam; required before Horcrux/Practice/Inscription expansion.

## RewardSettlementService

**Layer:** shared_kernel  
**Responsibility:** Validates/applies typed MutationPlan across economy, inventory, entities and receipts.  
**Inputs:** MutationPlan with debits/credits/entity creates/patches  
**Outputs:** MutationResult + award/projection facts  
**Persistence:** All leaf mutations in caller UoW; no duplicate durable reward ledger.  
**Compatibility/migration:** Current RewardTransactionService/RewardPlan adapt into it.

## HeroAggregateRepository

**Layer:** domain_service  
**Responsibility:** Owns Hero identity/progression/loadout state.  
**Inputs:** hero id + domain command  
**Outputs:** aggregate snapshots/mutations  
**Persistence:** Hero state only; costs settle through leaf owners.  
**Compatibility/migration:** Current HeroRepository becomes adapter during split.

## GearService

**Layer:** domain_service  
**Responsibility:** Owns gear-plane rules: ordinary/Fumo/Practice/Inscription/Element/Spirit/Horcrux boundaries.  
**Inputs:** hero + gear command + catalog facts  
**Outputs:** gear mutation plan/stat-relevant state  
**Persistence:** Does not mutate economy/inventory directly; requests settlement in UoW.  
**Compatibility/migration:** Current HeroEquipmentRepository supplies ordinary-plane migration starting point.

## ResponseProjector

**Layer:** application  
**Responsibility:** Builds wire economy_/awards/new_funcs_/entity deltas from committed mutation semantics.  
**Inputs:** committed MutationResult + canonical snapshots  
**Outputs:** protocol payload additions  
**Persistence:** Read-only; no persistence.  
**Compatibility/migration:** During migration may merge legacy five-field diff projection.

## RngPolicyProvider

**Layer:** policy_port  
**Responsibility:** Resolves evidence/version-scoped RNG policy by domain+operation.  
**Inputs:** domain, operation, version/evidence  
**Outputs:** policy implementation  
**Persistence:** No persistent state except domain-owned counters/receipts.  
**Compatibility/migration:** Existing summon/campaign private policies plug in unchanged.

## BattleAuthorityAdapter

**Layer:** policy_port  
**Responsibility:** Selects client-sim/server-commit/report/audit/fail-closed per mode.  
**Inputs:** mode battle request/result  
**Outputs:** validated settlement fact/report  
**Persistence:** Mode aggregate owns lifecycle; adapter validates battle authority.  
**Compatibility/migration:** WorldRepository campaign split target.

## Hard dependency direction

Transport adapters -> application commands -> domain aggregates/services -> shared leaf owners/policy ports -> infrastructure adapters.

Handlers/transport never mutate `PlayerState` directly once their slice migrates. Reward settlement never calls high-level Mission/World orchestration. Domain progression hooks may request leaf settlement inside the active UoW. Response projection is post-commit/read-only.
