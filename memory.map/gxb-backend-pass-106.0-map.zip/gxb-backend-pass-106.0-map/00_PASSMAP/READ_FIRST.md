# READ FIRST — Pass106 HOT authority

Read HOT/BOOT.json -> HOT/STATE.json -> HOT/RISKS.json -> HOT/ROADMAP.json -> HOT/RNG_REALITY.json -> HOT/QUERY.json, then query `00_PASSMAP/databases/GAME_KNOWLEDGE_CATALOG_PASS106_0.sqlite`. Do not bulk-read historical pass files.

Backend `gxb-backend-v0.13.1-pass105.0.zip` is unchanged. Pass105 is accepted for roadmap continuation; 25 HTTP409 completions were healthy, accepted verticals regressed cleanly, but the exact eight Phase2 session-entry MIDs were not organically emitted and that coverage caveat is preserved.

NEXT: RandomOutcomeService foundation. It must be entropy/policy separated and reuse PlayerUnitOfWork durable receipts. The source-correct standard Summon MID is 50; SUMMON_SUPER_HERO is MID305, not MID70. After MID50 UUID + unchanged-policy Summon migration, move Campaign repeat reward completion ahead of unique-instance/Girls work because SweepWindow settles its returned items as Backpack stacks. src_64 feedback loop remains mandatory.
