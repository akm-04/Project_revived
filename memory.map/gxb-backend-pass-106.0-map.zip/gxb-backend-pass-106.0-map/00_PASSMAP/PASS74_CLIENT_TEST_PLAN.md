# Pass74.0 Client Test Plan

- **Login / persistence baseline:** use anonymous debug UID `13371337`; confirm preserved Hero/inventory state.
- **Emblem Dissolve:** dissolve one known emblem. For `160500603`, verify the emblem count decreases by 1 and `patent_cer` increases by **1,420**; relog and confirm persistence.
- **Quick Enchant:** use Institute Quick Enchant once. Verify **20 Crystals** are consumed, Fumo rises by **150** or the remaining amount to cap, and the client does not freeze.
- **Quick Enchant daily limit:** a second same-day use must not create a second Crystal debit/Fumo grant.
- **Manual Enchant regression:** perform one normal/manual Fumo enchant and confirm MID58 still works.
- **Ordinary Awakening open:** press Awakening gear on an eligible Girl; confirm an Awaken Task appears under Lobby → Missions → Awaken Task.
- **Ordinary stage 1:** claim the first gear/objective stage; confirm stage 2 appears.
- **Wrong Campaign negative probe:** if practical, clear a different Campaign stage and confirm the Awakening task does not complete.
- **Correct Campaign proof:** clear the exact required stage with the required Girl and satisfy its special condition; confirm the task becomes complete.
- **Final ordinary claim:** claim it and verify the Girl awakens / receives awakened state and remains awakened after relog.
- **Blood Awakening:** only if a naturally eligible Girl exists; open, claim stage 1, win the dedicated special battle, claim final stage, and verify completed Blood state persists.
- **Give-up:** if practical, open a disposable ordinary/Blood task and give it up; confirm its row becomes inactive/reopenable, and Blood state resets when applicable.
- **Stone Evolution regression:** perform one valid stone operation. A rejected Stone request should no longer nil-crash because authoritative `evo_info` is returned; a rare rejected MID2608 may temporarily show a local item-count mismatch until Backpack refresh, while the server does not debit it.
- **Persistence:** record Mana, Crystals, inscription certificate balance, and relevant Hero/Awakening state before closing; verify exact persistence on relog.
- **Not a Pass74 failure:** the 1,225-item debug seed may still trigger the client bag-capacity/mail warning.
- **Not a Pass74 failure:** Campaign's normal 6-Energy stage deduction remains deferred to Campaign ownership.
