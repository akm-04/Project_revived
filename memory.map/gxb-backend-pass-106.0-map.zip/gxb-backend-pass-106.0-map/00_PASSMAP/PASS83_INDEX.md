# Pass83.0 Index — MID1 Login Ordering & Temporal Hygiene

Status: implementation complete, static/offline accepted, client smoke pending.

- `00_PASSMAP/MACHINE_BOOTSTRAP_PASS83.json` — startup state.
- `00_PASSMAP/PASS83_LIVE_CHECKPOINT.json` — authoritative artifact/hash/gate.
- `00_PASSMAP/PASS83_IMPLEMENTATION_FACTS.json` — bounded code changes.
- `00_PASSMAP/PASS83_TECHNICAL_CHANGELOG.md` — human technical changelog.
- `00_PASSMAP/PASS83_SRC64_FEEDBACK_LOOP.json` — effective Lua proof for every behavioral modification.
- `00_PASSMAP/PASS83_DAILY_RESET_TEMPORAL_SELFTEST.json` — focused deterministic validation.
- `00_PASSMAP/PASS83_REGRESSION_MATRIX.json` — regression gates.
- `00_PASSMAP/PASS83_CLIENT_TEST_PLAN.md` — runtime acceptance plan.
- `00_PASSMAP/CURRENT_NEGATIVE_MEMORY_PASS83.json` — do-not-regress facts.
- `00_PASSMAP/DAILY_RESET_INTEGRATION_GUIDE.json` — persistent reset integration policy updated for MID1.
- `00_PASSMAP/databases/GAME_KNOWLEDGE_CATALOG_PASS83.sqlite` — authoritative promoted knowledge database.

Next gate: focused Pass83 client smoke and reconciliation. MID116 remains blocked.
