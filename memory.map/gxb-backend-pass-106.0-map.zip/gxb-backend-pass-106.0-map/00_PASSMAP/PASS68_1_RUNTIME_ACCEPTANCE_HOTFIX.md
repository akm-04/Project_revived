# Pass68.1 — Runtime Acceptance Hotfix: Medium Free Summon

**Status:** FINAL — static hotfix and user runtime retest accepted.

Pass68.0's first client smoke was broadly healthy. Login/lobby, Girls, evolution, Hero skill spending, skill-point handling, SX, paid Medium x10, Small summons, Campaign battles/rewards, restart/relogin and client balance reconciliation all completed without Python traceback or HTTP 500.

One isolated inherited gacha defect was runtime-proven: MID50 `SUMMON_HERO` with `summon_type=3`, `summon_index=1` returned `{"error_code":1,"result":[]}` when the established account used the ready Medium free single summon. The client showed an empty popup and had to be restarted.

## Root cause

The backend still classified this tuple as the first tutorial Crystal summon only. Effective `src_64` proves the same tuple remains the ordinary post-tutorial Medium/CrystalFree route, using `crystal_free_time` plus the source-backed `165600`-second (46-hour) rolling cooldown.

## Pass68.1 fix

- Preserve first tutorial Pandaria behavior.
- After tutorial completion, route the same MID50 tuple into a rolling Medium-free transaction.
- Reject the request when its 46-hour cooldown is not ready.
- On success, materialize exactly one result, persist the new `crystal_free_time`, advance a private-server Medium-free result counter, and use a short replay receipt so an immediate transport retry cannot double-settle.
- Add source-exact pool metadata for `200006` and `200014`, which were missing from the packaged private pool catalog.
- Keep the result-counter/RNG carrier explicitly inside `PRIVATE_SERVER_POLICY`; the original hidden server counter/rate-step algorithm is not claimed as recovered.
- Do not alter paid Medium, Small, SX, the Pass68 persistence/UoW/ResourceRegistry foundation, transport routes, or response projection.

## Runtime status

Static validation is clean and the second user runtime retest is accepted. See `PASS68_1_RUNTIME_ACCEPTANCE_FINAL.md` for the final runtime evidence and the explicitly excluded profile-card MID1829 noise.
