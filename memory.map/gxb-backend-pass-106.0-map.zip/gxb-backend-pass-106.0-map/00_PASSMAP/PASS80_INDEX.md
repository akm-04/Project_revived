# Pass 80.0 — Daily Reset / Super Campaign Diagnostic Research

## State
Research-only diagnostic complete. Backend remains frozen at v0.9.9 Pass79. No Python modification occurred.

## Start here
- `MACHINE_BOOTSTRAP_PASS80.json`
- `PASS80_LIVE_CHECKPOINT.json`
- `PASS80_DIAGNOSTIC_REPORT.md`
- `PASS80_BUG_DIAGNOSES.json`
- `PASS80_SOURCE_EVIDENCE.json`
- `PASS80_CORRECTION_PLAN.json`
- `CURRENT_NEGATIVE_MEMORY_PASS80.json`

## Root causes
1. Quick Enchant reset is lost during JSON persistence because recursive extension merging resurrects children of an authoritative empty `daily_consume_state.counts`.
2. Super Campaign MID114 never consumes the mutable remaining `daily_limit`; client trusts the unchanged server row and stays at 3/3.

## Next gate
Pass81 may correct only these defects and their shared persistence ownership issue. MID116/117/118 and new domains remain blocked.
