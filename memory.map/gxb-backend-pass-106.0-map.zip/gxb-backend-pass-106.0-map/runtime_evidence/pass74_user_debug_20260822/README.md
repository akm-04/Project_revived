# Pass74 user runtime smoke — 2026-08-22

SHA-256 debug.zip: `5ece363da58ad81e1d9b4ae06729a894987d68d8a79fdf6d637c84346c71a7fb`

Pass75 triage source: 196 engine requests, 41 distinct MIDs, 0 backend fallbacks, 0 Python tracebacks, 0 HTTP 5xx, and 1 captured client Lua error (`TaskWindow:updateDaily` nil huoyue bootstrap). The smoke also exposed the Stone Evolution canonical empty-map persistence bug and the missing general Campaign Energy ownership now corrected in Pass75.
