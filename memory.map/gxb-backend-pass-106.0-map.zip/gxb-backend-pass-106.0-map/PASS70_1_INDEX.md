# Pass70.1 Index

Current state: **STATIC_ACCEPTED_RUNTIME_PENDING_FOCUSED_RESMOKE**.

- `00_PASSMAP/READ_FIRST.md` — canonical startup.
- `00_PASSMAP/PASS70_0_RUNTIME_DEBUG_FINDINGS.json` — supplied Pass70.0 runtime evidence and isolated MID59 defect.
- `00_PASSMAP/PASS70_1_HOTFIX_FACTS.json` — source-backed atomic Mana/fragment/Hero correction.
- `00_PASSMAP/PASS70_1_SRC64_REALITY_CHECK.json` — post-debug 4,370-file source reality check and 47/30/17 economy ownership boundary.
- `00_PASSMAP/PASS70_1_REGRESSION_MATRIX.json` — compile + predecessor/current static gates.
- `00_PASSMAP/PASS70_1_CLIENT_RETEST_PLAN.md` — focused next runtime gate.
- `00_PASSMAP/PASS70_1_LIVE_CHECKPOINT.json` — resumable current state.
- `00_PASSMAP/databases/GAME_KNOWLEDGE_CATALOG_PASS70_1.sqlite` — current machine-first memory, 189 non-system tables.

Backend: `gxb-backend-v0.9.2-pass70.1.zip` SHA-256 `3098bf72d2d3d3821234c07452f1ce6c6e22ae6cac6f006a61c4e8195daa0560`.

Economy Backbone core is structurally complete after Pass70.1 static validation, but the literal 47-field Global Economy is not fully implemented; Temporal Resources are next after focused runtime acceptance.
