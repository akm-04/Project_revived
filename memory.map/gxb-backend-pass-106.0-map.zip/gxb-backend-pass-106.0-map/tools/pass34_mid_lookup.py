#!/usr/bin/env python3
"""Fast Pass34 MID atlas lookup.

Examples:
  python tools/pass34_mid_lookup.py --mid 90
  python tools/pass34_mid_lookup.py --symbol USE_SKILL_POINT_ITEM
  python tools/pass34_mid_lookup.py --field skill_point
  python tools/pass34_mid_lookup.py --event FIGHT_RESULT
  python tools/pass34_mid_lookup.py --gm-alias mana
"""
from __future__ import annotations
import argparse, json, pathlib, sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
PM = ROOT / "00_PASSMAP"

def load(name):
    return json.loads((PM / name).read_text(encoding="utf-8"))

def compact_mid(rec):
    return {
        "mid": rec.get("mid"),
        "plane": rec.get("plane"),
        "symbols": rec.get("symbols"),
        "backend_symbols": rec.get("backend_symbols"),
        "gm_operation": rec.get("gm_operation"),
        "request_callsite_count": rec.get("request_callsite_count"),
        "request_fields": rec.get("request_fields"),
        "callback_response_fields": rec.get("callback_response_fields"),
        "event_mappings": rec.get("event_mappings"),
        "global_web_response_bus_applies": rec.get("global_web_response_bus_applies"),
        "backend": rec.get("backend"),
        "runtime": rec.get("runtime"),
        "evidence_labels": rec.get("evidence_labels"),
        "source_declarations": rec.get("source_declarations"),
        "source_reference_roles": rec.get("source_reference_roles"),
        "source_reference_files": rec.get("source_reference_files"),
        "request_callsites": [
            {k:c.get(k) for k in ("file","line","function","mid","mid_value","request_raw","request_fields","request_fields_recovered","response_fields") if c.get(k) not in (None,[],{})}
            for c in rec.get("request_callsites",[])[:12]
        ],
        "event_consumers": rec.get("event_consumers"),
        "non_request_reference_sites": rec.get("non_request_reference_sites",[])[:12],
    }

def main():
    ap=argparse.ArgumentParser()
    g=ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--mid", type=int)
    g.add_argument("--symbol")
    g.add_argument("--field")
    g.add_argument("--event")
    g.add_argument("--gm-alias")
    g.add_argument("--owner")
    g.add_argument("--plane")
    g.add_argument("--stats", action="store_true")
    args=ap.parse_args()

    if args.stats:
        obj=load("PASS34_MID_ATLAS_STATS.json")
    elif args.mid is not None:
        idx=load("MID_LOOKUP_INDEX.json"); rec=idx.get(str(args.mid))
        if not rec:
            print(json.dumps({"found":False,"mid":args.mid},indent=2)); return 1
        obj=compact_mid(rec)
    elif args.symbol:
        si=load("MID_SYMBOL_INDEX.json")
        mids=[]; source=si.get("source_symbols",{}).get(args.symbol)
        if source: mids.extend(source.get("all_assignments",[]))
        mids.extend(si.get("backend_or_source_aliases",{}).get(args.symbol,[]))
        if args.symbol in si.get("undefined_source_symbols",{}):
            obj={"symbol":args.symbol,"numeric_mid":None,"status":"referenced_but_undefined","details":load("MID_UNDEFINED_SYMBOLS.json")}
            obj["details"]=[x for x in obj["details"]["entries"] if x["symbol"]==args.symbol]
        else:
            idx=load("MID_LOOKUP_INDEX.json")
            obj={"symbol":args.symbol,"source_symbol":source,"mids":[compact_mid(idx[str(n)]) for n in sorted(set(mids)) if str(n) in idx]}
    elif args.gm_alias:
        si=load("MID_SYMBOL_INDEX.json"); mid=si.get("gm_aliases",{}).get(args.gm_alias)
        if mid is None: obj={"found":False,"gm_alias":args.gm_alias}
        else: obj={"gm_alias":args.gm_alias,"record":compact_mid(load("MID_LOOKUP_INDEX.json")[str(mid)])}
    elif args.owner:
        idx=load("MID_LOOKUP_INDEX.json")
        hits=[]
        for rec in idx.values():
            own=(rec.get("backend") or {}).get("ownership_registry") or {}
            if own.get("owner")==args.owner:
                hits.append(compact_mid(rec))
        obj={"owner":args.owner,"count":len(hits),"records":hits}
    elif args.plane:
        idx=load("MID_LOOKUP_INDEX.json")
        hits=[compact_mid(rec) for rec in idx.values() if rec.get("plane")==args.plane]
        obj={"plane":args.plane,"count":len(hits),"records":hits}
    elif args.field:
        fi=load("MID_FIELD_CONTEXT_INDEX.json")
        mids=sorted(set(fi.get("request",{}).get(args.field,[])+fi.get("callback_response",{}).get(args.field,[])))
        idx=load("MID_LOOKUP_INDEX.json")
        obj={"field":args.field,"request_mids":fi.get("request",{}).get(args.field,[]),"callback_response_mids":fi.get("callback_response",{}).get(args.field,[]),"global_response_bus":fi.get("global_response_bus",{}).get(args.field),"global_economy_inner":fi.get("global_economy_inner",{}).get(args.field),"records":[compact_mid(idx[str(n)]) for n in mids[:80] if str(n) in idx]}
    else:
        ei=load("MID_EVENT_CONSUMER_INDEX.json")
        hits=[]
        for rec in ei.values():
            for em in rec.get("event_mappings",[]):
                if em.get("event")==args.event:
                    hits.append(rec); break
        obj={"event":args.event,"matches":hits}
    print(json.dumps(obj,indent=2,ensure_ascii=False))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
