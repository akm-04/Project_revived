#!/usr/bin/env python3
"""Offline lookup helper for Pass32 ID namespace evidence.

Usage:
  python tools/pass32_id_lookup.py 40001004
  python tools/pass32_id_lookup.py 41001 --assets

This tool does not infer a global semantic type. It prints every audited core
source-table meaning and optional recovered asset paths for the numeric stem.
"""
from pathlib import Path
import argparse, json

ROOT = Path(__file__).resolve().parents[1]
LOOKUP = ROOT / "00_PASSMAP" / "ID_LOOKUP_INDEX.json"
ASSETS = ROOT / "00_PASSMAP" / "ASSET_ID_INDEX.json"

p = argparse.ArgumentParser()
p.add_argument("id", type=int)
p.add_argument("--assets", action="store_true")
a = p.parse_args()
key = str(a.id)
lookup = json.loads(LOOKUP.read_text("utf-8"))["ids"].get(key)
print(json.dumps({"id": a.id, "source_meanings": lookup}, indent=2, ensure_ascii=False))
if a.assets:
    paths = json.loads(ASSETS.read_text("utf-8"))["ids"].get(key, [])
    print(json.dumps({"id": a.id, "asset_paths": paths}, indent=2, ensure_ascii=False))
