#!/usr/bin/env python3
from __future__ import annotations
import argparse, collections, json, os, pathlib, re, hashlib
from typing import Any

ASSIGN_RE = re.compile(r'xyd\.mid\.([A-Za-z0-9_]+)\s*=\s*(\d+)')
REF_RE = re.compile(r'\b(?:xyd|[A-Za-z_][A-Za-z0-9_]*)\.mid\.([A-Za-z0-9_]+)')
FUNC_RE = re.compile(r'^\s*(?:local\s+)?function\s+([^\(]+)\s*\(')
EVENT_MAP_RE = re.compile(r'mid2EventNames_\[[^\]]*\.mid\.([A-Za-z0-9_]+)\]\s*=\s*xyd\.event\.([A-Za-z0-9_]+)')
EVENT_REF_RE = re.compile(r'xyd\.event\.([A-Za-z0-9_]+)')
BACKEND_DIRECT_RE = re.compile(r'"([A-Za-z0-9_]+)"\s*:\s*(self\.[A-Za-z0-9_\.]+)')
BACKEND_MID_RE = re.compile(r'MID\.([A-Za-z0-9_]+)\s*:\s*(self\.[A-Za-z0-9_\.]+)')
RUNTIME_ENGINE_RE = re.compile(r'\[ENGINE IN\]\s+mid=([^\s]+)\s+\((\d+)\)')
RUNTIME_SDK_RE = re.compile(r"\[SDK\]\s+mid='([^']+)'" )


def read_lines(p: pathlib.Path):
    return p.read_text(encoding='utf-8-sig', errors='replace').splitlines()

def function_context(lines:list[str], line_no:int)->dict[str,Any]|None:
    idx=max(0,line_no-1)
    for j in range(idx, max(-1, idx-180), -1):
        m=FUNC_RE.match(lines[j])
        if m:
            return {'name':m.group(1).strip(),'line':j+1}
    return None

def recover_table_fields(lines:list[str], line_no:int, varname:str)->list[str]|None:
    if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', varname or ''):
        return None
    # search backward for nearest assignment of varname to table literal
    pat=re.compile(r'^\s*(?:local\s+)?'+re.escape(varname)+r'\s*=\s*\{')
    start=None
    for j in range(line_no-2, max(-1,line_no-140), -1):
        if pat.search(lines[j]):
            start=j; break
    if start is None: return None
    # collect until brace balance closes; crude but deterministic
    text='\n'.join(lines[start:min(len(lines), line_no)])
    pos=text.find('{')
    if pos<0: return None
    bal=0; end=None; in_s=None; esc=False
    for k,ch in enumerate(text[pos:],pos):
        if in_s:
            if esc: esc=False
            elif ch=='\\': esc=True
            elif ch==in_s: in_s=None
            continue
        if ch in "'\"": in_s=ch; continue
        if ch=='{': bal+=1
        elif ch=='}':
            bal-=1
            if bal==0:
                end=k; break
    if end is None: return None
    body=text[pos+1:end]
    fields=[]
    # line-oriented top-level-ish key scan. nested keys may leak; mark as heuristic at caller.
    for m in re.finditer(r'(?m)^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=', body):
        f=m.group(1)
        if f not in fields: fields.append(f)
    return fields or None

def plane_for_mid(mid:int)->str:
    if mid==20480: return 'center_http'
    if mid==2: return 'update_http'
    if (mid & 36864)==32768: return 'tcp_chat_or_push'
    if (mid & 36864)==36864: return 'gm_http'
    return 'engine_web'

def dominant_tokens(symbols:list[str])->list[dict[str,Any]]:
    c=collections.Counter()
    for s in symbols:
        toks=[t for t in s.upper().split('_') if t]
        if toks:
            c[toks[0]]+=1
            if len(toks)>=2: c['_'.join(toks[:2])]+=1
    return [{'token':k,'count':v} for k,v in c.most_common(6)]

def build_blocks(nums_to_syms:dict[int,list[str]], max_gap:int=1):
    nums=sorted(n for n in nums_to_syms if n < 32000)
    blocks=[]
    if not nums: return blocks
    st=pr=nums[0]
    for n in nums[1:]:
        if n-pr>max_gap:
            ns=[x for x in nums if st<=x<=pr]
            sy=[s for x in ns for s in nums_to_syms[x]]
            blocks.append((st,pr,ns,sy))
            st=n
        pr=n
    ns=[x for x in nums if st<=x<=pr]; sy=[s for x in ns for s in nums_to_syms[x]]
    blocks.append((st,pr,ns,sy))
    out=[]
    for st,pr,ns,sy in blocks:
        out.append({'start':st,'end':pr,'declared_count':len(ns),'span':pr-st+1,'density':round(len(ns)/(pr-st+1),4),'dominant_symbol_tokens':dominant_tokens(sy),'symbols':sy if len(sy)<=40 else sy[:40]+['...']})
    return out

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--src',required=True)
    ap.add_argument('--map-root',required=True)
    ap.add_argument('--backend-root',required=True)
    ap.add_argument('--out',required=True)
    args=ap.parse_args()
    src=pathlib.Path(args.src); mp=pathlib.Path(args.map_root); backend=pathlib.Path(args.backend_root); out=pathlib.Path(args.out); out.mkdir(parents=True,exist_ok=True)

    midfile=src/'app/common/network/mid.lua'; lines=read_lines(midfile)
    assignments=[]; symbol_assign=collections.defaultdict(list); num_assign=collections.defaultdict(list)
    for i,l in enumerate(lines,1):
        m=ASSIGN_RE.search(l)
        if not m: continue
        sym=m.group(1); val=int(m.group(2)); rec={'order':len(assignments)+1,'line':i,'symbol':sym,'mid':val}
        assignments.append(rec); symbol_assign[sym].append(rec); num_assign[val].append(rec)
    effective_symbol={s:recs[-1]['mid'] for s,recs in symbol_assign.items()}
    all_declared_nums=set(num_assign)

    # raw source refs to xyd/alias.mid.SYMBOL
    refs=collections.defaultdict(list); event_refs=collections.defaultdict(list); file_lines={}
    for p in src.rglob('*.lua'):
        rel=str(p.relative_to(src)); ls=read_lines(p); file_lines[rel]=ls
        for i,l in enumerate(ls,1):
            for m in REF_RE.finditer(l):
                s=m.group(1)
                refs[s].append({'file':rel,'line':i,'function':function_context(ls,i),'snippet':l.strip()[:300]})
            for m in EVENT_REF_RE.finditer(l):
                ev=m.group(1)
                event_refs[ev].append({'file':rel,'line':i,'function':function_context(ls,i),'snippet':l.strip()[:300]})

    undefined_symbols=sorted(set(refs)-set(symbol_assign))

    # retained zero-error API audit from exact source snapshot
    audit=json.loads((mp/'tools/api_audit.json').read_text())
    req_by_mid=collections.defaultdict(list); unresolved_requests=[]
    for r in audit['records']:
        rr=dict(r); rel=rr['file']; ls=file_lines.get(rel) or read_lines(src/rel); file_lines[rel]=ls
        rr['function']=function_context(ls,int(rr['line']))
        if not rr.get('request_fields') and rr.get('request_raw'):
            raw=str(rr['request_raw']).strip()
            fields=recover_table_fields(ls,int(rr['line']),raw)
            if fields:
                rr['request_fields_recovered']=fields
                rr['request_fields_recovery']='heuristic_backward_table_assignment'
        mv=rr.get('mid_value')
        if isinstance(mv,int): req_by_mid[mv].append(rr)
        else: unresolved_requests.append(rr)

    callback_summary=json.loads((mp/'API_CALLBACK_CONSUMER_SUMMARY_PASS10.json').read_text())

    # Backend event mappings and global response bus
    backend_lua=file_lines['app/common/network/Backend.lua']
    event_map=collections.defaultdict(list)
    for i,l in enumerate(backend_lua,1):
        m=EVENT_MAP_RE.search(l)
        if m:
            event_map[m.group(1)].append({'event':m.group(2),'file':'app/common/network/Backend.lua','line':i})
    # extract extraWebResponseCheck body until next function
    sidx=next(i for i,l in enumerate(backend_lua) if 'function var_0_1.extraWebResponseCheck_' in l)
    eidx=next(i for i in range(sidx+1,len(backend_lua)) if backend_lua[i].startswith('function '))
    global_fields=sorted(set(re.findall(r'arg_36_1\.([A-Za-z0-9_]+)', '\n'.join(backend_lua[sidx:eidx]))))
    # Nested economy_ consumer contract lives in SelfPlayer.economySyncEvent_.
    selfplayer_rel='app/model/SelfPlayer.lua'; selfplayer_lines=file_lines[selfplayer_rel]
    eco_start=next(i for i,l in enumerate(selfplayer_lines) if l.startswith('function ') and '.economySyncEvent_' in l)
    eco_end=next(i for i in range(eco_start+1,len(selfplayer_lines)) if selfplayer_lines[i].startswith('function '))
    economy_inner_fields=sorted(set(re.findall(r'arg_60_1\.params\.([A-Za-z0-9_]+)', '\n'.join(selfplayer_lines[eco_start:eco_end]))))

    # Separate GM/debug operation plane: ChatWindow.gmOperation maps command aliases to raw 0x9xxx IDs.
    chat_rel='app/windows/ChatWindow.lua'; chat_lines=file_lines[chat_rel]
    gm_start=next(i for i,l in enumerate(chat_lines) if l.startswith('function ') and '.gmOperation' in l)
    gm_end=next(i for i in range(gm_start+1,len(chat_lines)) if chat_lines[i].startswith('function '))
    gm_body=chat_lines[gm_start:gm_end]
    tbl_start=next(i for i,l in enumerate(gm_body) if 'local var_40_0 = {' in l)
    tbl_end=next(i for i in range(tbl_start+1,len(gm_body)) if gm_body[i].startswith('\t}'))
    gm_alias_to_mid={}
    for off,l in enumerate(gm_body[tbl_start+1:tbl_end],tbl_start+1):
        m=re.match(r'\s*([A-Za-z0-9_]+)\s*=\s*(\d+)\s*,?',l)
        if m: gm_alias_to_mid[m.group(1)]=int(m.group(2))
    gm_mid_to_alias=collections.defaultdict(list)
    for a,n in gm_alias_to_mid.items(): gm_mid_to_alias[n].append(a)
    gm_ids=sorted(gm_mid_to_alias)
    gm_field_map={n:set(['player_id']) for n in gm_ids}
    gm_branch_lines={n:[] for n in gm_ids}
    # Top-level if/elseif branches in gmOperation. Evaluate only the simple numeric condition grammar used here.
    top=[]
    for i,l in enumerate(gm_body):
        m=re.match(r'^\t(?:if|elseif)\s+(.+?)\s+then\s*$',l)
        if m and 'var_40_3' in m.group(1): top.append((i,m.group(1)))
    top.append((len(gm_body),None))
    matched_gm=set()
    for idx in range(len(top)-1):
        bi,cond=top[idx]; bj,_=top[idx+1]; body='\n'.join(gm_body[bi+1:bj])
        fields=set(re.findall(r'var_40_2\.([A-Za-z0-9_]+)',body))
        pycond=cond.replace('var_40_3','n').replace('~=','!=').replace(' nil',' None').replace('true','True').replace('false','False')
        if re.fullmatch(r'[n0-9<>=!()\s.orand]+',pycond):
            for n in gm_ids:
                if n in matched_gm: continue
                try: ok=bool(eval(pycond,{'__builtins__':{}},{'n':n}))
                except Exception: ok=False
                if ok:
                    gm_field_map[n].update(fields); gm_branch_lines[n].append({'condition':cond,'line':gm_start+bi+1}); matched_gm.add(n)
    gm_ops={}
    for n in gm_ids:
        gm_ops[n]={'mid':n,'aliases':gm_mid_to_alias[n],'request_fields':sorted(gm_field_map[n]),'source':'app/windows/ChatWindow.lua:gmOperation','branch_evidence':gm_branch_lines[n], 'sent_to_backend': n != 1048576, 'route': ('engine_web' if n==26 else 'gm_http' if (n & 36864)==36864 else 'local_only_or_other')}

    # Existing backend ownership + current dispatcher routes
    own=json.loads((mp/'00_PASSMAP/MID_OWNERSHIP.json').read_text())
    ownership={int(e['mid']):e for e in own.get('entries',[])}
    dispatcher=(backend/'gxb_backend/dispatch/engine_dispatcher.py').read_text()
    current_routes=collections.defaultdict(list)
    for m in BACKEND_DIRECT_RE.finditer(dispatcher): current_routes[m.group(1)].append(m.group(2))
    for m in BACKEND_MID_RE.finditer(dispatcher): current_routes[m.group(1)].append(m.group(2))
    current_routes['VERSION_CHECK_MID'].append('self.center.version_check')
    current_routes['CENTER_DISCOVERY_MID'].append('self.center.center_discovery')
    # protocol mids for route name resolution
    mids_py=(backend/'gxb_backend/protocol/mids.py').read_text()
    backend_name_to_num={m.group(1):int(m.group(2)) for m in re.finditer(r'^\s{4}([A-Za-z0-9_]+)\s*=\s*(\d+)\s*$',mids_py,re.M)}
    backend_route_by_mid=collections.defaultdict(list)
    for name,routes in current_routes.items():
        if name=='VERSION_CHECK_MID': val=2
        elif name=='CENTER_DISCOVERY_MID': val=20480
        else: val=backend_name_to_num.get(name)
        if val is not None:
            for route in routes:
                if route not in backend_route_by_mid[val]: backend_route_by_mid[val].append(route)

    # compatibility safe allow-list
    compat=json.loads((mp/'00_PASSMAP/COMPATIBILITY_SAFE_MIDS.json').read_text())
    def collect_ints(obj):
        vals=set()
        if isinstance(obj,int): vals.add(obj)
        elif isinstance(obj,list):
            for x in obj: vals |= collect_ints(x)
        elif isinstance(obj,dict):
            for k,v in obj.items():
                if k in ('mid','mids','safe_mids','allow_list','allowlist','values','entries') or True:
                    vals |= collect_ints(v)
        return vals
    compat_ints=collect_ints(compat)

    # Runtime observations from canonical source_facts jsonl/txt
    runtime=collections.defaultdict(lambda:{'count':0,'names':collections.Counter(),'files':collections.Counter(),'request_keys':collections.Counter(),'response_keys':collections.Counter(),'handlers':collections.Counter()})
    sf=mp/'source_facts'
    if sf.exists():
        for p in sf.rglob('*'):
            if not p.is_file(): continue
            rel=str(p.relative_to(mp))
            if p.suffix=='.jsonl':
                for line in p.read_text(errors='replace').splitlines():
                    try: j=json.loads(line)
                    except: continue
                    if isinstance(j,dict) and isinstance(j.get('mid'),int):
                        mid=j['mid']; ro=runtime[mid]; ro['count']+=1; ro['files'][rel]+=1
                        if j.get('name'): ro['names'][str(j['name'])]+=1
                        if j.get('handler'): ro['handlers'][str(j['handler'])]+=1
                        req=j.get('request')
                        if isinstance(req,dict):
                            for k in req: ro['request_keys'][k]+=1
                        resp=j.get('response_keys')
                        if isinstance(resp,list):
                            for k in resp: ro['response_keys'][str(k)]+=1
                        elif isinstance(resp,str): ro['response_keys'][f'<{resp}>']+=1
            elif p.suffix in ('.txt','.log'):
                txt=p.read_text(errors='replace')
                for m in RUNTIME_ENGINE_RE.finditer(txt):
                    mid=int(m.group(2)); ro=runtime[mid]; ro['count']+=1; ro['names'][m.group(1)]+=1; ro['files'][rel]+=1
    # deduplicate conceptual counts are intentionally occurrences across retained artifacts, not unique requests

    # raw numeric MIDs outside mid.lua in source
    raw_unknown=[]
    raw_mid_assign=re.compile(r'\bmid\s*=\s*(\d+)')
    direct_req=re.compile(r':request\(\s*(\d+)')
    for rel,ls in file_lines.items():
        for i,l in enumerate(ls,1):
            for m in raw_mid_assign.finditer(l):
                val=int(m.group(1)); raw_unknown.append({'mid':val,'file':rel,'line':i,'kind':'raw_mid_field','declared_in_mid_lua':val in all_declared_nums,'snippet':l.strip()[:300]})
            for m in direct_req.finditer(l):
                val=int(m.group(1)); raw_unknown.append({'mid':val,'file':rel,'line':i,'kind':'literal_backend_request','declared_in_mid_lua':val in all_declared_nums,'snippet':l.strip()[:300]})
    # unique entries
    seen=set(); raw_unknown_u=[]
    for r in raw_unknown:
        k=(r['mid'],r['file'],r['line'],r['kind'])
        if k not in seen: seen.add(k); raw_unknown_u.append(r)

    # Build lookup universe: all declared, raw numeric source, runtime, backend routes
    universe=set(all_declared_nums)|{r['mid'] for r in raw_unknown_u}|set(runtime)|set(backend_route_by_mid)|set(ownership)|{n for n,o in gm_ops.items() if o['sent_to_backend']}
    lookup={}
    for mid in sorted(universe):
        decls=num_assign.get(mid,[])
        symbols=[]
        for d in decls:
            if d['symbol'] not in symbols: symbols.append(d['symbol'])
        # include current backend symbolic aliases for 2/20480 or where different
        own_e=ownership.get(mid)
        backend_symbols=[]
        if own_e:
            backend_symbols=[s for s in own_e.get('symbols',[]) if s not in symbols]
        gm_op=gm_ops.get(mid)
        calls=req_by_mid.get(mid,[])
        req_fields=sorted(set(f for r in calls for f in (r.get('request_fields') or r.get('request_fields_recovered') or []) if f!='<array-item>') | set((gm_op or {}).get('request_fields',[])))
        resp_fields=sorted(set(f for r in calls for f in (r.get('response_fields') or [])))
        # callback summary by any source symbol
        summary_fields=set(); summary_files=set(); summary_calls=0
        for s in symbols:
            sm=callback_summary.get(s)
            if sm:
                summary_fields.update(sm.get('response_fields') or []); summary_files.update(sm.get('files') or []); summary_calls+=sm.get('calls',0)
        resp_fields=sorted(set(resp_fields)|summary_fields)
        source_refs=[]
        for s in symbols:
            source_refs.extend(refs.get(s,[]))
        # keep compact: request callsites are primary, retain representative non-declaration refs for push/event/dispatch paths
        source_ref_files=collections.Counter(x['file'] for x in source_refs)
        def ref_role(x):
            sn=x.get('snippet','')
            if ':request(' in sn: return 'backend_request'
            if ':sendMessage(' in sn: return 'tcp_send'
            if 'mid2EventNames_' in sn: return 'event_mapping'
            if ' == ' in sn or ' ~= ' in sn: return 'comparison_or_dispatch'
            if x.get('file')=='app/common/network/mid.lua': return 'declaration'
            return 'symbol_reference'
        nonreq=[]
        for x in source_refs:
            role=ref_role(x)
            if role not in ('declaration','backend_request'):
                y=dict(x); y['role']=role; nonreq.append(y)
        roles=collections.Counter(ref_role(x) for x in source_refs)
        mid_event_consumers=[]
        for em in sum((event_map.get(s,[]) for s in symbols),[]):
            ev=em['event']; ers=[]
            for er in event_refs.get(ev,[]):
                if er['file']=='app/common/network/Backend.lua' and 'mid2EventNames_' in er.get('snippet',''): continue
                ers.append(er)
            mid_event_consumers.append({'event':ev,'reference_count':len(ers),'references':ers[:30]})
        ro=runtime.get(mid)
        runtime_obj=None
        if ro:
            runtime_obj={'occurrences_in_retained_artifacts':ro['count'],'names':[{'name':k,'count':v} for k,v in ro['names'].most_common()], 'files':[{'file':k,'count':v} for k,v in ro['files'].most_common(12)], 'request_keys':[k for k,_ in ro['request_keys'].most_common()], 'response_keys':[k for k,_ in ro['response_keys'].most_common()], 'handlers':[{'handler':k,'count':v} for k,v in ro['handlers'].most_common()]}
        lookup[str(mid)]={
            'mid':mid,
            'plane':plane_for_mid(mid),
            'source_declared':bool(decls),
            'source_declarations':decls,
            'symbols':symbols,
            'backend_symbols':backend_symbols,
            'gm_operation':gm_op,
            'source_assignment_status':('reassigned_symbol_target' if any(len(symbol_assign[d['symbol']])>1 for d in decls) else 'single_assignment') if decls else 'not_in_mid_lua',
            'request_callsite_count':len(calls),
            'request_fields':req_fields,
            'callback_response_fields':resp_fields,
            'request_callsites':calls,
            'event_mappings':sum((event_map.get(s,[]) for s in symbols),[]),
            'event_consumers':mid_event_consumers,
            'source_reference_count':len(source_refs),
            'source_reference_roles':[{'role':k,'count':v} for k,v in roles.most_common()],
            'source_reference_files':[{'file':k,'count':v} for k,v in source_ref_files.most_common()],
            'non_request_reference_sites':nonreq[:24],
            'global_web_response_bus_applies':plane_for_mid(mid) in ('engine_web','gm_http'),
            'global_web_response_bus_reference':'MID_NAMESPACE_REGISTRY.json#global_web_response_bus',
            'backend': {
                'routes':backend_route_by_mid.get(mid,[]),
                'ownership_registry':own_e,
                'compatibility_safe_allowlist_numeric_match':mid in compat_ints,
            },
            'runtime':runtime_obj,
            'evidence_labels':sorted(set(
                (['source_declared'] if decls else [])+
                (['source_request_callsite'] if calls else [])+
                (['source_gm_command_map'] if gm_op and gm_op.get('sent_to_backend') else [])+
                (['runtime_observed'] if runtime_obj else [])+
                (['backend_explicit_route'] if backend_route_by_mid.get(mid) else [])+
                (['compatibility_allowlisted'] if mid in compat_ints else [])
            )),
        }

    # Undefined symbol index with context/callback evidence and unresolved request records
    undef=[]
    unresolved_by_symbol=collections.defaultdict(list)
    for r in unresolved_requests:
        m=re.search(r'\.mid\.([A-Za-z0-9_]+)$',str(r.get('mid','')))
        if m: unresolved_by_symbol[m.group(1)].append(r)
    for s in undefined_symbols:
        sm=callback_summary.get(s,{})
        undef.append({'symbol':s,'numeric_mid':'unresolved_in_supplied_lua','references':refs[s],'request_callsites':unresolved_by_symbol.get(s,[]),'callback_summary':sm,'classification':'referenced_but_undefined_symbol','warning':'Do not assign a numeric MID from name similarity alone.'})

    # aliases/reassignments
    collisions={
        'symbol_reassignments':[{'symbol':s,'assignments':recs,'effective_last_assignment':recs[-1]['mid']} for s,recs in sorted(symbol_assign.items()) if len({r['mid'] for r in recs})>1],
        'duplicate_assignment_statements':[{'symbol':s,'assignments':recs} for s,recs in sorted(symbol_assign.items()) if len(recs)>1 and len({r['mid'] for r in recs})==1],
        'numeric_multiple_symbols':[{'mid':n,'declarations':recs} for n,recs in sorted(num_assign.items()) if len({r['symbol'] for r in recs})>1],
        'literal_request_uses':[r for r in raw_unknown_u if r['kind']=='literal_backend_request'],
    }

    # source numeric exceptions not declared
    outside=[r for r in raw_unknown_u if not r['declared_in_mid_lua']]
    for n,o in sorted(gm_ops.items()):
        if o['sent_to_backend'] and n not in all_declared_nums:
            outside.append({'mid':n,'kind':'gm_command_map','file':'app/windows/ChatWindow.lua','line':gm_start+1,'declared_in_mid_lua':False,'aliases':o['aliases'],'request_fields':o['request_fields'],'route':o['route']})
    # ensure runtime/backend outside as records too
    for mid in sorted(universe-all_declared_nums):
        if not any(r['mid']==mid for r in outside):
            outside.append({'mid':mid,'kind':'runtime_or_backend_only','file':None,'line':None,'declared_in_mid_lua':False,'snippet':None})

    # Field context inverted index
    field_idx={'request':{},'callback_response':{},'global_response_bus':{f:{'scope':'all successful web responses where field is present','consumer':'Backend.extraWebResponseCheck_'} for f in global_fields},'global_economy_inner':{f:{'scope':'response.economy_ on successful web/GM responses','consumer':'SelfPlayer.economySyncEvent_'} for f in economy_inner_fields}}
    for smid,rec in lookup.items():
        for f in rec['request_fields']:
            field_idx['request'].setdefault(f,[]).append(int(smid))
        for f in rec['callback_response_fields']:
            field_idx['callback_response'].setdefault(f,[]).append(int(smid))
    for section in ('request','callback_response'):
        for f in field_idx[section]: field_idx[section][f]=sorted(set(field_idx[section][f]))

    # callback consumer index compact
    cb_idx={smid:{'mid':rec['mid'],'symbols':rec['symbols'],'fields':rec['callback_response_fields'],'callsites':[{'file':c['file'],'line':c['line'],'function':c.get('function'),'fields':c.get('response_fields',[])} for c in rec['request_callsites'] if c.get('response_fields')]} for smid,rec in lookup.items() if rec['callback_response_fields']}

    # event consumer index compact
    ev_idx={smid:{'mid':rec['mid'],'symbols':rec['symbols'],'event_mappings':rec['event_mappings'],'event_consumers':rec['event_consumers']} for smid,rec in lookup.items() if rec['event_mappings']}

    # backend route index compact
    br_idx={smid:{'mid':rec['mid'],'symbols':rec['symbols'],'backend_symbols':rec['backend_symbols'],'routes':rec['backend']['routes'],'ownership':rec['backend']['ownership_registry'],'compatibility_safe_allowlist_numeric_match':rec['backend']['compatibility_safe_allowlist_numeric_match']} for smid,rec in lookup.items() if rec['backend']['routes'] or rec['backend']['ownership_registry'] or rec['backend']['compatibility_safe_allowlist_numeric_match']}

    # runtime compact
    rt_idx={smid:rec['runtime'] for smid,rec in lookup.items() if rec['runtime']}

    # Numeric patterns: exact contiguous blocks + higher-order observations
    pattern={
      'rule':'Numeric proximity is a research accelerator, never protocol authority. Resolve numeric MID -> plane -> declaration/callsites/callbacks/runtime/backend evidence.',
      'transport_bitmasks':{
        'tcp_chat':{'predicate':'(mid & 36864) == 32768','hex':'(mid & 0x9000) == 0x8000','source':'app/common/network/mid.lua:xyd.isChatRoomMessage'},
        'gm_or_server_push':{'predicate':'(mid & 36864) == 36864','hex':'(mid & 0x9000) == 0x9000','source':'app/common/network/mid.lua:xyd.isGMOperation'},
      },
      'declaration_characteristics':{
        'assignment_count':len(assignments),'unique_symbols':len(symbol_assign),'unique_numeric_values':len(num_assign),'min_mid':min(num_assign),'max_mid':max(num_assign),
        'all_declared_symbols_are_referenced_somewhere':len(set(symbol_assign)-set(refs))==0,
        'referenced_but_undefined_symbol_count':len(undefined_symbols),
      },
      'contiguous_numeric_blocks':build_blocks({n:[r['symbol'] for r in rs] for n,rs in num_assign.items()},1),
      'interpretation':'Most web MIDs are allocated in contiguous feature/domain blocks, often aligned near 16/32 boundaries in the older/core ranges and larger feature clusters in later ranges. This clustering is useful for research navigation but cannot determine request shape, mutation safety, or ownership without callsite evidence.'
    }

    registry={
      'schema_version':1,
      'pass':34,
      'canonical_identity':'numeric_mid',
      'source_root':'effective src_64 snapshot (src_32 byte-identical per canonical source baseline)',
      'mid_lua':{'path':'app/common/network/mid.lua','assignment_count':len(assignments),'unique_symbols':len(symbol_assign),'unique_numeric_values':len(num_assign)},
      'planes':{
        'engine_web':{'routing':'Backend.request -> webRequest_ unless chat/GM bitmask matches','examples':[1,17,39,90,113,114]},
        'tcp_chat_or_push':{'routing':'Backend.request -> tcpRequest_ when xyd.isChatRoomMessage(mid); this same 0x8xxx plane contains chat client messages and server-push/broadcast symbols','bitmask':'(mid & 0x9000) == 0x8000','declared_examples':[32771,32779,32782,32783,32784,32797,36852,36853,36854,36855,36856,36857,36858,36859,36860,36861,36862,36863]},
        'gm_http':{'routing':'Backend.request -> GMRequest_ when xyd.isGMOperation(mid)','bitmask':'(mid & 0x9000) == 0x9000','declared_examples':[], 'note':'No xyd.mid assignment in this snapshot occupies the 0x9xxx GM-operation plane; the routing predicate still exists.'},
        'update_http':{'routing':'UpdateScene raw HTTP payload, not declared in mid.lua','known_mid':2},
        'center_http':{'routing':'UpdateScene center discovery raw HTTP payload, not declared in mid.lua','known_mid':20480},
        'sdk_native_http':{'routing':'Android SDK/account plane; numeric/string identifiers are separate from xyd.mid and must not be merged by value alone','evidence':'SDK_MID_MAP_PASS21.md'}
      },
      'global_web_response_bus':{'source':'app/common/network/Backend.lua:extraWebResponseCheck_','fields':global_fields,'order_note':'On successful web responses extraWebResponseCheck_ runs before MID event dispatch, LoadingProxy removal, and endpoint-local callback. GMRequest_ also invokes the same global check on success. Presence of a global field can matter even when endpoint callback ignores body.','notable_consumers':{'economy_':'dispatch xyd.event.ECONOMY; news.funcIDs receives new_funcs_','extra_drops_':'SelfPlayer.handleRewards','task':'Task.onTaskBackendEvent receives full response','new_funcs_':'SelfPlayer.onNewFuncOpen','redmarks_':'RedMark.onUpdate','server_time':'ServerTime.resetServerTime'},'economy_inner_fields':economy_inner_fields,'economy_consumer':'app/model/SelfPlayer.lua:SelfPlayer.economySyncEvent_'},
      'trust_rules':['mid.lua is declaration evidence, not the complete protocol universe','friendly symbol names never determine compatibility safety','reassigned/undefined symbols must preserve ambiguity','runtime raw IDs 2 and 20480 prove out-of-table engine/update identifiers exist','numeric clustering is research-only, not semantic authority'],
      'lookup_workflow':['numeric MID','transport plane','source declarations/reassignments','request callsites + fields','global response bus','endpoint callback consumers','runtime observations','backend route/owner/status','domain implementation evidence']
    }

    # write
    def dump(name,obj):
        (out/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+"\n")
    dump('MID_NAMESPACE_REGISTRY.json',registry)
    dump('MID_LOOKUP_INDEX.json',lookup)
    dump('MID_COLLISIONS_OR_ALIASES.json',collisions)
    dump('MID_FIELD_CONTEXT_INDEX.json',field_idx)
    dump('MID_CALLBACK_CONSUMER_INDEX.json',cb_idx)
    dump('MID_EVENT_CONSUMER_INDEX.json',ev_idx)
    dump('MID_RUNTIME_OBSERVATIONS.json',rt_idx)
    dump('MID_BACKEND_ROUTE_INDEX.json',br_idx)
    dump('MID_UNDEFINED_SYMBOLS.json',{'count':len(undef),'entries':undef})
    dump('MID_OUTSIDE_MID_LUA.json',{'count':len(outside),'entries':outside})
    dump('MID_NUMERIC_PATTERNS.json',pattern)
    dump('MID_SOURCE_ASSIGNMENTS.json',{'count':len(assignments),'assignments':assignments})
    # Dynamic request expressions: add conservative nearby xyd.mid candidate sets for control-flow dispatch sites.
    dynamic_entries=[]
    for r in unresolved_requests:
        if re.search(r'\.mid\.[A-Za-z0-9_]+$',str(r.get('mid',''))): continue
        rr=dict(r); ls=file_lines[rr['file']]; lo=max(0,int(rr['line'])-220); hi=min(len(ls),int(rr['line'])+8)
        syms=[]
        for l in ls[lo:hi]:
            for mm in REF_RE.finditer(l):
                s2=mm.group(1)
                if s2 in effective_symbol and s2 not in syms: syms.append(s2)
        rr['control_flow_candidate_symbols']=syms
        rr['control_flow_candidate_mids']=sorted(set(effective_symbol[s2] for s2 in syms))
        rr['candidate_warning']='Candidates are nearby control-flow evidence, not proof that every candidate reaches this callsite.'
        dynamic_entries.append(rr)
    dump('MID_DYNAMIC_REQUESTS.json',{'count':len(dynamic_entries),'entries':dynamic_entries})
    dump('MID_GM_OPERATION_INDEX.json',{'count':len([n for n,o in gm_ops.items() if o['sent_to_backend']]),'local_only_helpers':[o for n,o in gm_ops.items() if not o['sent_to_backend']],'entries':{str(n):o for n,o in sorted(gm_ops.items()) if o['sent_to_backend']}})

    # Compact symbol/alias index for fast LLM/human retrieval without scanning the full numeric atlas.
    source_symbol_idx={}
    for sym,recs in sorted(symbol_assign.items()):
        source_symbol_idx[sym]={
            'effective_mid':recs[-1]['mid'],
            'all_assignments':[r['mid'] for r in recs],
            'reassigned':len({r['mid'] for r in recs})>1,
        }
    backend_alias_idx=collections.defaultdict(set)
    for smid,rec in lookup.items():
        mid=int(smid)
        for sym in rec.get('backend_symbols',[]): backend_alias_idx[sym].add(mid)
        for sym in rec.get('symbols',[]): backend_alias_idx[sym].add(mid)
    symbol_index={
        'source_symbols':source_symbol_idx,
        'gm_aliases':{a:n for a,n in sorted(gm_alias_to_mid.items()) if n != 1048576},
        'undefined_source_symbols':{s:{'numeric_mid':None,'status':'referenced_but_undefined'} for s in undefined_symbols},
        'backend_or_source_aliases':{s:sorted(v) for s,v in sorted(backend_alias_idx.items())},
        'lookup_rule':'Numeric MID is canonical identity. Symbols/aliases are evidence-backed lookup conveniences and never compatibility-safety authority.'
    }
    dump('MID_SYMBOL_INDEX.json',symbol_index)

    # stats
    used_declared=set(mid for mid in req_by_mid if mid in all_declared_nums)
    declared_no_request=sorted(all_declared_nums-used_declared)
    no_req_event=set()
    no_req_dynamic=set()
    for mid in declared_no_request:
        syms=[r['symbol'] for r in num_assign[mid]]
        if any(event_map.get(s) for s in syms): no_req_event.add(mid)
    for r in dynamic_entries:
        for mid in r.get('control_flow_candidate_mids',[]):
            if mid in declared_no_request: no_req_dynamic.add(mid)
    tcp_direct=set()
    for mid in declared_no_request:
        rec=lookup[str(mid)]
        if any(x.get('role')=='tcp_send' for x in rec.get('non_request_reference_sites',[])): tcp_direct.add(mid)
    residual=set(declared_no_request)-no_req_event-no_req_dynamic-tcp_direct

    stats={
      'mid_lua_assignments':len(assignments),'mid_lua_unique_symbols':len(symbol_assign),'mid_lua_unique_numeric_values':len(num_assign),
      'source_request_callsites':len(audit['records']),'source_request_numeric_values_resolved':len(req_by_mid),'declared_numeric_values_with_Backend_request_callsites':len(used_declared),'declared_numeric_values_without_Backend_request_callsites':len(declared_no_request),
      'source_symbol_references':sum(len(v) for v in refs.values()),'source_referenced_symbols':len(refs),'referenced_but_undefined_symbols':len(undefined_symbols),
      'raw_numeric_source_MIDs_outside_mid_lua':sorted(set(r['mid'] for r in outside if r.get('file'))),
      'gm_command_numeric_mids_sent_to_backend':len([n for n,o in gm_ops.items() if o['sent_to_backend']]),
      'gm_command_alias_count':len(gm_alias_to_mid),
      'runtime_observed_numeric_mids':len(runtime),'backend_route_or_ownership_numeric_mids':len(set(backend_route_by_mid)|set(ownership)),
      'atlas_numeric_universe':len(universe),'global_response_bus_fields':global_fields,'global_economy_inner_fields':economy_inner_fields,
      'declared_no_request_breakdown':{
        'event_mapped':len(no_req_event),
        'dynamic_request_candidates':len(no_req_dynamic),
        'direct_tcp_send_without_Backend_request':len(tcp_direct),
        'reference_only_or_indirect_or_push_lower_bound':len(residual),
        'note':'Sets may overlap before residual subtraction; categories are research navigation, not proof of runtime non-use.'
      },
      'declared_no_request_values':declared_no_request,
    }
    dump('PASS34_MID_ATLAS_STATS.json',stats)
    print(json.dumps(stats,indent=2))

if __name__=='__main__': main()
