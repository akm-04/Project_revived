# Girl cohort test reference — Pass42.10

Use the narrowest list for the UI/result you are testing:

- `GIRL_SX_IDS.txt` — **73** current SX Girls. Both SX Current/Weekly and Daily Hotspots must come only from here.
- `GIRL_MEDIUM_ORDINARY_POOL_IDS.txt` — **143** effective ordinary Medium full-Hero candidates = **85 recovered + 58 Legacy Soul-Casket extensions**.
- `GIRL_MEDIUM_SOUL_CASKET_EXTENSION_IDS.txt` — the exact **58** added in Pass42.9 because the canonical classifier has positive Soul-Casket type2/type5 fragment-route evidence.
- `GIRL_MEDIUM_FEATURED_ONLY_IDS.txt` — the exact **56** allowed for Medium `SUMMON_LIST_NEW_ADD` / `medium.manual_hero_id`, classified as having no positive type2/type5 acquisition route.

Do not use the loose word “normal” for the Medium test pool: `docs/GIRL_IDS.txt`/the canonical Girl database describes the much broader normal Partner-table Girl universe, while Medium eligibility is a specific subset.

Runtime authority remains the backend machine data (`data/summon_featured_catalog.json` and `data/summon_pool_catalog.json`). These text sheets are generated operator references so a tester can immediately compare a displayed or acquired Hero ID against the intended cohort.

## About the Medium `?` popup

In the Pass42.10 run, the client information popup did not enumerate the private Legacy/Soul-Casket additions, yet the actual paid Medium10 returned SP Aquaris from the 58-Girl extension. Treat that popup as historical/static presentation, **not** as the authority for this private-server extension. Use these generated cohort sheets or the backend machine JSON when validating a roll.
