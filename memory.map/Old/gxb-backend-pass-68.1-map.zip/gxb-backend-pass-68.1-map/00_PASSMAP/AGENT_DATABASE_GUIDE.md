# Agent Database Guide — Pass62

Use `databases/GAME_KNOWLEDGE_CATALOG_PASS62.sqlite` first. It contains normalized domain tables plus Phase62 protocol/mode/catalog/archive-document retrieval tables. Query `phase1_domain_registry_pass62` to find the current state of a domain. Query `retrieval_routes_pass62` for routing. Query `archived_json_documents_pass62` only for old pass JSON detail; use the cold archive only when exact raw bytes/provenance are required. SQLite accelerates retrieval but never outranks effective source.
