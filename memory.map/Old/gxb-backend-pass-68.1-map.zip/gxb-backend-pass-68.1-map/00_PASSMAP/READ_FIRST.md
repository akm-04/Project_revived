# READ FIRST — Pass68.1 FINAL

Current working state: **Pass68.1 FINAL / runtime accepted**. Phase1 closed, Phase2 sealed, Phase3 active.

Backend: `gxb-backend-v0.9.0-pass68.1.zip` SHA-256 `75740eae144d40d8b313d6e0543549699fb4f39aab4807a6f9908d0b8301754f`.
Assets remain unchanged: `89f0f830508b92e5fff6ad53c6a9dae961a14042dbfdf5649008efb8353f5608`.

Pass68 installed Economy Backbone Part 1: merge-preserving persistence metadata, crash-safer JSON commits, PlayerUnitOfWork/state-version/receipt infrastructure, exact 47-key ResourceRegistry, and legacy five-field EconomyRepository compatibility. Pass68.1 fixed one inherited gacha regression: post-tutorial Medium/CrystalFree MID50 `(summon_type=3, summon_index=1)` was incorrectly treated as tutorial-only.

The second client smoke is accepted. Established-player Medium free succeeded and stamped its rolling cooldown; fresh-account registration/tutorial/first free path also succeeded; zero Python traceback and zero HTTP 5xx were observed. Profile-card MID1829/PersonDisplayWindow noise is a separate unsupported surface and is explicitly excluded.

**Next recommended implementation pass, only when user authorizes:** Pass69 Economy Backbone Part 2 — generalized 30-field Scalar EconomyLedger + StackInventory transactional settlement under PlayerUnitOfWork, preserving the old façade. Do not implement Campaign/Vows/Workshop/Pet yet.

## Startup order
1. `00_PASSMAP/STATUS.json`
2. `00_PASSMAP/PASS68_1_RUNTIME_ACCEPTANCE_FINAL.md`
3. `00_PASSMAP/PASS68_1_SECOND_RUNTIME_DEBUG_FINDINGS.json`
4. `00_PASSMAP/PASS68_1_LIVE_CHECKPOINT.json`
5. `00_PASSMAP/PHASE3_ECONOMY_BACKBONE_PART1_PASS68.md`
6. `00_PASSMAP/PASS68_1_RUNTIME_ACCEPTANCE_HOTFIX.md`
7. `00_PASSMAP/CURRENT_NEGATIVE_MEMORY_PASS68_1.json`
8. `00_PASSMAP/databases/GAME_KNOWLEDGE_CATALOG_PASS68_1.sqlite`
9. `00_PASSMAP/QUERY_ROUTER.json`
10. `00_PASSMAP/NEXT_CHAT_CONTEXT_PASS68_1.txt`
