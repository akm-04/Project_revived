# PASS82 DB USE

Open only `databases/GAME_KNOWLEDGE_CATALOG_PASS82.sqlite` as the authoritative machine database.

Start with `pass82_machine_bootstrap`, `pass82_root_causes`, `pass82_runtime_trace`, `pass82_source_feedback`, `pass82_pass83_correction_plan`, and `pass82_live_checkpoint`; then route through `QUERY_ROUTER.json`.

Pass81 tables remain the authoritative correction implementation record; Pass79 tables remain the DailyResetCoordinator contract; Pass78 tables remain reset blast-radius/source research. Effective `src_64` is always final implementation authority.

Do not scan predecessor SQLite files: Pass82 contains the promoted historical database and there is intentionally no second authoritative SQLite snapshot.
