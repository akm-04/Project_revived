# GXB Machine Memory — Pass 90.0

Current passmap authority: Pass90 architecture/reconciliation.
Backend implementation authority: gxb-backend-v0.10.2-pass89.0.zip
Backend SHA256: 6ff3a674fdb8d8754dae2141f799769b01098c985dfd2566ee46fb92b9a8a913
Source SHA256: 89f0f830508b92e5fff6ad53c6a9dae961a14042dbfdf5649008efb8353f5608

Pass89 OTA/native Recharge is fully runtime accepted on a fresh account; user also confirmed restart persistence. Pass90 changes no backend code. Next: Pass91 MID657 VIP awards lifecycle; then Pass92 MID116 paid Super reset after Pass91 smoke. MID117 remains RNG-blocked.

Read `00_PASSMAP/READ_FIRST.md` and `00_PASSMAP/MACHINE_BOOTSTRAP_PASS90.json` first.
