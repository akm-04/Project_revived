# READ FIRST — Pass 90.0

Current machine-memory authority is **Pass 90.0**. The Python backend did not change in this pass; implementation authority remains `gxb-backend-v0.10.2-pass89.0.zip`.

Pass89 is now fully runtime accepted: MID2 OTA 1.631.3 installed/restarted, the Lua bridge intercepted direct Recharge taps, fresh-account authentication was correct, Commerce transactions committed, VIP progressed from 0 to 15, and the user separately confirmed VIP/Crystal persistence after restart.

Start with `MACHINE_BOOTSTRAP_PASS90.json`, then `PASS90_LIVE_CHECKPOINT.json`, the Pass89 runtime acceptance, VIP hardwiring audit, MID657/MID116 architecture files, retry policy, phased roadmap, and finally the Pass90 SQLite authority.

The next bounded implementation is **Pass91 MID657 VIP one-time rewards**. MID116 follows only after Pass91 runtime acceptance. Do not rush MID117 before the system-wide RNG architecture.
