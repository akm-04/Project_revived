# Current handoff

PASS90 CURRENT CONTEXT

Backend implementation authority: gxb-backend-v0.10.2-pass89.0.zip
SHA256: 6ff3a674fdb8d8754dae2141f799769b01098c985dfd2566ee46fb92b9a8a913
Source bundle SHA256: 89f0f830508b92e5fff6ad53c6a9dae961a14042dbfdf5649008efb8353f5608
Backend changed in Pass90: NO.

Pass89 is fully runtime accepted. The source-confirmed MID2 updater installed cumulative resource version 1.631.3 and restarted the client. A fresh account (uid 20000002, player 19700002, region 197) then used the OTA Lua bridge for 25 direct Crystal purchases, all authenticated to that account, progressing from VIP0 to VIP15. The user separately confirmed VIP and Crystal persist after restart.

Pass90 is architecture/reconciliation only. The active implemented VIP consumers (Skill Point/Temporal and Summon/Soul Box) already use VipPrivilegeResolver. Do not bulk-wire incomplete domains.

Next bounded implementation: Pass91 MID657 VIP one-time award lifecycle. Canonical vip_awards must be a non-empty 15-entry 0/1 vector, with source vip.lua reward_item resolved through gift.lua and reward + claim marker committed in one PlayerUnitOfWork. Duplicate claim naturally grants nothing.

After Pass91 runtime acceptance: Pass92 MID116 Super Campaign paid reset. Compose VipPrivilegeResolver num_elite with active Monthly Privilege num_elite=3, use nth refresh_cost, and commit Crystal debit + daily_limit restore + reset_count increment atomically. Do not invent exact-once request dedupe because source MID116 has no operation id and identical requests may be legitimate consecutive resets.

Read MACHINE_BOOTSTRAP_PASS90.json, PASS90_LIVE_CHECKPOINT.json, PASS90_PASS89_RUNTIME_ACCEPTANCE.json, PASS90_VIP_HARDWIRING_AUDIT.json, PASS90_MID657_ARCHITECTURE.json, PASS90_MID116_ARCHITECTURE.json, PASS90_MUTATION_RETRY_POLICY.json, PASS90_PHASED_ROADMAP.json, CURRENT_NEGATIVE_MEMORY_PASS90.json, and GAME_KNOWLEDGE_CATALOG_PASS90.sqlite.
