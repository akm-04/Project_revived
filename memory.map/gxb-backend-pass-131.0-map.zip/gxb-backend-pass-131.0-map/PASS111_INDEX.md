# Pass111.0 Index

MID50 RNG migration implemented. Backend `gxb-backend-v0.14.1-pass111.0.zip` SHA-256 `2af196494a344ac5a4a6f968cc5ac9885bff48ec5aa01fb31e375ec86485e9cb`. See `00_PASSMAP/PASS111_INDEX.json` and `00_PASSMAP/PASS111_TECHNICAL_REPORT.md`.
