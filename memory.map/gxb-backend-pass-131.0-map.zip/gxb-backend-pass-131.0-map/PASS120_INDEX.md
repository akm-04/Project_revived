# Pass120.0 Index

See `00_PASSMAP/READ_FIRST.md`, current HOT authority, `PASS120_TECHNICAL_REPORT.md`, and `GAME_KNOWLEDGE_CATALOG_PASS120_0.sqlite`. Pass120 is design-only; backend remains frozen at v0.15.1-pass117.0. The three Campaign correction architectures are frozen and ready for bounded implementation.
