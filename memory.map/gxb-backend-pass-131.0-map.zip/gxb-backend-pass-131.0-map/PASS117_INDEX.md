# Pass117.0 Index

See `00_PASSMAP/READ_FIRST.md` and current HOT authority. Pass117 Campaign reconciliation is implemented/static accepted; client runtime smoke remains pending.
