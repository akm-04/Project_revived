# Pass120.1 Migration Index

Read `00_PASSMAP/READ_FIRST.md`, HOT, `PASS120_1_LIVE_CHECKPOINT.json`, `PASS120_1_MIGRATION_HANDOFF.md`, accepted Pass120 design files, and `GAME_KNOWLEDGE_CATALOG_PASS120_1.sqlite`. No implementation occurred in Pass120.1.
