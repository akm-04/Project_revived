# Pass119.0 — Targeted Campaign Extrapolation / Original-Server Reality Map

Pass119 is **research only**. Backend remains frozen at `gxb-backend-v0.15.1-pass117.0.zip` SHA-256 `b4d2790be9d34198bd2a62fcfa499060a0cb02c4acab6a24e4c7067a84ffce80`. No Python or OTA file changed.

## 1. Super MID117 daily limits

The recovered `chapter.lua` Super wire membership contains **155 stages**, and every one has source `campaign.lua.daily_limit = 3`. `NewMapDetailWindow` treats `dailyLimit` as remaining attempts: one-sweep sends `sweep_num=1`, multi-sweep sends the current remaining count, and reset is exposed only at zero. `SweepWindow` replaces both `worldMaps_[campaign_id].dailyLimit` and the detail-window value from `response.campaign.daily_limit`; it does not locally decrement ordinary Super sweeps.

The infinite-sweep exploit is therefore a localized server omission, not an RNG/table ambiguity. Pass117 `_sweep_mutation()` atomically settles cost/rewards but never consumes the mutable Super `daily_limit`. Manual MID114 already consumes one attempt, Daily Reset already restores the source baseline, and MID116 already restores a paid block. The existing MID117 UoW is the correct ownership seam for the eventual correction; no new subsystem is needed.

## 2. Challenge progression is a graph, not a chain

Effective source has **144 Challenge campaigns across 7 chapters**, with **7 roots**, **137 validated child edges**, and **22 fan-out nodes**. Every recovered child exists and every child back-link agrees with its parent. Roots are `24111, 24211, 24311, 24411, 24511, 24611, 24711`.

Raw `campaign.lua.next_campaign_id` contains pipe-separated branches such as `24111 -> 24112|24121`. This is critical: both client `CampaignTable.lua` and the current backend `campaign_meta.json` normalize `next_campaign_id` through a single integer, so branch rows collapse to zero. The eventual Challenge projector therefore needs a dedicated source-derived topology catalog rather than the generic Normal/Super next-id field.

`MapWindow.getTrueCampaignInfo()` treats each visible node as three Challenge variants and directly reads the second/third projected row after earlier variants are cleared. That explains the runtime nil dereference after 24111. `MapWindow.createContainer()` makes only projected rows touchable.

All seven roots have raw `last_campaign_id=0`. Challenge globally unlocks only after Normal Chapter16, while the seven roots relate to Normal campaigns in chapters 1–7. This strongly suggests all seven roots can be initially materialized, but no official response capture proves that exact root-seeding policy; it remains explicit strong inference for design.

## 3. Challenge reward plane is deterministic in recovered data

All **144** Challenge rows have `daily_limit=0`, repeat `dropbox=0`, and no sweep reward; the client hides the Challenge sweep panel. Their **539** `init_dropbox` rows use only `10000, 20000, 40000, 60000, 80000` and every value is an exact multiple of 10,000. Thus recovered Challenge init reward quantities are deterministic `increase_rate // 10000`; this slice needs no RandomOutcomeService draws.

For all 144 stages, `campaign.lua.item_display` exactly equals the init-pool item IDs. MID113 can receive battle-visible `items`, while Challenge MID114 also has a separate result-only `items` popup channel. The content math is clear, but design must assign those transport planes carefully so init rewards are never duplicated.

## 4. Manual battle idempotency reality check

Stock `src_64` MID113 sends no operation UUID. Stock MID114 sends no operation UUID and does not echo MID113's `battle_id`. Campaign result handling accepts either transport success or source battle error **30005 (`errorIdFightExist`)**. The protocol therefore points to **server-owned active battle-session/result deduplication**, not a client-held transaction identity spanning the fight.

The current backend already has exactly the seam needed for that model: `player.active_campaign_battle` stores the Campaign tuple, frozen staged DropPlan/items, status/committed state, and terminal response, with older matching/replay helpers. Pass117's cross-request `campaign_battle_op_id` plus dual permanent MID113/MID114 receipts is additive complexity and should be reconsidered rather than extended.

This does **not** change the accepted UUID architecture for MID50 and MID117: those are immediate cost+RNG transactions, and MID50 is runtime proven.

## Backend retrofit reality

No full rewrite is indicated. The three eventual changes can remain modular: Super attempt consumption inside the existing MID117 UoW, Challenge graph/reward projection via a dedicated source catalog on the existing world-map/battle seams, and a bounded simplification of manual Campaign battle coordination back to `active_campaign_battle`. Player EXP/Mana sweep economy and Generated/Unique Instances stay separate.

## Readiness

**Yes — after Pass119 research, I am ready to begin an architecture/design-only pass for all three requested points.** The remaining unknowns are bounded negative memory, not blockers: official capture of initial seven-root Challenge materialization, exact historical 30005 duplicate response shape, and final assignment of Challenge MID113-vs-MID114 item transport without duplication.
