# Pass128.3 Index — Knowledge-System Self-Heal

- `CURRENT/README.md` — new minimal startup kernel.
- `CURRENT/CURRENT_FACTS.jsonl` — canonical claims with epistemic class/provenance.
- `CURRENT/CURRENT_UNKNOWNS.json` — ranked unresolved assumptions.
- `CURRENT/CURRENT_INVARIANTS.json` — current engineering/architecture invariants.
- `CURRENT/CURRENT_ARCHITECTURE.json` — compatibility architecture, explicitly not original-server internals.
- `CURRENT/CURRENT_BLOCKERS.json` — runtime gate.
- `CURRENT/TASK_ROUTING.json` — targeted retrieval routes.
- `CURRENT/NEGATIVE_MEMORY.json` — structured failed hypotheses.
- `CURRENT/SETTLED_DO_NOT_REINVESTIGATE.json` — settled questions.
- `CURRENT/RESEARCH_COMPASS.json` — revisit queue.
- `AUDIT/PASS128_3_*` — epistemic/readiness/contradiction/source/routing/health audits.
- `PASS128_3_MEMORY_HEALTH_REPORT.md` — human report.
- `databases/GAME_KNOWLEDGE_CATALOG_PASS128_3.sqlite` — sole live SQLite.
- `99_ARCHIVE/HISTORICAL_KNOWLEDGE_CATALOGS_PASS116_TO_128_2.tar.zst` — exact predecessor DB archive.
