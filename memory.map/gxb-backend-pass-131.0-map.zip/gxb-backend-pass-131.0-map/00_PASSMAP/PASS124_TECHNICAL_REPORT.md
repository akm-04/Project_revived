# Pass124.0 Technical Report — Campaign Progression Reality Check

## Scope
Research/runtime-acceptance pass only. **No backend or OTA bytes were modified.** Canonical backend remains `gxb-backend-v0.15.4-pass123.0.zip` SHA-256 `68f7403a605d2e707361e17e8ba7bfdee85986cc00bc614f7cccbb1657590fe9`.

## Pass123 smoke review
The supplied `debug.zip` is clean for the observed Campaign flows. Stock-shaped MID113/MID114 completed for Normal, Super and Challenge without Campaign nonzero errors, traceback, or Lua nil-crash evidence. Challenge 24111 first-clear again materialized both raw children 24112 and 24121. Super 1600018 projected its remaining daily limit after settlement. Pass123 manual battle-session rewrite and OTA 1.631.8 are therefore runtime accepted and the Pass123 structural issue is closed.

## Original-server progression shape
The effective `src_64` client consumes two distinct kinds of server state:

1. `SelfPlayer.worldMapEvent_` hydrates **per-campaign rows** for Normal, Super and Challenge, including star, daily limit and reset count.
2. The same response separately hydrates **summary/frontier cursors** (`normal_chapter_id`, `normal_campaign_id`, `super_chapter_id`, `super_campaign_id`) and chapter star/bonus summaries.

A lone pointer cannot encode Challenge branch clears, per-stage stars, Super daily attempt counters, or reset state. The best reconstruction is therefore a **hybrid authority**: durable per-player stage projection plus derived/cached frontier cursors. The exact official database engine/schema remains unrecovered.

## Challenge gate — source-confirmed
`MapWindow.changeToChallenge()` rejects Challenge when campaign 24111 is absent, using `CHALLENGE_ISNOT_OPEN`; the English source translation is **“Unlock after clearing Chapter 16.”** `TaskChallengeCell` also checks player level 80 and then the presence of `worldMaps_[24111]`. Source `chapter.lua` identifies Normal `1600016` as the Chapter 16 terminal stage.

Current Pass123 code was rechecked: it already opens the Challenge projection only when Normal `1600016` has star > 0, with a bounded legacy `normal_chapter_id > 16` fallback only if the canonical row is absent. Therefore **no correction is required to the Challenge timing gate**. The initial choice to seed all seven disconnected Challenge roots after that gate remains a documented compatibility inference, not captured official-server behavior.

## Super gate — two distinct source rules
Super/Elite has two gates that should not be collapsed:

- **Feature availability:** FunctionID 31 (`Elite Campaign`) is level/Academy 11 in `function.lua`.
- **Per-node playability:** `MapWindow` calls `checkNomalCampaignThrough()` before every non-Normal node. For Super, `getTrueCampaignInfo()` maps the visible Normal slot through `campaign:relateCampaign()`. The client refuses entry until the corresponding Normal progress is cleared (`NORMAL_MAP_ALERT`: “After clearing normal level to unlock”).

The exact official server algorithm for advancing/materializing `super_chapter_id` / `super_campaign_id` is **not exposed by the recovered client** and must not be invented.

## Backend reality and gap
The backend already stores `player.world_map` as the durable Campaign projection and derives `chapter_info` cursors. This is the right architectural direction and should be retained rather than replaced by a new pointer database.

However, MID113 Normal/Super authorization currently treats source membership + projected row presence as sufficient. The Pass75 `SANDBOX_UID` QA migration deliberately materializes all 155 Super rows, which means a modified/direct client on that QA profile could bypass the Normal prerequisite even though the stock UI blocks it. That QA seed is explicitly private-server test policy, not official progression evidence.

## Recommendation / next action
Create **Pass125 — Campaign Progression Authority / unlock-gating hardening** before Campaign EXP + Mana reconciliation:

- keep per-stage `world_map` rows authoritative;
- keep `chapter_info` as derived/transactional summary cursors;
- preserve the existing Normal-1600016 Challenge gate and raw Challenge projection;
- add server-side Super authorization against the source-related Normal anchor;
- keep FunctionID31 level-11 availability distinct from per-node clearance;
- perform bounded research/runtime probing before altering exact Super cursor/materialization semantics;
- preserve legacy cleared progress and keep broad SANDBOX QA seeding isolated/non-authoritative; no destructive migration.

After Pass125: Campaign Player EXP + Mana sweep economy → RNG final closure → Generated/Unique → Girls/Equipment → deferred vertical slices.

## Passmap health
Promoted SQLite: `PRAGMA integrity_check = ok`; project tables = **717**.
