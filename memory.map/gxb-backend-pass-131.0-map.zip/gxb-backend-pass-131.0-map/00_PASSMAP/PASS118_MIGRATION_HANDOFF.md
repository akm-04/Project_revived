# Pass118.0 Migration Handoff

Canonical backend remains **unchanged** at `gxb-backend-v0.15.1-pass117.0.zip` SHA-256 `b4d2790be9d34198bd2a62fcfa499060a0cb02c4acab6a24e4c7067a84ffce80`. Effective source remains `app-assets/output/assets/src_64` from `all-assest-rechecked.zip` SHA-256 `89f0f830508b92e5fff6ad53c6a9dae961a14042dbfdf5649008efb8353f5608`.

Pass118 is audit-only. New runtime evidence invalidates overall Pass117 Campaign runtime acceptance:

- Challenge uses MID113/MID114 type24, but Pass117 projects only 24111. Clearing it makes `MapWindow.getTrueCampaignInfo()` dereference missing 24112 and softlock. Challenge 24111 first-clear reward rows are source-present and deterministic 10000-rate, but Challenge rewards remain parked.
- Super MID117 is exploitable: stage 1900020 remained at daily_limit=2 across successful 1,1,1,1,2 sweep batches. Pass114/117 `_sweep_mutation()` never consumes the Super daily limit; `SweepWindow` expects the server response to own the remaining count.
- Normal first-clear 1900014 produced no items, but this is plausible under the accepted Bernoulli policy (20.73% zero-occurrence probability). Do not change first-clear policy from one empty result.
- Campaign fixed Juice sweep rewards are already delivered through `items` (e.g. 1900020 Mini Juice x3 + Medium Juice x1). The deferred missing plane is per-sweep Player EXP/Mana `economys` and corresponding cumulative economy mutation. `additional` is separate.

Architecture reality check: stock MID113/MID114 carries no cross-request operation UUID and MID114 does not echo battle_id; BattleCreate accepts `errorIdFightExist=30005`. Keep UUID/UoW for immediate transactional RNG (MID50, MID117), but review/simplify manual battle idempotency before extending Pass117's client UUID state machine. An MID113-only identity for RNG-stage retry protection plus server-side pending-battle/MID114 terminal replay is more source-aligned and should be evaluated in the next design pass.

Generated/Unique Instance work remains paused. Query the Pass118 SQLite tables/technical report first; cold historical passes are provenance only.
