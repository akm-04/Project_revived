# Pass118.0 — Targeted Campaign Bug Investigation II + Architecture Reality Check

## Scope
Research/audit only. Backend remains frozen at `gxb-backend-v0.15.1-pass117.0.zip` SHA-256 `b4d2790be9d34198bd2a62fcfa499060a0cb02c4acab6a24e4c7067a84ffce80`. No Python or OTA behavior is changed in Pass118.

Runtime input: `debug.zip` SHA-256 `89c9bbf2238142cb8a11320334b35bc69b6c1501293c864eae33a72c4846c273`.

Canonical source remains `all-assest-rechecked.zip` SHA-256 `89f0f830508b92e5fff6ad53c6a9dae961a14042dbfdf5649008efb8353f5608`, effective `app-assets/output/assets/src_64`.

## Executive conclusions
1. **Challenge softlock is a projection/progression bug.** Challenge uses ordinary MID113/MID114, not separate battle MIDs. Pass117 only projected Campaign 24111. Once 24111 is cleared, `MapWindow.getTrueCampaignInfo()` immediately dereferences Campaign 24112; because 24112 is absent, the client throws `MapWindow.lua:1446 attempt to index a nil value`. Challenge first-clear rewards are also still parked, so MID113 correctly returned no items under current backend but is incomplete relative to source.
2. **Super MID117 daily-limit exploit is a real Pass114/117 server bug.** Manual MID114 reduced stage 1900020 from 3 to 2. Five later MID117 batches (1,1,1,1,2 sweeps) left it at 2 every time. `_sweep_mutation()` never validates/decrements `daily_limit`. `SweepWindow.lua` trusts `response.campaign.daily_limit` for ordinary sweeps, so the server owns this decrement.
3. **Normal first-clear empty items is plausible RNG, not evidence of failure.** Stage 1900014 has ten independent `init_dropbox` rates under `campaign_first_clear_bernoulli_v1`; probability of zero occurrences is about 20.7328% and expected occurrences are 1.422. The captured empty MID113 result is therefore statistically ordinary. The 30 Crystal first-three-star grant committed correctly.
4. **Juice stack rewards are already present in MID117 `items`.** Stage 1900020 repeatedly returned Mini Juice x3 + Medium Juice x1 as deterministic `sweep_reward` before random repeat items. Across recovered Campaign `sweep_reward`, only Mini/Small/Medium Juice are used; SX/Magic Juice are not part of this fixed ordinary Campaign sweep plane. The real missing economy slice is per-sweep Player EXP/Mana: backend hardcodes `economys=[{exp:0,mana:0}]` and does not credit those cumulative balances on sweep. `additional` is a separate auxiliary/awakening item plane and must not be repurposed for ordinary Juice rewards.
5. **Manual-battle UUID architecture should be simplified in a future design pass.** Stock `src_64` MID113 and MID114 carry no operation identity; MID114 does not even echo MID113 `battle_id`. `BattleCreate` explicitly treats battle error 30005 (`errorIdFightExist`) as compatible with result completion. That is strong evidence the original protocol depended on server-side battle-session/result dedupe. Keep source-native UUID/UoW exactly-once for immediate transactions such as MID50 and MID117. For manual Campaign battles, retaining an MID113-only identity to prevent an RNG staging retry from rerolling is defensible, but requiring that client UUID to span the entire MID113→MID114 lifecycle is not source-required and adds OTA/coordination failure surface.

## 1. Challenge clear audit

### Protocol
Runtime request 34 uses `MID113 FIGHT`, `campaign_id=24111`, `campaign_type=24`. Runtime requests 42 and 43 use `MID114 FIGHT_RESULT` for the same Challenge campaign. Therefore Challenge combat is on the same MID113/MID114 protocol family, with Challenge-specific campaign type 24.

The Pass117 OTA deliberately injects `campaign_battle_op_id` only into Normal/Super Campaign paths, so Challenge requests have no such UUID. That is not itself the softlock root cause.

### Client crash root cause
The captured client error is:

`src_64/app/windows/MapWindow.lua:1446: attempt to index a nil value`

For Challenge, `MapWindow.getTrueCampaignInfo()` groups Challenge campaigns in triples. The Chapter 1 Challenge list begins:

`24111 | 24112 | 24113 | 24121 | 24122 | 24123 | ...`

After 24111 has `star > 0`, the function immediately checks `campaigns[24112].star`. Pass117's projection contains only 24111, so that dereference is nil and the map softlocks.

`BattleCreate.campaignResult()` also treats a returned *different* Campaign row with `star == 0` as `newOpenCampaignId`, corroborating that successful Campaign progression responses are expected to materialize newly opened rows rather than leaving a sparse map.

### Challenge reward gap
Pass117 intentionally restricts first-clear RNG to wire Campaign types Normal=1 and Super=2. Challenge is parked. Source metadata for 24111 nevertheless has `init_dropbox=924111` with three deterministic 10000-rate rows:

- 50001121 — 100 Energy — 10000
- 50001125 — 10k Powder — 10000
- 50001129 — 10k Liquid — 10000

Thus the observed Challenge MID113 `items=[]` is not a low roll. It reflects an intentionally unimplemented Challenge reward plane. Challenge reward/progression needs its own source-bounded design rather than being force-fit into the Normal/Super battle UUID state machine.

## 2. Super MID117 daily-limit audit

Stage 1900020 has source daily limit 3. The smoke run first completed a manual Super battle; MID114 correctly returned `daily_limit=2`.

Subsequent ordinary MID117 calls were accepted for sweep counts 1,1,1,1,2 and every response still returned `daily_limit=2`, while Energy and rewards continued settling. The exploit is therefore confirmed.

Backend inspection identifies the exact omission: Pass114/117 `_sweep_mutation()` validates the UUID, costs, VIP multi-sweep gate, repeat-pool policy, entropy and inventory mutations, but never validates or mutates Super `daily_limit`.

Effective `SweepWindow.lua` demonstrates ownership: for ordinary sweeps it writes both `worldMaps_[campaign_id].dailyLimit` and map-detail `dailyLimit` directly from `response.campaign.daily_limit`. It does not locally subtract an attempt for ordinary Super Campaign. The server response is authoritative.

A future corrective pass must therefore make Super attempt consumption part of the same MID117 UoW as costs/rewards, with replay returning the already-decremented state and never consuming the limit twice. Exact implementation is deferred from Pass118.

## 3. Normal first-clear audit

Captured first clear:

- MID113 stage 1900014, type 1, UUID present.
- MID113 response `items=[]`.
- MID114 victory returns `star_crystal=30`, current economy/EXP projections and no result-channel items.

Source `init_dropbox` rates for 1900014 are:

`1500, 1677, 1615, 1612, 602, 623, 687, 814, 1990, 3100`

Under the accepted independent Bernoulli compatibility policy, the probability that every row misses is:

`Π(1-rate/10000) = 0.2073276937` ≈ **20.73%**.

Expected occurrences are **1.422**.

Therefore a single zero-item first clear is statistically plausible and does not prove the RNG path failed. `first_display` remains presentation metadata, not a guarantee-all list. There is no source-backed reason to convert this one smoke result into a guaranteed-item policy.

`campaign.sweep_reward` should also not automatically be added to manual battle first clears: no client code directly maps that field into the manual battle reward path. It is a server-owned sweep data plane and current evidence is insufficient to claim it belongs to MID113/MID114 manual battle grants.

## 4. EXP/Juice audit

### Juice item plane
Recovered progression metadata:

- 50001001 Mini Juice — 60 Hero EXP
- 50001002 Small Juice — 300 Hero EXP
- 50001004 Medium Juice — 1500 Hero EXP
- 50001005 SX Juice — 7500 Hero EXP
- 50005182 Magic Juice — 10000 Hero EXP

For tested Super stage 1900020, `campaign.sweep_reward` is exactly:

- Mini Juice x3
- Medium Juice x1

Every captured MID117 response includes these deterministic rows before optional repeat-pool rewards. So the fixed Campaign Juice rewards are working.

Across the recovered ordinary Campaign `sweep_reward` plane the fixed IDs are Mini/Small/Medium Juice; no fixed SX or Magic Juice entry was recovered. SX Juice exists in other campaign/dropbox content families, but not as the ordinary Normal/Super fixed sweep_reward observed here. Magic Juice is not present in recovered Campaign sweep rewards.

### Missing Player EXP/Mana economy plane
`SweepWindow.EconomyItem` consumes per-sweep `{exp,mana}`. For Player EXP it applies `xyd.getStudentExp(base_exp, getExpMulti())` for display; manual `BattleWinWindow` derives the base Player EXP from `campaign.energyCost(campaignID)`. Campaign Mana presentation comes from `CampaignTable.gainMana()` / `campaign.mana_gain`.

Pass114/117 intentionally returns zero `economys` and only projects MID117 costs in cumulative `economy_`. Thus Player EXP and Mana from sweeps are not currently settled. This is a real deferred subsystem, distinct from Juice items.

`additional` is independently credited as Backpack items and is tied to auxiliary/awakening request state (`awake_mission`); it is not the normal Juice channel.

## 5. Architecture reality check: UUIDs and manual battles

### What the stock protocol actually does
Stock `SelectTeamNewWindow.lua` builds MID113 using Campaign ID/type, formation, pet/rent data. There is no operation UUID.

Stock `BattleCreate.campaignResult()` builds MID114 from Campaign ID, star, Campaign type, formation and pet/awakening data. It does not send an operation UUID and does not echo MID113's returned `battle_id`.

The result callback accepts either transport success or application error `errorIdFightExist = 30005` as a compatible completion path. This pattern appears broadly across battle-result families.

### Reality-check verdict
The Pass117 client UUID spanning MID113→MID114 is **not source-native**. It gives strong exactly-once guarantees, but it also adds state transitions, OTA propagation, receipt coupling and supersede logic across a long-lived local battle where the official client clearly expected the server to remember the active fight.

This does **not** mean idempotency should be abandoned:

- **Keep MID50 UUID/UoW:** immediate RNG + cost + outcome; runtime-proven.
- **Keep MID117 UUID/UoW:** immediate sweep cost + batch RNG + reward; correct transaction boundary.
- **Manual battle:** reconsider. The RNG roll occurs at MID113 staging, so an MID113-only retry identity is sufficient to prevent a lost response from rerolling. MID114 can then consume the server's current staged battle session and use a server-side terminal-result replay/dedupe contract compatible with the source's 30005 semantics.

This is a design recommendation only. Pass118 makes no code change and does not roll Pass117 back.

## Recommended next work order
Generated/Unique Instance settlement remains paused.

1. **Critical Campaign correction design:** Super MID117 daily-limit atomic consumption + Challenge contiguous progression/reward contract.
2. **Manual battle idempotency simplification design:** decide whether to reduce the cross-request UUID to MID113-only staging identity plus server-side MID114 session/result replay.
3. **Implement bounded critical fixes and smoke them.**
4. **Campaign sweep Player EXP/Mana design and implementation.** Keep Juice `items` and `additional` separate.
5. Resume broader roadmap only after Campaign runtime acceptance.

No official-server behavior is fabricated by this pass.
