# Pass108.0 — RNG Backbone Stage 1 Closure Report + Stage 2 Baseline

## Executive result

Pass108 closes **Stage 1 Extrapolation** without modifying the backend. Canonical backend remains `gxb-backend-v0.13.1-pass105.0.zip` SHA-256 `b89c76c4c8345e216f1233f27939915a51388997091d454dfe04ac60ebf13d06`. Effective source remains `app-assets/output/assets/src_64` (4,370 files) from `all-assest-rechecked.zip` SHA-256 `89f0f830508b92e5fff6ad53c6a9dae961a14042dbfdf5649008efb8353f5608`.

Stage1 is considered closed because the remaining uncertainty is no longer an *unclassified RNG surface*: all helper-expanded client-local RNG sites are classified, the representative world/mode and event callback chains have been traced to server/client authority boundaries, and declaration/callsite inconsistencies are captured as explicit negative memory. Missing official probability algorithms remain parked rather than invented.

## Pass107 census self-heal: wrappers matter

Pass107's direct `math.random` census was a useful lower bound, but effective `app/common/utils.lua` contains RNG wrappers and battle/minigame modules call `weightedChoise` through imported/local aliases. Pass108 therefore expands the census to direct RNG + helper callsites.

Exact Pass108 helper-expanded census:

- **304 unique Lua files** contain a direct RNG call or recovered helper call.
- `math.random(` exact calls: **348**.
- `math.randomseed(`: **57**.
- `weightedChoise(`: **211**.
- `xyd.randomIndex(`: **13**.
- `xyd.randomlySelectElement(`: **2**.
- `xyd.shuffle(`: **9**.

Every one of the 304 files is classified; **0 remain unclassified**:

| Local plane | Files | Authority |
|---|---:|---|
| Client battle simulation | 213 | local battle/replay; exclude from economy ROS |
| Client presentation | 48 | visual/dialogue/animation/display; exclude |
| Client minigame simulation | 33 | local challenge/physics; server settlement separate |
| Client RNG infrastructure | 4 | helpers/seed/UUID infrastructure; exclude |
| Client-originated random request input | 2 | client chooses submitted value; validate/settle, don't silently reroll |
| Deterministic seeded local selection | 1 | DreamWorld path tie-break |
| Random UI convenience selection | 1 | NewTerm material/recipe UI |
| Non-economic local state | 1 | SelfPlayer fallback with no authoritative economy effect |
| Dormant unused RNG helper | 1 | Zhuge sweep helper; no active settlement callsite |

`xyd.generateUUID()` is specifically classified as **identity entropy**, not gameplay outcome entropy. This preserves the future MID50 source-native UUID bridge while keeping RandomOutcomeService scoped to gameplay outcome mechanics.

## Source authority corrections and closures

### Pet MID781

`Pet:stoneSummonHero()` sends `PET_SUMMON=781` with `{table_id = arg:getTableID()}`. The recovered request therefore identifies the Pet table explicitly. Stage1 classification is corrected from “summon-like randomness unproven” to **deterministic server creation by requested table_id** for MID781 itself. This does not prove every returned field is deterministic; it only rejects invented random hatch-species/pool semantics.

### HUNQI_CREATE and dormant declarations

`HUNQI_CREATE=3098` occurs only in `mid.lua`; no active named request/listener callsite is recovered. Active nearby authority is `HUNQI_FIGHT_RESULT=3093` and `HUNQI_GET_CAMPAIGN_INFO=3097`. Seven additional RNG-adjacent symbols likewise occur only in `mid.lua`: `LOAD_GIFTBOX`, `RECEIVE_GIFT_BOX_ITEM`, `TREASURE_GET_PARTNERS`, `CHEST_US_AWARD`, `ACTIVITY_1068_AWARD`, `ACTIVITY_GACHA_BROADCAST`, and `SQ_TURNTABLE_BROADCAST`. Numeric declarations are not sufficient to invent handlers.

### Legacy MagicShop

`app/model/MagicShop.lua` references `LOAD_MAGIC_SHOP`, `SHOP_MAGIC_BUY`, `SHOP_MAGIC_REFRESH` and corresponding events, and MagicShop windows reference `ModelType.MAGIC_SHOP`; those definitions are absent from the active `mid.lua`, `event.lua`, and model enum. `SHOP_MAGIC_UNLOCK=35` survives as the only active defined member. The legacy creation/refresh/buy route is therefore **stale residue / unresolved**, not permission to infer neighboring MID numbers.

### MID150 WISH

`WISH=150` is declared and event-mapped, but no active direct MID150 request/callback callsite is recovered. It is parked as dormant/legacy and must not be conflated with `THIRD_ANNI_WISH` or other Wish activities.

## World/mode closure

- **Adventure:** server returns list/event info; rate-bearing event/card/shop tables establish server-authoritative random selection. Exact trigger/normalization remains opaque.
- **Auction:** server returns `auction_list`; `drop_item/drop_rate` establish random lot composition. Bidding itself is deterministic against a selected lot.
- **Region:** server provides missions and matched opponents; mission `weight` is source policy evidence. Local `RegionEnemyItem` random side choice is presentation.
- **Treasure:** server returns encounter/reward state including `award` and optional `crystal_award`; location tables expose `chest_rate`/`enemy_rate`.
- **Beach:** server `START_BEACH` establishes boss/award state; matchup/boss tables expose `weight`/`queue_rate`; threshold gifts are deterministic and are not folded into RNG.
- **Zhuge:** server returns event IDs, random tasks, summon/sweep/boss outcomes; rate-bearing Zhuge tables are policy evidence. Local model/flower randomization stays presentation; the standalone local sweep helper is dormant relative to authoritative server `result_awards`.

These domains are cataloged now but remain separate parked vertical slices.

## Event-chain closure

Active Snow, Chocolate, Love Letter, Polar Night, Ragnarok, Lukang, Activity1220, Contract Summon, Fifth Anniversary, Square Turntable, Lvbu and Balloon chains are server-outcome/event-state boundaries. Local roulette/slot/spin simulations animate already returned outcomes and are not authoritative RNG.

Balloon is explicitly split: **server RNG generates/materializes the pool**, while the client's chosen `pos` is a deterministic reveal/settlement against that pre-generated state unless later evidence proves a fresh server roll at reveal time.

## Final matrix

The user-requested primary bins are preserved:

1. `CONFIRMED_SERVER_RNG`
2. `DETERMINISTIC_SERVER_SELECTION`
3. `CLIENT_LOCAL_VISUAL_RNG`
4. `UNRESOLVED_PARKED`

Pass108 adds boundary categories where the four-bin model would be semantically unsafe: client-local battle/minigame simulation, client-originated random request input, client identity entropy, deterministic seeded local selection, and non-economic local state. `PASS108_RNG_FINAL_MATRIX.json` contains the definitive family-level authority matrix, while `PASS108_RNG_LOCAL_RANDOM_FINAL_CENSUS.json` contains all 304 local files individually.

The central negative-memory rule remains: **a rate field proves rate-bearing policy data, not the complete official roll algorithm**. Missing Campaign pools, opaque weight normalization, dormant route numbers and event-specific pity/guarantee logic remain fail-closed/parked.

## Stage 2 transition

Because Stage1 is now closed, Pass108 begins Stage2 **design only**. `PASS108_STAGE2_RANDOM_OUTCOME_SERVICE_BLUEPRINT.md/json` records a baseline architecture centered on existing `PlayerUnitOfWork` receipts and the existing Summon policy seam. No Python implementation occurred.

Recommended next pass: **Pass109 Stage2 validation/freeze**, then Stage3 implementation only after architecture acceptance.
