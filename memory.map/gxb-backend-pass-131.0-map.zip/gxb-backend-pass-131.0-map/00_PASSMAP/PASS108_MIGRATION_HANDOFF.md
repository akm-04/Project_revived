# Pass108.0 Migration Handoff — RNG Stage1 CLOSED; Stage2 design started

Canonical backend remains `gxb-backend-v0.13.1-pass105.0.zip` SHA-256 `b89c76c4c8345e216f1233f27939915a51388997091d454dfe04ac60ebf13d06`. **Pass108 made no backend changes.** Canonical source remains `all-assest-rechecked.zip` SHA-256 `89f0f830508b92e5fff6ad53c6a9dae961a14042dbfdf5649008efb8353f5608`, effective `app-assets/output/assets/src_64` (4,370 files).

Read `READ_FIRST.md`, HOT BOOT/STATE/RISKS/ROADMAP/RNG_REALITY/QUERY, then `PASS108_LIVE_CHECKPOINT.json`, `PASS108_RNG_STAGE1_CLOSURE_REPORT.md`, `PASS108_RNG_FINAL_MATRIX.json`, `PASS108_STAGE2_RANDOM_OUTCOME_SERVICE_BLUEPRINT.md`, and `GAME_KNOWLEDGE_CATALOG_PASS108_0.sqlite`. Do not bulk-read cold historical passes.

Pass108 closes Stage1: helper-expanded census = 304 Lua files, zero unclassified. Server/world/event chains are classified to their authority boundaries. Missing official roll formulas, missing Campaign pools, HUNQI_CREATE=3098, WISH=150 and legacy MagicShop are explicit negative memory, not permission to invent behavior.

Stage2 has started **design only**. RandomOutcomeService owns entropy mechanics/namespaces/test injection; domains retain rate/pity/pool policy. Existing PlayerUnitOfWork receipts are the only generic durable replay substrate. Persist materialized outcome/replay payload, never RNG seed/state. Committed retries never reroll.

Before MID50 entropy migration, add source-native per-click UUID identity following MID97; preserve existing Summon probability/pool policy unchanged. Recommended next pass is Stage2 validation/freeze before Stage3 code.

Post-design implementation order remains: RandomOutcomeService foundation → MID50 UUID + unchanged-policy migration → MID117 repeat completion → unique-instance settlement → Girls/Equipment. Unrelated verticals remain parked.
