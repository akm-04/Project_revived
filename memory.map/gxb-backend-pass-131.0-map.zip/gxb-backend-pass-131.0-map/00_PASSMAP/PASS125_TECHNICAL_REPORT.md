# Pass125.0 Technical Report — Progression Gates Extrapolation II

## Scope and freeze
Pass125 is **planning/data-fetching/extrapolation only**. No Python backend, OTA, migration, or gameplay behavior changed. Canonical backend remains `gxb-backend-v0.15.4-pass123.0.zip` SHA-256 `68f7403a605d2e707361e17e8ba7bfdee85986cc00bc614f7cccbb1657590fe9`. Effective source remains `app-assets/output/assets/src_64`.

The Pass124 conclusion remains intact: the source-consistent persistence shape is durable per-stage `world_map` projection plus server-issued summary/frontier cursors. Pass125 does **not** finalize the new architecture; it supplies raw source facts and backend gap data for Pass126 modular design.

## 1. Exact Normal ↔ Super relationship
`CampaignTable.ctor()` stores each `campaign.lua.relate_campaign_id` directly in `relateCampaigns_[campaign_id]`; `CampaignTable:relateCampaign(id)` simply returns that lookup. `ChapterTable` independently parses each chapter's `normal` and `super` lists.

A fresh parser run against the effective `src_64` regenerated the frozen Pass75 Campaign ownership catalog **byte-for-byte** (SHA-256 `ddcb41cb4e55c8b1ca081f9c4dc9a60a2b03e883b945aa4061832bb9c1499830`). Raw census:

- 917 `campaign.lua` rows
- 23 chapters
- 429 Normal chapter-list campaign IDs
- 155 Super chapter-list campaign IDs
- exactly **155 mapped Normal↔Super pairs**
- zero chapter relation mismatches
- zero bidirectional mapping mismatches

The mapping is not arithmetic. Across the 155 pairs the numeric `super_id - normal_id` delta ranges from 6 to 20. The canonical server primitive must therefore be the source relation, not an ID formula.

The relation is also symmetric for every recovered pair: mapped Normal row → Super row, and that Super row's `relate_campaign_id` → the same Normal row. This makes server-side reverse lookup trivial without deriving IDs.

All 155 mapped Normal anchors are source node type **2**; the remaining 274 Normal rows are node type **1** and have no Super counterpart. All 155 Super rows are node type **3**. For every chapter, `chapter.lua.super` exactly equals the ordered non-zero `relate_campaign_id` values of the chapter's Normal major-node sequence.

Representative pairs:
- Chapter 1: `100001 ↔ 100019`
- Chapter 16 terminal Normal: `1600016 ↔ 1600022`
- Chapter 23 terminal Normal: `2300018 ↔ 2300024`

The complete 155-row map is stored as `PASS125_NORMAL_SUPER_RELATION_MAP.csv` and JSON authority.

## 2. What `checkNomalCampaignThrough()` actually proves
For a Super map node, `MapWindow.getTrueCampaignInfo()` starts from the **Normal plot-node ID** and resolves the real Super ID through `campaign:relateCampaign(normal_id)`. Before opening any non-Normal node, the click handler calls `checkNomalCampaignThrough(chapter_id, normal_anchor_id)`.

The recovered predicate blocks when:
1. requested Normal chapter is above `maxNormalChapter`; or
2. Normal anchor ID is above `selfPlayer.normal_campaign_id`; or
3. Normal anchor equals `normal_campaign_id` **and that anchor's `worldMaps_` star is <= 0**.

This is important nuance: the client treats `normal_campaign_id` as an ordered frontier. Normal anchors numerically/source-ordered below that cursor are assumed already cleared; the cursor node itself must have a positive star before its Super counterpart is enterable. This remains a **client gate**, not sufficient server authority.

## 3. Super cursor advancement — source boundary reached
A full `src_64` assignment scan found no client-side advancement algorithm for `super_campaign_id` or `super_chapter_id`.

The client only consumes server-issued cursor values:
- `SelfPlayer.worldMapEvent_`: copies the four Normal/Super cursor fields from `LOAD_WORLD_MAP.chapter_info`.
- `SelfPlayer.worldMapLoginEvent_`: copies the same fields from server login/event params.
- `BattleCreate` FIGHT_RESULT handlers: copy returned `chapter_info` cursor fields.
- `MapWindow.onFightResult`: copies returned cursors and refreshes the maximum visible Normal/Super chapter.

There is no recovered assignment such as `super_campaign_id = relateCampaign(...)`, `next_campaign_id`, `chapter.next_id`, `+1`, or any other local progression calculation.

The FIGHT_RESULT callback separately recognizes a **different returned campaign row with star=0** as `newOpenCampaignId`. This proves the original server could atomically return both a new materialized stage row and updated `chapter_info` after settlement. `super_chapter_id` is used as the maximum navigable Super chapter and Super mode is shown only when it is >0. Other UI treats `super_campaign_id` as a reached/frontier threshold.

What remains unrecovered is the exact server trigger. `src_64` cannot tell us whether:
- the first Super row appeared when FunctionID31 was granted;
- it appeared after a particular Normal anchor clear;
- subsequent Super cursors advanced on prior Super clear;
- advancement waited for the next Normal anchor;
- or the server used an intersection of those conditions.

FunctionID31 itself is also server-authoritative at runtime: `function.lua` documents Elite Campaign as level/Academy 11, but `SelfPlayer.isFuncOpen()` simply checks server-supplied `func_ids/openFuncMap`. The exact original server function-grant event is not in the client.

Therefore Pass125 **does not invent exact cursor timing**. Pass126 must explicitly separate source facts from any compatibility policy it proposes.

## 4. Frozen backend gap map
The current Pass123 backend was audited without modification.

### MID113 authority gap
For Super MID113, `_begin_fight_mutation()` currently validates source Super membership, materialized Super-row presence, remaining daily attempts, and Energy. It does **not** independently validate the Super row's source-related Normal anchor.

### Fresh-player bootstrap gap
Canonical fresh state starts with `world_map.super = []`, `super_campaign_id = 0`, and `super_chapter_id = 0`. No Normal-clear-driven first-Super materialization path was found. In other words, a future production-correct solution must solve both **authorization** and **how the first legitimate Super row appears**; merely adding a deny-check would leave a fresh credential player unable to enter Elite Campaign.

### Current Super progression gap
On successful Super settlement, current backend progression uses the flat source `super_campaign_ids` order and materializes the next Super row without checking that next row's related Normal anchor. That is source-shaped ordering but not source-complete authorization.

### Pass75 QA masking
The anonymous sandbox policy deliberately seeds all 429 Normal rows at star >=1 and all 155 Super rows at star 0. This is legitimate private-server QA policy, but it masks production progression:
- every Normal prerequisite is intentionally satisfied;
- every Super row already exists;
- derived `super_campaign_id` becomes the final source Super ID (`2300024`) and `super_chapter_id` becomes 23 regardless of actual Super clears.

This is exactly why QA data and gameplay authority must be conceptually separate.

## 5. How QA can be decoupled from authority — scout map, not final design
The source gives a clean primitive: for a requested Super ID, its own `campaign.lua.relate_campaign_id` points directly back to the Normal anchor. Pass126 can therefore design an independent Normal-prerequisite check without changing the Pass75 seed and without arithmetic mapping.

Important consequences for design:
- keep the Pass75 seed as explicit `PRIVATE_SERVER_POLICY` test data;
- do not treat Super-row presence as authorization;
- let the fully unlocked sandbox naturally pass the Normal-prerequisite rule because its policy intentionally cleared all Normal anchors;
- use a low-progress non-sandbox fixture to test locked/partial progression, because the fully unlocked sandbox cannot prove negative gates;
- consider whether one shared Super progression-authority component should guard MID113, MID117, and future Super operations so protocol paths cannot drift.

Pass125 intentionally does **not** choose the exact Normal-clear predicate or cursor/materialization policy. Those belong to Pass126 modular design.

## 6. Pass126 design questions
Pass126 must remain **design only** and resolve:
1. direct related-Normal `star>0` vs exact client frontier semantics for the authoritative clear predicate, including legacy saves;
2. relation-catalog API and ownership;
3. shared vs protocol-local Super authorization;
4. first-Super materialization for non-QA players;
5. subsequent Super row/cursor materialization policy and its explicit evidence class;
6. `super_campaign_id` / `super_chapter_id` invariants;
7. non-destructive legacy reconciliation;
8. low-progress + fully unlocked QA test matrix.

Pass127 is the first pass allowed to implement.

## Roadmap
**Pass125 complete → Pass126 modular design only → Pass127 implementation → Campaign Player EXP + Mana sweep economy → RNG final closure → Generated/Unique → Girls/Equipment → deferred vertical slices.**

## Passmap health
Promoted SQLite: `PRAGMA integrity_check = ok`; project tables = **727**. Backend SHA remains `68f7403a605d2e707361e17e8ba7bfdee85986cc00bc614f7cccbb1657590fe9`.
