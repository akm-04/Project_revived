# Pass108 Stage 2 Baseline — RandomOutcomeService Architecture (DESIGN ONLY)

Stage 1 is closed in Pass108. This section **begins Stage 2 Architecture & Design only**. The backend remains `gxb-backend-v0.13.1-pass105.0.zip` SHA-256 `b89c76c4c8345e216f1233f27939915a51388997091d454dfe04ac60ebf13d06` and no Python was modified.

## Design boundary

`RandomOutcomeService` owns **entropy mechanics**, not game policy. Domain code continues to own pools, probability, pity, guarantees, rate-up rules, eligibility filters, costs, and mutation semantics. This boundary is required by the Stage1 source matrix: Summon, Campaign, Practice, generated Rune/Spirit state, shop refreshes, world encounters, and event gachas all expose different domain contracts even when they all need random selection.

It must explicitly exclude authentication/session/token entropy, `xyd.generateUUID()` identity entropy, client battle/minigame simulation, client presentation randomness, deterministic seeded DreamWorld selection, and client-originated random request fields.

## Existing backend fit

The frozen backend already has the correct transaction/idempotency substrate:

- `PlayerUnitOfWork.get_receipt(domain,key)` reads committed receipts.
- `stage_receipt(...)` records request fingerprints and replay payloads inside an active UoW; commit marks them `COMMITTED` together with state.
- MID97 already demonstrates the correct retry ordering: committed receipt lookup occurs before mutable server-day/current-counter checks, then is rechecked inside the transaction.
- `summon_private_policy.py` already isolates classic Summon policy behind `SummonRandomSource.randbelow()`. Stage3 should replace the entropy dependency while leaving current policy untouched.
- Existing `PaidSummonOperationReceiptStore` is a compatibility short-window heuristic, not the future durable repeatable MID50 identity architecture.

Therefore **no second RNG receipt store/database is allowed**.

## Atomic operation model

1. Validate source-proven request and operation identity.
2. Derive canonical receipt key + request fingerprint.
3. Check committed UoW receipt before RNG. Compatible receipt => replay; **never reroll**.
4. Recheck inside UoW.
5. Debit/validate cost in the same transaction.
6. Domain builds eligible pool and weights.
7. RandomOutcomeService performs only the mechanical draw.
8. Domain materializes and applies outcome/proposal/generated-instance mutation.
9. Stage exact replay payload/outcome under the existing UoW receipt and commit costs + outcome + state + receipt atomically.

Persist the committed outcome/replay payload, **not RNG seed/state**.

## Lifecycle-specific rules

- **Immediate grant:** Summon/Campaign-like rolls settle immediately.
- **Proposed result:** Practice/Inscription roll persists candidate(s); SAVE/ABANDON is a later deterministic transition and never rerolls.
- **Unique generated instance:** ROS can choose domain-supplied indices/weights, but Rune/Spirit identity allocation and persistence belongs to the later unique-instance settlement pass.
- **Random stock/encounter:** commit the materialized refresh/day/round state, not a seed.
- **Pre-generated reveal:** Balloon-style selected-position reveal is deterministic against prior server pool state.
- **Client-random request input:** validate and settle submitted values; do not silently replace the client source-native random choice with server RNG.

## Minimal mechanical primitives for design review

The service should remain small: bounded integer entropy, choose-index, weighted-index over already-computed validated weights, and only evidence-required sampling helpers. Test entropy is namespaced and scripted by draw ordinal so an unexpected draw fails loudly.

Suggested namespaces include `summon.classic`, `summon.super`, `summon.magic`, `campaign.repeat`, `gift.open`, `practice.hero`, `practice.pet`, `inscription.rebuild`, `rune.generate`, `spirit.generate`, `shop.refresh`, `event.<id>`, and `world.<mode>`.

## MID50 design constraint

Before MID50 entropy migration, the OTA/client must attach a **source-native per-click UUID operation identity** following the successful MID97 pattern. `xyd.generateUUID()` remains client identity entropy outside RandomOutcomeService. The migration must preserve existing classic Summon probability/pool behavior unchanged.

## Stage status

Stage2 is now **started with a contract-level design baseline ready for review**. Implementation remains not started. A prudent Pass109 is a Stage2 validation/freeze pass before Stage3 code.
