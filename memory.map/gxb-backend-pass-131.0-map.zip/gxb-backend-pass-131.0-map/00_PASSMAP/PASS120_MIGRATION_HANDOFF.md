# Pass120 migration handoff

Backend remains frozen at v0.15.1-pass117.0 (`b4d2790be9d34198bd2a62fcfa499060a0cb02c4acab6a24e4c7067a84ffce80`). Pass120 is design-only. Architecture is frozen for Super MID117 attempt consumption, Challenge source graph/projection/deterministic init rewards, and manual MID113/MID114 simplification back to `active_campaign_battle`.

Next recommended pass: implement the Super MID117 daily-limit exploit fix only. Preserve MID50/MID117 UUID exactly-once. Do not extend Campaign battle UUID. Challenge implementation follows from `PASS120_CHALLENGE_ARCHITECTURE_DESIGN.json`; manual battle simplification/OTA rollback follows from `PASS120_MANUAL_BATTLE_SIMPLIFICATION_DESIGN.json` and `PASS120_OTA_ROLLBACK_MIGRATION.json`.
