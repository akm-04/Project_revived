# Current engineering rules

1. Effective `src_64` feedback loop before every backend behavioral change.
2. Source/research → decide → bounded implementation → static/self-test → client smoke → reconciliation → next subsystem.
3. Never fabricate missing official-server behavior; isolate compatibility policy and label it `IMPLEMENTATION_DECISION`.
4. Preserve raw evidence and historical reports; supersede through CURRENT/HOT registries instead of rewriting history.
5. Do not infer runtime acceptance from static tests.
6. Query CURRENT + the single live SQLite / task routing instead of bulk-reading historical pass narratives or recovering cold catalogs.

## Passmap commit discipline

7. Every state-changing pass or same-pass pre-release repair must synchronize: `CURRENT/`, HOT mirrors, unversioned current pointers, the single live SQLite, `LAST_COMMIT.json`, and a pass-specific commit/checkpoint or audit record.
8. Historical `PASS<n>` reports are immutable provenance. If they are stale, keep them historical and repair only current authority/pointers.
9. Exactly one knowledge SQLite may be live under `00_PASSMAP/databases/`. Superseded catalogs go to hashed cold storage with restore/verification metadata; no `-wal`/`-shm` sidecars may ship.
10. Before release, validate SQLite `integrity_check`, `quick_check`, foreign keys, task-route count, current authority, archive lineage, and backend/source hashes.
11. Regenerate `MANIFEST.json` and `FILE_MANIFEST.sha256` only after all internal passmap edits are complete. Those manifest files exclude themselves to avoid recursion.
12. The final passmap ZIP SHA256 is external/sidecar metadata by design; embedding the ZIP hash inside the ZIP would invalidate it.
13. A packaging/self-heal repair performed before a passmap is first released may remain on the same pass number. Any semantic work after release must advance the pass/subpass.
14. Every final response for a release includes a short commit message plus validated artifact hashes.
