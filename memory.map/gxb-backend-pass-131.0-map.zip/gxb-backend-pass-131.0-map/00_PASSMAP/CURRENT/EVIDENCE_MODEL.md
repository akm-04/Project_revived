# Evidence model — current epistemic contract

This passmap separates **recovered behavior** from **compatibility implementation**. Implementation does not become original-server fact merely because it is clean, accepted, or runtime-tested.

## Allowed epistemic classes

- `SOURCE_FACT` — directly present in the effective `src_64` client/data source.
- `RUNTIME_OBSERVED` — directly observed in a captured runtime. Runtime must state its origin; reconstructed-backend runtime proves our reconstruction behavior, not the original server.
- `STRONG_INFERENCE` — multiple independent evidence surfaces constrain the conclusion strongly, but no direct server proof exists.
- `WEAK_INFERENCE` — plausible, materially underdetermined.
- `IMPLEMENTATION_DECISION` — chosen private-server/compatibility architecture or policy. This is orthogonal to evidence strength and must never be described as recovered server internals.
- `UNKNOWN` — unresolved.
- `DISPROVEN/SUPERSEDED` — prior hypothesis or once-current implementation model invalidated or replaced.

## Evidence hierarchy is domain-sensitive, not one global ladder

For **original-server behavior**, authenticated original-server captures/server artifacts outrank client expectations; direct effective client source/data then constrains protocol-visible behavior; cross-source corroboration supports inference. Local reconstructed-backend runtime does **not** upgrade an original-server claim.

For **client behavior**, direct effective `src_64` is primary; client runtime corroborates exercised paths.

For **our current backend behavior**, real runtime observations outrank focused/regression tests, which outrank static code inspection/design prose.

Every important claim in `CURRENT_FACTS.jsonl` carries a `layer` and `epistemic_class`. If a future agent cannot identify both, it should treat the claim as unresolved rather than flattening it into truth.
