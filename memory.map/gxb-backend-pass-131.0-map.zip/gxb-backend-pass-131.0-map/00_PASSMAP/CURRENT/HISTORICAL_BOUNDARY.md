# Current truth vs historical truth boundary

- `00_PASSMAP/CURRENT/` is the only unversioned conceptual authority.
- `00_PASSMAP/PASS<n>_*`, root/pass indexes, runtime/source evidence, and SQLite predecessor tables are historical snapshots/provenance. They are **not rewritten** to match later conclusions.
- When history conflicts with current understanding, the historical file stays intact and `AUDIT/PASS128_3_CONTRADICTION_SCAN.json` records the supersession.
- Unversioned historical files that looked authoritative were archived verbatim and replaced with routing stubs.
- Historical readiness/frozen/complete language is pass- and subsystem-scoped. It never overrides `CURRENT_STATE.json` or `CURRENT_BLOCKERS.json`.
