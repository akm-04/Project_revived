# CURRENT — minimal startup kernel

Read in this order:
1. `CURRENT_STATE.json`
2. `CURRENT_BLOCKERS.json`
3. `CURRENT_FACTS.jsonl`
4. `CURRENT_UNKNOWNS.json`
5. `CURRENT_INVARIANTS.json`
6. `CURRENT_ARCHITECTURE.json`
7. `TASK_ROUTING.json`
8. `NEGATIVE_MEMORY.json`
9. `EVIDENCE_MODEL.md`
10. `SETTLED_DO_NOT_REINVESTIGATE.json`
11. `RESEARCH_COMPASS.json`
12. `ENGINEERING_RULES.md`
13. `HISTORICAL_BOUNDARY.md`

Then query only `../databases/GAME_KNOWLEDGE_CATALOG_PASS131_0.sqlite` or routed/current evidence. Do not bulk-read historical narratives or recover cold SQLite catalogs during startup.

Pass131 implements the source-bounded Campaign MID117 Player EXP + Mana plane on existing canonical owners. Per-run `economys.exp` is raw `energy_cost`; per-run `economys.mana` is `mana_gain`; cumulative account EXP/Mana are settled atomically through existing progression/economy owners. The <=10 1x then >10 3x cumulative EXP rule is an IMPLEMENTATION_DECISION supported by client simulation, not recovered official-server internals. Mentor/Student remains deferred.

Backend **v0.15.8-pass131.0** is STATIC/REGRESSION ACCEPTED and awaits targeted real-client MID117 smoke. OTA remains **1.631.8**. No roadmap advancement to RNG until runtime reconciliation is accepted.
