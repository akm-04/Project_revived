# Pass113.0 Migration Handoff — MID117 Phase C1 Inert Foundation

Canonical backend: `gxb-backend-v0.14.2-pass113.0.zip` SHA-256 `b7bafc85d322e4d01ddcc955cb29abaebeb049110b58e287b397a8d675f9bd17`. Canonical source remains `all-assest-rechecked.zip` SHA-256 `89f0f830508b92e5fff6ad53c6a9dae961a14042dbfdf5649008efb8353f5608` with effective `app-assets/output/assets/src_64`.

Pass111 MID50 remains runtime accepted. Pass112 MID117 design remains authoritative. Pass113 implements only the inert Python foundation.

The executable repeat policy is now isolated in `data/campaign_repeat_rng_policy.json`; **do not** move it into the legacy Campaign policy path. `CampaignDropPlanner.plan(first_clear=False)` is used by MID113 battle staging and must remain disabled for repeat RNG. MID117 activation must call the new `plan_repeat_sweep()` entry point.

Policy mechanics: per source row q,r=divmod(increase_rate,10000); q guaranteed; nonzero r uses exactly one `campaign.repeat.residual` draw and adds one iff draw<r. This is private-server source-bounded compatibility policy, not recovered official code. Positive pool without rows hard-fails before entropy/mutation. Pool 0 is valid deterministic-only.

`mid117_operation_receipt.py` contains inert UUID/fingerprint/replay helpers but **WorldRepository does not use them yet**. Live `WorldRepository.sweep()` and legacy `campaign_drop_policy.json` are byte-identical to Pass111. Current OTA remains 1.631.5 and there is no SweepWindow override.

Next Pass114 activation order: src_64 re-check → cumulative OTA 1.631.6 ordinary MID117-only UUID injection → committed receipt lookup/replay before mutable gates → UoW recheck → validate source pool/costs → call plan_repeat_sweep once per constituent sweep → atomically stage costs + deterministic sweep_reward + repeat stack rewards + state + receipt → exact static replay/current projections → fresh extraction → client force-close/retry smoke.

Keep `economys` explicit zero and `additional=[]`; do not widen into Campaign EXP/Mana/awakening settlement.
