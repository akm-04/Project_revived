# Pass128.0 Technical Report — Super Campaign Progression Gates Implementation

## Result
Pass128 is implemented and statically/regression accepted. Backend is `gxb-backend-v0.15.5-pass128.0.zip` SHA-256 `58c4f8abe99d5a7c849a25a5f2deecb20db47348100b7f81ab0bf5cf73aa9ef2`. OTA remains 1.631.8 byte-identical to Pass123. Client smoke is intentionally deferred to Pass129.

## Source feedback loop
Fresh effective `src_64` checks were performed before behavioral changes. Function31 uses source condition `1|11`; `onNewFuncOpen(31)` invalidates/reloads world map; `CampaignTable.relateCampaign()` is direct `relate_campaign_id`; Super nodes require a server row before click behavior and separately call `checkNomalCampaignThrough()`; all 155 Super rows form one raw linear next/last chain ending at 2300024.

## Implemented modules
1. `SuperCampaignCatalog` — validates the 155 source Super rows, direct Normal anchors and raw chain.
2. `SuperCampaignAccessPolicy` — pure Function31/materialized-row/related-Normal-star bouncer.
3. `SuperCampaignProjectionService` — first/next row materialization and cursor derivation.
4. `EliteCampaignUnlockCoordinator` — Function31 eligibility/projection/announcement ordering and legacy maintenance repair.

## Level-11 bootstrap
The level-up UoW now makes Function31 eligible, projects Super100019 at star0 with source daily_limit3, derives the Super cursor, then announces Function31. Player progression rollback snapshots include `world_map` and `persistence_state`, so a failed durable commit restores the whole transition. Historical level>=11 unresolved accounts repair during player-load maintenance without a NEW_FUNC_OPEN callback.

## Server bouncer
MID113 preserves Pass123 same-stage STAGED replay first. New Super stages run the bouncer before attempts, Energy, RNG or session replacement. MID117 preserves committed UUID receipt replay first; fresh UUIDs run the bouncer before attempts/cost/RNG/receipt. A related Normal `star<=0` returns application `error_code=1` and performs zero operation mutation.

## Sequential frontier
A Super win exposes raw N+1 immediately at star0/source daily limit. Entry remains blocked until N+1's related Normal anchor has `star>0`. Terminal 2300024 remains terminal. Pass75 QA all-row seeding is retained and does not bypass authorization.

## Validation
Focused Pass128 suite passes 12/12. Neighbor Pass121, Pass122, Pass123, Pass94, Pass92, Pass81, Pass79 and Pass75 suites pass. `compileall` passes. `local_assets` is byte-identical to Pass123. Clean backend ZIP extraction passes.

## Next
Pass129 client smoke/debug/reconciliation. After runtime acceptance: Campaign Player EXP + Mana sweep economy, RNG closure, Generated/Unique, Girls/Equipment, deferred verticals.
