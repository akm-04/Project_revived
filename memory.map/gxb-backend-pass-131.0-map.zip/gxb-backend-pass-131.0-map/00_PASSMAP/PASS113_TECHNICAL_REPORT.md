# Pass113.0 Technical Report — Campaign MID117 RNG Phase C1 Inert Foundation

Canonical backend is now `gxb-backend-v0.14.2-pass113.0.zip` SHA-256 `b7bafc85d322e4d01ddcc955cb29abaebeb049110b58e287b397a8d675f9bd17`.

Pass113 implements the **inert** half of Campaign MID117 RNG. The effective `src_64` feedback loop was re-run against `SweepWindow.lua`, MapDetail/NewMapDetail request construction, `mid.lua`, `Backend.lua`, `campaign.lua`, and `campaign_dropbox.lua`. The Pass112 design remains valid: ordinary Campaign sweep is MID117, event sweep modes branch to distinct MIDs, returned `items` are per-sweep arrays, and the official server selection algorithm remains unrecovered.

## Implemented policy

The source-bounded private-server policy `campaign_repeat_rate_decomposition_v1` is executable behind a new dedicated MID117 policy registry. Per row: `guaranteed,residual = divmod(increase_rate,10000)`; guaranteed quantity is emitted directly; a nonzero residual consumes exactly one `campaign.repeat.residual` RandomOutcomeService draw and grants one extra unit iff `draw < residual`. Exact multiples and zero rates consume no entropy. Duplicate item IDs aggregate in first-source-occurrence order.

Positive repeat pool IDs with no recovered rows raise `campaign_repeat_pool_unavailable` class failure before entropy. Pool ID zero remains valid deterministic-only.

## Critical inertness correction

During implementation review, the existing `CampaignDropPlanner.plan(first_clear=False)` was confirmed to be used by **MID113 repeat battle staging**. Activating the new policy through the legacy registry would therefore have widened Pass113 beyond authorized MID117 infrastructure.

The final implementation avoids that: legacy `data/campaign_drop_policy.json` and `WorldRepository.sweep()` are byte-identical to Pass111. MID113 continues returning `disabled_unknown` for repeat planning. The new executable policy lives in `campaign_repeat_rng_policy.json` and is reachable only through `CampaignDropPlanner.plan_repeat_sweep()`, which has no live caller in Pass113.

## ROS adapter

`CampaignRandomOutcomeAdapter` maps Campaign's existing `draw_int(upper)` seam onto request-scoped `RandomOutcomeService.randbelow("campaign.repeat.residual", upper)`. RequestServices composes the adapter and dedicated MID117 policy registry, but no live route consumes them yet.

## MID117 helper contract

`mid117_operation_receipt.py` now implements the frozen helper layer: optional `mid117-<UUIDv4>` parsing, canonical fingerprint of MID117 + campaign_id + campaign_type + sweep_num + sweep_type + awake_mission-or-0, exact static replay serialization for `items/economys/additional/chapter_event`, current-projection descriptors, and audit metadata. It does **not** read or stage UoW receipts in Pass113.

## Validation

Strict deterministic tests cover 360000→36 with zero draws, 13332 guaranteed+residual boundary behavior, 4000 hit/miss boundary, duplicate aggregation, zero/exact-multiple no-draw behavior, negative-rate pre-entropy failure, the effective-source 24 positive missing-pool and 372 zero-pool invariants, request-scoped ROS composition, MID113 inertness, OTA 1.631.5 preservation, UUID/fingerprint behavior, and replay static/projection separation.

Current Pass111 MID50, Pass105 firewall, Pass99 Campaign cost, Pass98 consumables, Pass96 Economy/VIP, and Pass75 Campaign ownership regression spines pass. Fresh-extraction validation also passes.

## Next

Pass114 remains the separately bounded Phase C2 activation: re-check src_64, build cumulative OTA 1.631.6 only at ordinary MID117 SweepWindow routing, integrate permanent PlayerUnitOfWork receipt/replay in WorldRepository.sweep, call `plan_repeat_sweep()` independently per sweep inside the transaction, settle deterministic+repeat stack rewards with existing costs atomically, and hard-fail missing pools before mutation. Keep EXP/Mana `economys` and `additional` unchanged unless separately source-authorized.
