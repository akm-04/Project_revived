# Pass115.0 Index

- `PASS115_LIVE_CHECKPOINT.json` — current state.
- `PASS115_CAMPAIGN_INVESTIGATION_REPORT.md` — four-bug technical findings.
- `PASS115_CAMPAIGN_INVESTIGATION.json` — full derived audit dataset.
- `PASS115_RUNTIME_RECONCILIATION.json` — debug/runtime evidence.
- `PASS115_MODE_STATISTICS.json` — Normal/Super rate/catalog statistics.
- `PASS115_CHALLENGE_UNLOCK_FINDING.json` — exact Campaign 24111 client gate.
- `PASS115_SOURCE_EVIDENCE.json` — source hashes/roles.
- `CURRENT_NEGATIVE_MEMORY_PASS115.json` — do-not-infer guardrails.
- `PASS115_MIGRATION_HANDOFF.md` — continuation authority.
- `evidence/pass115/` — derived machine-readable audit artifacts.
- `databases/GAME_KNOWLEDGE_CATALOG_PASS115_0.sqlite` — promoted machine-memory database.
