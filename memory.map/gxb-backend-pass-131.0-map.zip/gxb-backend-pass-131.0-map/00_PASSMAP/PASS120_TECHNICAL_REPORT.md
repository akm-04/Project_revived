# Pass120.0 — Campaign Structural Architecture / Design Freeze

Pass120 is **design only**. Backend remains frozen at `gxb-backend-v0.15.1-pass117.0.zip` SHA-256 `b4d2790be9d34198bd2a62fcfa499060a0cb02c4acab6a24e4c7067a84ffce80`. No Python or OTA file changed.

## Design principle

The target is original-server-shaped behavior, not maximal client/server ceremony. Keep source-native exactly-once UUIDs where the operation is one immediate random transaction (MID50, MID117). Manual MID113→MID114 is a long-lived battle protocol with no recovered client correlation token, so it returns to one server-owned active Campaign battle session.

## 1. Super MID117 daily-limit atomicity

The existing MID117 UUID/UoW transaction is retained exactly. For Super (`campaign_type=2`) the request must strictly belong to the source Super membership and `sweep_num` must be <= the current mutable `daily_limit`. This preflight happens before entropy and before Energy/Ticket-or-Crystal cost mutation. A successful batch decrements `daily_limit` by **exactly `sweep_num`** inside the same UoW as costs, rewards and the permanent receipt. Receipt replay precedes the mutable gate, so a force-close retry never consumes attempts again. Normal Campaign has no attempt mutation. Daily Reset and MID116 remain the only reset owners.

Implementation should use a very small `CampaignAttemptService` (or equivalently bounded WorldRepository helper), not a new persistence subsystem. The canonical remaining count stays on the existing Super world-map Campaign row.

## 2. Dedicated Challenge graph/projector

A future `ChallengeCampaignCatalog` will be generated from effective `campaign.lua`, `chapter.lua` and `campaign_dropbox.lua`, retaining the raw parents/children arrays that generic `campaign_meta.json` loses. It must validate all 144 rows, 137 edges, seven roots and deterministic init reward invariants.

A `ChallengeProjectionService` will own the client `LOAD_WORLD_MAP.challenge` array. Once the Chapter16 global gate is satisfied, the frozen compatibility root policy seeds all seven raw source roots. On normalization/restart it performs a fixpoint repair: every persisted Challenge row with `star>0` materializes every raw source child at `star=0`; a `star=0` row does not unlock grandchildren. This both supports fan-out and guarantees the second/third variants exist before `MapWindow.getTrueCampaignInfo()` dereferences them.

Challenge first-clear init rewards use **no RNG**: `item_num = increase_rate // 10000`. When an uncleared Challenge battle is staged, MID113 returns these deterministic awards as battle-visible drops and the server freezes the same awards in the active battle session. MID114 victory commits those frozen awards canonically; loss commits none. MID114 returns `items=[]` for this init plane because `BattleWinWindow` already mirrors the MID113 drops after victory. A distinct MID114 result-only reward channel stays parked until separately source-proven.

Challenge also gets its source Energy result cost (24 win / 2 defeat through existing campaign cost data) in the same terminal UoW. Player/Hero EXP scalar reconciliation remains a later slice. Challenge has no sweep/repeat plane.

## 3. Manual Campaign battle simplification

`player.active_campaign_battle` becomes the sole canonical coordination object (schema v2). The client no longer needs to join MID113 and MID114 with `campaign_battle_op_id`, and new MID113/MID114 permanent receipts stop being written.

MID113 behavior: if a STAGED session already exists for the same campaign/type, replay its exact persisted stage response and DropPlan with zero RNG; formation is audit metadata, not identity, so changing formation cannot reroll the staged outcome. A valid different campaign/type may supersede the single active session. New Normal/Super first-clear stages call the existing RNG planner once; Challenge stages use deterministic catalog awards.

MID114 behavior: consume the matching STAGED server session. Victory commits its frozen awards/progression/cost once; loss commits no staged first-clear award. The terminal static response/projection is then retained in the session as `SETTLED_WIN` or `SETTLED_LOSS`. A duplicate matching MID114 performs zero mutation and returns the stored terminal response with source-compatible `error_code=30005`; missing/mismatched terminal results are family-bounded safe drains rather than opportunities to mint state.

There is one irreducible negative-memory boundary: because stock MID114 carries no token, a very late old result arriving after a new same-campaign battle cannot be perfectly correlated. Stock client sequencing does not allow the next battle to begin before the previous result callback completes, so the design deliberately relies on that recovered protocol property rather than hiding another UUID system under the server state.

## OTA rollback/migration

The future compatibility OTA is provisionally **1.631.8**. Backend compatibility ships first and accepts/ignores legacy `campaign_battle_op_id`. The OTA then explicitly overwrites the six Pass117 Campaign battle files (src_32/src_64 SelectTeamWindow, SelectTeamNewWindow, BattleCreate) with pre-Pass117/source-shaped content. They must be present in the new volume because clients that already installed 1.631.7 otherwise retain the patched files. The MID50 SelfPlayer and MID117 SweepWindow patches remain untouched. The Pass117 BattleCreate application-error guard is reverted with those files so stock family-bounded `30005` semantics work again.

Existing UoW receipt rows for Pass117 battle UUIDs remain inert historical data; no destructive database migration is needed. The helper module can remain for one compatibility pass and be deleted after runtime acceptance.

## Backend fit and implementation order

No full rewrite is indicated. Recommended bounded implementation sequence: Pass121 Super MID117 attempt fix; Pass122 Challenge catalog/projection/rewards; Pass123 manual battle session simplification + OTA 1.631.8 rollback; Pass124 client smoke/debug reconciliation. Generated/Unique Instances remains paused until Campaign runtime acceptance.

**Design status: CLOSED for the three requested structural points and ready for implementation.**
