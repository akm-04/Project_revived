# Pass128.1 Index — Emergency New-Account Campaign Hardlock Research

- `PASS128_1_TECHNICAL_REPORT.md` — root-cause report.
- `PASS128_1_RUNTIME_REVIEW.json` — debug.zip runtime facts.
- `PASS128_1_SRC64_WIRE_CONTRACT.json` — mandatory MID112 Lua wire contract.
- `PASS128_1_ROOT_CAUSE.json` — exact Pass128 regression mechanism and design verdict.
- `PASS128_1_TEST_GAP.json` — missing regression coverage.
- `PASS128_1_HOTFIX_PLAN.json` — bounded Pass128.2 implementation plan.
- `PASS128_1_ROADMAP_ABORT.json` — Pass129 and later roadmap halt.
- `CURRENT_NEGATIVE_MEMORY_PASS128_1.json` — emergency do-not-regress rules.
- `PASS128_1_LIVE_CHECKPOINT.json` — continuation authority.
- `evidence/pass128_1_new_account_hardlock/` — supplied debug and extracted MID112/client-error excerpts.
- `databases/GAME_KNOWLEDGE_CATALOG_PASS128_1.sqlite` — promoted knowledge catalog.
