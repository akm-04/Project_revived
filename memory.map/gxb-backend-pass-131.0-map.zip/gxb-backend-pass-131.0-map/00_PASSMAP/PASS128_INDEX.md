# Pass128.0 Index — Super Campaign Progression Gates Implementation

- `00_PASSMAP/PASS128_TECHNICAL_REPORT.md` — implementation report.
- `00_PASSMAP/PASS128_SRC64_FEEDBACK_LOOP.json` — effective-source recheck.
- `00_PASSMAP/PASS128_IMPLEMENTATION.json` — module/wiring/ordering summary.
- `00_PASSMAP/PASS128_FUNCTION31_BOOTSTRAP_IMPLEMENTATION.json` — level11 and legacy repair.
- `00_PASSMAP/PASS128_SUPER_ACCESS_POLICY_IMPLEMENTATION.json` — MID113/MID117 bouncer.
- `00_PASSMAP/PASS128_SUPER_PROJECTION_IMPLEMENTATION.json` — frontier/materialization semantics.
- `00_PASSMAP/PASS128_QA_DECOUPLING_VALIDATION.json` — sandbox authority separation.
- `00_PASSMAP/PASS128_VALIDATION.json` / `PASS128_REGRESSION_MATRIX.json` — tests.
- `00_PASSMAP/CURRENT_NEGATIVE_MEMORY_PASS128_0.json` — do-not-regress boundary.
- `00_PASSMAP/PASS128_LIVE_CHECKPOINT.json` — migration checkpoint.
- `00_PASSMAP/databases/GAME_KNOWLEDGE_CATALOG_PASS128_0.sqlite` — promoted machine authority.
