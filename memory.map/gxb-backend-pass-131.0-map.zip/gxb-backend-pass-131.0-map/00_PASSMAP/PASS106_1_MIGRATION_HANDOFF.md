# PASS106.1 MIGRATION HANDOFF — CANONICAL CONTINUATION BANK

## Purpose
This file exists to migrate the GXB private-server restoration project into a fresh ChatGPT thread without reconstructing state from conversational memory. The passmap is canonical machine-memory. Historical pass files are cold provenance; current truth is the HOT kernel + PASS106.1 SQLite + this handoff.

## Mandatory working rules
1. Treat uploaded ZIP artifacts as canonical. Verify hashes before use.
2. Effective `src_64` Architectural Feedback Loop is mandatory before every backend behavioral modification. Never implement from remembered assumptions when source evidence is available.
3. Act as version control: every state-changing pass must synchronize backend/passmap, update machine-memory, record a concise commit message, validate archives, and return ZIPs.
4. Workflow is `source/research -> decide -> bounded implementation -> static/self-test -> client smoke -> reconciliation -> next subsystem`.
5. Do not broad-implement multiple unrelated domains. Prefer narrow vertical slices with explicit ownership and rollback boundaries.
6. Do not fabricate source behavior when recovered source is incomplete. Fail closed or preserve negative memory.
7. For fresh-chat migration: first turn is reorientation/verification only. Do not implement. The user will authorize the next pass on the second turn.

## Canonical artifacts expected in the next chat
- Backend: `gxb-backend-v0.13.1-pass105.0.zip`
  SHA-256: `b89c76c4c8345e216f1233f27939915a51388997091d454dfe04ac60ebf13d06`
- Passmap: `gxb-backend-pass-106.1-map.zip`
  SHA-256: read from the final chat response / archive verification; do not assume before verifying uploaded bytes.
- Source/assets: `all-assest-rechecked.zip`
  SHA-256: `89f0f830508b92e5fff6ad53c6a9dae961a14042dbfdf5649008efb8353f5608`
- Effective source root inside assets: `app-assets/output/assets/src_64`
- Effective `src_64` known file count: 4,370.

## Startup authority order
Read only this small hot set first:
1. `00_PASSMAP/READ_FIRST.md`
2. `00_PASSMAP/HOT/BOOT.json`
3. `00_PASSMAP/HOT/STATE.json`
4. `00_PASSMAP/HOT/RISKS.json`
5. `00_PASSMAP/HOT/ROADMAP.json`
6. `00_PASSMAP/HOT/RNG_REALITY.json`
7. `00_PASSMAP/HOT/MUTATION_SAFETY.json`
8. `00_PASSMAP/HOT/QUERY.json`
9. `00_PASSMAP/PASS106_1_LIVE_CHECKPOINT.json`
10. `00_PASSMAP/PASS106_1_MIGRATION_HANDOFF.md`
11. `00_PASSMAP/databases/GAME_KNOWLEDGE_CATALOG_PASS106_1.sqlite`
Do not bulk-read Pass62-Pass106 files unless a precise historical question requires them. Query SQLite first.

## Current backend authority
Backend stays frozen at `v0.13.1-pass105.0`; Pass106 and Pass106.1 are map/research/migration passes only.
No backend code was changed in Pass106.1.

## Runtime-accepted / accepted-for-continuation foundations
- Pass83: `ServerDayClock`, 05:00 GMT+8 source-day boundary, `DailyResetCoordinator`, MID1 cold-start ordering, high-water rollback protection, temporal future-anchor hygiene.
- Pass89: source-native OTA foundation, preservation Recharge bridge, authenticated PurchaseIntent, exactly-once direct-Crystal Commerce settlement, native VIP progression. Organic VIP0 -> VIP15 was runtime-proven.
- Pass91: MID657 VIP rewards, duplicate protection, restart persistence.
- Pass92: MID116 Super Campaign paid reset, nth source Crystal cost, VIP + active Monthly Privilege allowance, state-based lost-response reconciliation, daily reset of `reset_count`.
- Pass94: first-class `PlayerProgressionService`; cumulative EXP/Academy level and source level-up Energy behavior.
- Pass96: Academy max 100, source-derived Backpack stack ceilings, UID 13371337 normalization, Campaign multi-sweep VIP/Privilege gating, Hero preset-count VIP gating.
- Pass98: deterministic consumables: MID27 Energy consumables, MID87 Magic consumables, complete MID1404 Inscription mapping; MID134 and random MID241 remain fail-closed.
- Pass99: Campaign MID117 deterministic input costs: Energy + Raid Ticket or Crystal, atomic with existing deterministic rewards; QA consumable seed. Runtime accepted.
- Pass100: OTA 1.631.4 + MID97 exactly-once stamina purchase. Source-native `xyd.generateUUID()` operation identity, `expected_buy_energy_times`, `energy_day_id`; Crystal debit +120 Energy + counter + durable receipt in one UoW. Runtime accepted.
- Pass104: Mutation Safety Firewall Phase1. 79 source-audited non-session unowned mutations blocked with transport-level HTTP409; startup contract validation. Runtime/no-regression accepted; Store/SkyTower UI/read-model gaps intentionally parked.
- Pass105: Firewall Phase2. Eight unsupported session preflight/start MIDs moved to HTTP409 quarantine. Smoke showed no regression and healthy HTTP409 behavior; the exact eight Phase2 MIDs were not organically emitted, so direct per-MID runtime coverage is not claimed. Accepted for roadmap continuation.

## Mutation Safety Firewall current state
- Total audited contracts: 95.
- Phase1 non-session blocked: 79.
- Phase2 preflight/start blocked: 8.
- Terminal battle settlements deferred: 8.
- Canonical generic block is HTTP 409, not HTTP200 with `error_code=1`.
- Do not populate `error_msg` on generic firewall blocks; recovered `Backend.lua` can route nonempty `error_msg` to restart/exit alert behavior.
- `30005` terminal drain is NOT universal. Arena/Treasure/March/World Boss have source evidence; Region Arena does not. Reopen terminal semantics only when enabling that battle domain.
- Parked read-model/UI glitches in unimplemented Store/Sky Tower/Arena/March/Pet/etc. are not current blockers for RNG work.

## Global Economy / ownership backbone
The project intentionally uses a strangler architecture; do not centralize all domain currencies prematurely.
- `PlayerUnitOfWork`: atomic durable multi-owner commit/rollback boundary.
- `MutationSettlementService`: typed mutation orchestration.
- `EconomyLedger`: scalar economy resources it owns.
- `StackInventory`: Backpack stack quantities, with source `item.lua.stack` ceilings and legacy-overflow downward-consumption behavior.
- `TemporalPolicyService`: Energy/Skill Point temporal resources and cap/regeneration rules.
- `PlayerProgressionService`: cumulative player EXP/Academy level.
- `VipPrivilegeResolver`: source-native VIP privileges.
- `DailyResetCoordinator`: source-day resets at 05:00 GMT+8.
- `FunctionStateRepository`: progression eligibility/announcements.
- Existing `PlayerUnitOfWork` receipts already provide `get_receipt`, `stage_receipt`, durable `replay_payload`, and same-UoW persistence. Do NOT create a parallel generic outcome-receipt database for RNG.

## QA/dev account facts
Legacy developer UID: `13371337`.
Pass96/99 migration state targets:
- Academy level 100.
- EXP 579615 (safe Level-100 cumulative value; do not set to level-100 threshold 613615 because source loop can transiently step to 101).
- max_lev 100.
- max_energy 160.
- source-aware item stack caps; dev headroom normally 900 for cap>=999, 90 for cap99.
- QA seed includes Raid Ticket 50001013=900, Fries 50001014=90, Kanto Food 50001015=90, Tonkatsu 50001016=90, and Magic consumables 50001120-50001131=900 each.
One-shot migration markers must remain non-replenishing after consumption.

## Consumable / campaign facts
- MID27 Energy consumables are source-table driven; Kanto Food 50001015 grants +18 Energy, Tonkatsu 50001016 +30, Fries 50001014 +6.
- MID87 handles 12 deterministic Magic consumables through EconomyLedger.
- MID1404 Inscription dissolve awards certificate currencies (`degree_cer`, `graduate_cer`, `patent_cer`), not invented generic Emblem EXP; 254 source-valid item->inscription mappings are supported.
- MID134 Pet EXP intentionally fails closed until true Pet EXP settlement exists.
- MID241 random gift/chest use remains fail closed pending RNG because recovered gift definitions include random drops and some referenced gift IDs are missing from source.
- MID114 normal Campaign already debits source Energy correctly.
- MID117 deterministic input side is closed: `campaign.energy_cost * sweep_num`, plus Raid Ticket 50001013 per ITEM sweep or 1 Crystal per CRYSTAL sweep.
- Repeat Campaign random reward selection is still incomplete by design.

## Source-correct Summon facts and negative memory
- Effective `src_64/app/common/network/mid.lua`: `SUMMON_HERO = MID50`.
- `SUMMON_SUPER_HERO = MID305`.
- Prior machine wording that referred to repeatable Summon MID70 is stale/incorrect; do not resurrect it.
- Stock MID50 request identity is effectively `summon_type + summon_index`, with no per-click operation token.
- Current backend repeatable paid Summon idempotency still uses a short replay-window heuristic (`PaidSummonOperationReceiptStore`), which is ambiguous between lost-response retry and a legitimate identical second click.
- Summon success callbacks add returned heroes/items on transport success; operation identity must be fixed before RNG migration.

## RNG backbone — USER ACCEPTED ROADMAP
The user explicitly accepted the Pass106 recommended roadmap and intends to follow it.

### Phase 1 — `RandomOutcomeService` foundation (NEXT)
Architectural requirements:
- Own entropy mechanics, domain namespaces, and deterministic test injection only.
- Probability tables, pity rules, pools, rate-up logic, and game policy remain domain-owned.
- Production gameplay entropy may use cryptographically strong/system entropy, but auth/password/session/token/OTA UUID randomness is OUTSIDE this service.
- Persist the final committed outcome/replay payload, not raw RNG state/seed as authority.
- Reuse existing `PlayerUnitOfWork` receipts. A thin `OutcomeReceiptCoordinator` is allowed only as orchestration over existing receipts; it must not create parallel persistence.
- Cost mutations, generated outcome, rewards/entities, and outcome receipt must commit atomically in one UoW.
- Same operation identity retry must replay the committed outcome and never reroll.
- First pass may be architecture/research-only if needed; no rush.

Known current gameplay RNG candidates:
- `gxb_backend/state/summon_private_policy.py`
- `gxb_backend/state/classic_vending_balance_policy.py`
- `gxb_backend/state/magic_summon_private_policy.py`
- `gxb_backend/state/sx_soul_box_private_policy.py`
- `gxb_backend/state/medium_legacy_private_policy.py`
- `gxb_backend/state/campaign_drop_planner.py`
Explicitly exclude auth/session/token entropy and OTA operation UUID generation.

### Phase 2 — MID50 UUID bridge + unchanged-policy Summon migration
- Audit exact MID50 constructor/retry path in `src_64`.
- Use the source-native per-click UUID pattern proven by MID97.
- Automatic retry must reuse the original params/UUID; legitimate new click receives a new UUID.
- Replace the short replay-window heuristic only after this identity exists.
- Migrate existing Summon policy through `RandomOutcomeService` WITHOUT changing probabilities/pools/pity/rate-up behavior.
- Audit MID305 independently; do not silently fold it into MID50.

### Phase 3 — Campaign repeat reward completion / MID117
This was moved ahead of unique-instance/Girls work in Pass106.
Why: `SweepWindow.lua` handles returned MID117 `items` as ordinary Backpack stack additions, and `campaign_dropbox.lua` resolves to normal item IDs. Campaign repeat does not require generated unique-instance settlement.
Before implementation, perform a narrow source/policy audit of repeat dropbox selection, deterministic economy/partner-EXP response semantics, and unresolved probability meaning. `campaign_dropbox.increase_rate` is a recovered source fact but is not alone proof of the original server-side probability algorithm. Twenty-four referenced repeat pools were already proven absent from recovered source; do not invent them.

### Phase 4 — Generated/Unique Instance settlement
Add a narrow UoW-compatible primitive for rolled/generated unique objects (not generic Backpack stacks), needed particularly for Horcrux/generated gear.

### Phase 5 — Girls/Equipment economy closure
Finish deterministic Normal gear/Fumo, Super enhancement, Element Equipment, Inscription/Stone Evolution, then route random/generated Practice/Horcrux/etc. through RNG + unique-instance architecture.

### Parked domains
Store, Battle Pass, Arena, Pet, Guild, March, World Boss, Task/Sign, Monthly Privilege lifecycle and other unrelated systems remain separate source-driven vertical slices. Firewall/fail-close them until explicitly reconstructed. Do not fold them into RNG merely because they may use randomness.

## Current risks / things NOT to claim
- Direct runtime hit of each of the eight Pass105 Phase2 MIDs is not proven.
- Eight terminal battle settlement/drain contracts remain deferred.
- `RandomOutcomeService` does not exist yet.
- MID50 UUID operation identity has not been implemented yet.
- Campaign repeat random reward selection is not implemented yet.
- Generated unique-instance settlement is not implemented yet.
- Girls/Equipment random/generated-instance closure is incomplete.
- Store/SkyTower/Arena/March read-model/UI glitches are parked, not solved.
- Do not interpret the 1,061 source-requested MIDs vs routed subset as a percentage-complete score; the client includes years of events/modes and restoration is intentionally vertical-slice driven.

## Fresh-chat first-turn protocol
On the FIRST user message in the new thread, the user will attach backend + passmap + assets and ask only for reorientation. Do all of the following and nothing more:
1. Verify all three archives and their SHA-256 hashes.
2. Unpack/read the startup authority list above.
3. Confirm effective `src_64` is present/readable and count/spot-check source files.
4. Confirm SQLite `PRAGMA integrity_check = ok` and table count from current bootstrap.
5. Summarize current backend/runtime state and accepted roadmap.
6. Explicitly state that the immediate next architectural stage is `RandomOutcomeService` foundation, but do NOT implement it yet.
7. Confirm readiness for the user's SECOND prompt/authorization.
Do not modify or regenerate artifacts on the first turn.

## Second-turn behavior
The user has already accepted the roadmap in principle. On the second prompt, follow whatever scope they authorize. If they simply authorize continuation, begin the RNG backbone using the mandatory `src_64` feedback loop. You retain flexibility to make the first RNG pass design/research-only if that is architecturally safer.
