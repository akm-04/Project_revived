# Pass109.0 — RNG Backbone Stage 2 Final Design Freeze

Pass109 is **architecture/design only**. Backend remains `gxb-backend-v0.13.1-pass105.0.zip` SHA-256 `b89c76c4c8345e216f1233f27939915a51388997091d454dfe04ac60ebf13d06`; no Python backend file was modified. Effective source is `all-assest-rechecked.zip` SHA-256 `89f0f830508b92e5fff6ad53c6a9dae961a14042dbfdf5649008efb8353f5608`, `app-assets/output/assets/src_64` (4,370 files).

## Stage status

- RNG Stage1 Extrapolation: **CLOSED in Pass108**.
- RNG Stage2 Architecture & Design: **CLOSED / FROZEN in Pass109**.
- RNG Stage3 Implementation: **NOT STARTED**.

## 1. Locked RandomOutcomeService interface

The shared service owns **mechanical entropy only**. It must not know Summon rates, pity, pools, guarantees, eligibility, costs, Hero creation, Backpack settlement, shop/event semantics, or authentication/identity entropy.

Target module: `gxb_backend/state/random_outcome_service.py`. `RequestServices` is request-scoped, so one ROS instance is composed per request. Namespace ordinals are ephemeral and never persisted.

```python
@dataclass(frozen=True)
class EntropyDrawRequest:
    namespace: str
    ordinal: int          # 0-based within namespace for this request
    upper_exclusive: int

class EntropyProvider(Protocol):
    def draw(self, request: EntropyDrawRequest) -> int: ...

class RandomOutcomeService:
    def __init__(self, entropy: EntropyProvider | None = None): ...
    def randbelow(self, namespace: str, upper_exclusive: int) -> int: ...
    def choose_index(self, namespace: str, size: int) -> int: ...
    def weighted_index(self, namespace: str, weights: Sequence[int]) -> int: ...

class NamespacedRandbelowAdapter:
    def __init__(self, service: RandomOutcomeService, namespace: str): ...
    def randbelow(self, upper: int) -> int: ...
```

`SystemEntropyProvider.draw()` uses `secrets.randbelow()`. `weighted_index()` accepts only nonnegative integer weights, requires at least one positive weight, consumes exactly one bounded draw, walks the caller-supplied weights in original order, and returns the selected index. No floating probability API, shuffle helper, sample helper, seed API, or policy registry belongs in the foundation.

The adapter is intentional: the frozen backend's classic, balance, Medium-legacy and SX planners already depend on the tiny `SummonRandomSource.randbelow(upper)` seam. Stage3 can replace the entropy provider without rewriting their policy logic.

## 2. Namespace contract

Namespaces are lowercase dot-separated mechanical streams. They do not contain player IDs or probability versions. Initial frozen MID50 streams are `summon.classic.pool`, `summon.classic.balance`, `summon.medium_legacy`, and `summon.sx`. Reserved later roots include `summon.super`, `summon.magic`, `campaign.repeat`, `gift.open`, `practice.hero`, `practice.pet`, `inscription.rebuild`, `rune.generate`, `spirit.generate`, `shop.refresh`, `event.<family>`, and `world.<mode>`.

Client battle/minigame/presentation RNG, `xyd.generateUUID()`, authentication/session entropy, DreamWorld deterministic seeded selection, and client-originated random request choices remain outside gameplay ROS.

## 3. Deterministic test entropy

Tests inject a strict `ScriptedEntropyProvider`. Each expected draw is keyed by `(namespace, ordinal)` and also declares its expected `upper_exclusive` and returned value. Missing draws, unexpected draws, bound mismatches and out-of-range scripted values are hard failures; tests must assert the script is exhausted.

This deliberately makes draw-topology drift visible. A policy edit that adds a hidden random call cannot silently change deterministic test outcomes. Production ignores namespace/ordinal when sourcing entropy; they are mechanical test/observability coordinates, not a deterministic production seed.

## 4. Source-native MID50 operation identity

Pass109 freezes the client field as **`summon_op_id`** with value **`mid50-<xyd.generateUUID()>`**. The injection point is the single effective MID50 network choke point: `SelfPlayer:summonHero()` immediately before `Backend.request(SUMMON_HERO, params, ...)`. It sets the field only when absent, never overwriting an existing identity.

Effective `src_64` proves that all recovered MID50 UI paths (SummonWindow, SummonResultWindow, BackpackWindow) route through this method, while `Backend.lua` queues/retries the same `params` table after request failure. Therefore one legitimate click gets one UUID, a transport retry keeps that UUID, and a later click creates a fresh request table and UUID. `xyd.generateUUID()` stays outside ROS because it is identity entropy, not gameplay outcome entropy.

The server accepts only lowercase `mid50-` plus an RFC4122-v4-shaped UUID. Once the dedicated MID50 migration activates, missing/invalid identity fails closed. Foundation-only Pass110 does not require this bridge yet.

## 5. MID50 request fingerprint

Fingerprint preimage is exactly:

```json
{"schema_version":1,"protocol_mid":50,"summon_type":<int>,"summon_index":<int>}
```

Serialize canonical JSON with sorted keys and compact separators, SHA-256 it, and store `sha256:<hex>`. The UUID itself, current server counters, clock/day, pool data and policy version are excluded. This binds an operation UUID to the source request tuple without making replay depend on mutable server state.

## 6. Durable UoW receipt schema

Receipt domain is **`mid50_summon`**; key is the normalized `summon_op_id`; mode is `CLIENT_UUID_V4`; retention is `CLIENT_UUID_PERMANENT`. The resolved descriptor semantic is stored as the receipt operation. The existing `PlayerUnitOfWork` remains the only generic receipt authority.

The replay payload is split deliberately:

```json
{
  "schema_version": 1,
  "protocol_mid": 50,
  "semantic": "<descriptor semantic>",
  "request": {"summon_type": 1, "summon_index": 2},
  "static_response": {"result": ["<exact committed rows>"], "...": "other immutable reward fields"},
  "projection": {
    "economy_keys": ["mana"],
    "summon_info": true
  }
}
```

`static_response` is the committed success response with cumulative `economy_` and `summon_info` removed. It retains the exact committed `result` rows and any `reward`, `extra_reward`, `items`, `sakura_items`, or `stick_items` returned by that operation.

On replay, **ROS and domain policy are never called**. The exact immutable result/reward fields are replayed, but cumulative projections are rendered from current canonical state: current balances for exactly the originally returned economy keys, and current `SummonStateContract` when `summon_info` originally existed. This is necessary because effective `Backend.lua` treats `economy_` as absolute synchronization state; replaying an old balance after later legitimate pulls could rewind the client's projection.

## 7. Atomic ordering

The locked order is: normalize identity/tuple → fingerprint → committed receipt lookup **before mutable gates or entropy** → compatible replay or fingerprint conflict → descriptor/domain validation → UoW + receipt recheck → cost debit → domain policy computes pool/weights → ROS mechanical draw → materialize outcome/update counters/pity/state → build replay payload → stage UoW receipt → atomic commit.

Costs, outcomes, Hero/item mutation, counters and receipt therefore share one UoW commit. A committed retry cannot reroll or charge again. A transaction that truly rolls back has no committed receipt and may draw again on a later request.

## 8. Compatibility boundary

The old `SummonOperationReceiptStore` remains compatibility authority for existing deterministic tutorial one-shot migration semantics; Pass109 does not authorize deleting it. `PaidSummonOperationReceiptStore` is the short-window heuristic created because stock MID50 lacked an operation token. It is superseded **only for repeatable MID50 semantics when those semantics are migrated to the UUID/UoW path**. No broad receipt cleanup belongs in the same migration pass.

## 9. Design conclusion / next pass

Stage2 is now **done and frozen**. No additional architecture pass is required before implementation. The recommended next pass is **Pass110 Stage3 Phase A — RandomOutcomeService foundation only**: add the service/provider/adapter plus strict deterministic tests and composition wiring, but do not migrate a gameplay domain yet. After that, a bounded MID50 pass can add the OTA UUID bridge, durable UoW receipt/replay path and adapter injection while preserving the current Summon probability/pool policy unchanged.
