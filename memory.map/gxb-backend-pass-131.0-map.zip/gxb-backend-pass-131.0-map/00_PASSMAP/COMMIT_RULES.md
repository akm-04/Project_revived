# Historical routing stub

This unversioned file previously contained a **Pass32.5 historical VCS rules** and could be mistaken for current authority. The original is preserved verbatim at `99_ARCHIVE/pass128_3_stale_canonical_like/00_PASSMAP/COMMIT_RULES.md`.

Current replacement: `00_PASSMAP/CURRENT/ENGINEERING_RULES.md`.
