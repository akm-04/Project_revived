# READ FIRST — Pass130.0 Campaign EXP/Mana research + implementation plan

Backend: `gxb-backend-v0.15.7-pass129.0.zip` SHA256 `57854049e4f9319026d5703d81a0a0dc922690b29d78fb9e6110132eb1818d41`; OTA 1.631.8 unchanged; effective source `app-assets/output/assets/src_64`.

Pass129.0 behavior-neutral architecture hygiene is **runtime accepted** from the supplied debug smoke. Pass130.0 is a **passmap-only research and design pass**: no backend or OTA code was changed.

Core Campaign sweep economy mapping is complete enough for implementation. Canonical Normal/Super stages carry `energy_cost` and `mana_gain` from Chapter 1; player/account EXP base is `energy_cost`, not `partner_exp`; MID117 per-run `economys` is the raw EXP/Mana display plane while top-level `economy_` is cumulative authority; `additional` remains separate. The selected private-server compatibility rule mirrors the client sweep curve: 1x account EXP while simulated pre-run level is <=10, then 3x after crossing. Mentor/Student EXP is explicitly deferred with the Social/teacher vertical.

The bounded next implementation must reuse `RewardTransactionService`, `PlayerProgressionService`, `EconomyLedger`, `MutationSettlementService`, `PlayerUnitOfWork`, and the existing MID117 receipt. Add only a pure `CampaignSweepEconomyPolicy`; do not create a new Campaign ledger/progression owner or perform a broad MID117 rewrite. Recheck effective `src_64` before any code edit.

Start at `CURRENT/README.md`, then route Campaign economy work to `PASS130_CAMPAIGN_EXP_MANA_IMPLEMENTATION_BLUEPRINT.md`, `PASS130_COMPATIBILITY_DECISIONS.json`, `PASS130_BACKEND_REUSE_DESIGN.json`, and `PASS130_IMPLEMENTATION_TEST_PLAN.json`.
