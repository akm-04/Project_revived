# Pass128.4 — Backend Structure Reality Check / Self-Heal (Research Only)

## Scope
No Python backend or OTA bytes were modified. Frozen backend: `gxb-backend-v0.15.6-pass128.2.zip` SHA256 `e7f6b8cfdb29e95eef2f764bd2e8f0968d5cf397d483aeff7d340092295fc743`. This pass audits structure, ownership, composition, persistence boundaries and source compatibility only.

## Verdict
**Architecture is fundamentally sound. Full rewrite is not mandatory and is not recommended.** The backend is an evolved strangler architecture: old compatibility facades coexist with newer typed owners, but live request composition generally routes mutation to one canonical owner and one `PlayerUnitOfWork`. Static import graph is acyclic.

The backend is **not too modular** in the sense that matters. The four Super components are appropriately split: source catalog, read-only access policy, projection mutation owner, and Function31 coordination. Merging them would recreate the exact authority confusion Pass127/128 were designed to remove.

The real debt is **orchestration density** and **composition duplication**, especially `WorldRepository`, not excessive domain separation.

## Measured structure
- 147 Python modules / ~29,195 LOC.
- 71 `state` modules / ~19,890 LOC.
- 460 internal import edges; **0 import cycles**.
- `RequestServices`: 441 LOC, request composition root, 62 internal outbound imports, 72 constructed attributes. Large fan-out is expected for a composition root.
- `PlayerMaintenanceServices`: 111 LOC; duplicates 14 constructed attributes from request composition. This is the clearest drift seam.
- `WorldRepository`: ~1,920 LOC / 71 functions / 22 state-module imports. It coordinates Normal/Challenge/Super map normalization, story drop, manual battle session, MID116 reset, MID117 sweep and reward/progression settlement. This is the main structural hotspot.
- `SummonRepository`: ~1,988 LOC / 61 functions; also large, but policy/planner ownership is already split and no current runtime evidence requires immediate refactor.

## Source architecture recheck
Fresh effective `src_64` confirms the observable boundaries used by the current design: world-map cursors are server-issued client-visible state; Function31 announcement forces a world-map refresh; `relate_campaign_id` is the Normal/Super source link; Super row visibility and Normal entry gating are distinct; stock MID113/MID114 still have no cross-request operation token; and 30005 remains a battle-result-family semantic.

These source facts constrain backend behavior, **not Python module layout**. We should preserve ownership seams that make those contracts explicit rather than mimic Lua file organization.

## Are systems fighting each other?
No active canonical double-authority was found in live composition. `SuperCampaignAccessPolicy` is mutation-free. `SuperCampaignProjectionService` owns Super rows/cursors. `EliteCampaignUnlockCoordinator` sequences Function31 with projection and owns only its migration marker. `WorldRepository` calls those owners rather than implementing a second Super cursor algorithm.

There are latent drift risks:
1. `RequestServices` and `PlayerMaintenanceServices` construct overlapping graphs independently.
2. `WorldRepository` has permissive fallback constructors that can silently create collaborator instances when direct callers omit canonical dependencies. Live roots inject the correct shared instances, but the fallback is a future parallel-owner hazard.
3. `WorldRepository.payload()` performs normalization/self-heal and can persist on a read path. Pass128.2 proves some self-heal is required, but the mutation should eventually be an explicit reconcile boundary rather than hidden serialization behavior.
4. The UoW still has explicit legacy compatibility persistence outside transactions for older/simple handlers. Core typed mutation paths are on UoW, but the strangler migration is not literally 100% complete.

## Compatibility layers that look duplicate but are not fights
- `EconomyRepository` is a legacy facade; Mana/Crystal are owned by `EconomyLedger`, Energy by `TemporalPolicyService`, EXP/level by `PlayerProgressionService`. Live composition disables direct legacy fallbacks.
- `InventoryRepository` is a compatibility facade over `StackInventory`.
- `RewardTransactionService` translates domain reward plans; `MutationSettlementService` owns typed leaf settlement.
These should not be merged merely to reduce class count.

## Orphan historical runtime modules
Two production-orphaned modules remain packaged: `function_unlock_repository.py` and `campaign_battle_operation_receipt.py`. Current production imports neither; the StateRepository compatibility getter already returns `FunctionStateRepository`, and Pass123 retired Campaign battle UUID authority. They are cognitive/package debt, not active runtime conflicts.

## Recommended no-rewrite self-heal
Do **not** refactor before the mandatory client smoke. Pass128.2 needs an uncontaminated runtime test.

After runtime acceptance, use a strangler sequence:
1. Add architecture-invariant tests that assert canonical object identity and zero import cycles.
2. Centralize Campaign progression construction shared by request and maintenance roots.
3. Keep `WorldRepository` as the public facade but extract coherent use cases: MID113+MID114 together into a `CampaignBattleService`; MID117 into a `CampaignSweepService` when Campaign EXP/Mana work resumes.
4. Make MID112 reconciliation explicit/transactional and serialization pure, preserving mandatory numeric-zero fields.
5. Remove/deprecate truly orphaned historical runtime modules after test/tool dependency confirmation.

## Why no full rewrite
A rewrite would throw away a large set of already tested invariants: UoW receipt ordering, source-shaped Campaign sessions, Challenge raw topology, Function31/Super gates, daily reset semantics, typed economy/temporal ownership, RNG policy separation and mutation firewall behavior. None of the usual rewrite triggers are present: no dependency cycles, no irreconcilable live double ownership, no persistence model incapable of expressing source state, and no systemic UoW failure.

## Validation
- Python compileall: PASS.
- Pass128 Super progression gates: 12/12 PASS.
- Pass128.2 MID112 wire contract: 4/4 PASS.
- Static dependency graph: 0 cycles.
- Backend and OTA unchanged.

## Roadmap
1. Pass128.5 — mandatory fresh/new-account runtime smoke/reconciliation on unchanged Pass128.2 backend.
2. If failure: remain in Pass128.x with bounded source-backed fix.
3. If accepted: current accepted roadmap resumes with Campaign Player EXP + Mana, then RNG closure, Generated/Unique, Girls/Equipment, deferred verticals.
4. **Proposal pending user acceptance:** insert one behavior-neutral architecture-hygiene/strangler-preparation pass after smoke and before Campaign EXP/Mana to centralize Campaign construction and establish WorldRepository extraction seams.
