# Pass128.2 Technical Report — New-Account MID112 Wire Hotfix

## Status
Pass128.2 is implemented and static/regression accepted. The backend is `gxb-backend-v0.15.6-pass128.2.zip` SHA-256 `e7f6b8cfdb29e95eef2f764bd2e8f0968d5cf397d483aeff7d340092295fc743`. **Pass128 is not runtime-accepted yet**: a real fresh-account client smoke is mandatory next.

## `src_64` feedback loop
Effective source remains `app-assets/output/assets/src_64` (4370 files). Before modification, `SelfPlayer.worldMapEvent_()` was rechecked and confirmed to assign `super_chapter_id`, `super_campaign_id`, `super_stars`, and `super_bonus_id` directly from MID112 `chapter_info` with no fallback. `MapWindow.updateChapterTypeBtnShowInfo()` evaluates `maxSuperChapter > 0` without a nil guard. Therefore a Function31-closed account requires explicit numeric zero keys; omission is a protocol-visible error.

## Root cause carried from Pass128.1
Pass128 moved Super cursor ownership into `SuperCampaignProjectionService`. Its numeric comparison normalized a missing key to 0, so missing+desired0 was incorrectly treated as canonical. Login bootstrap masked this through `PlayerState.world_map_payload()` defaults; explicit MID112 exposed the raw omission and hardlocked MapWindow.

## Bounded hotfix
`SuperCampaignProjectionService.recompute_cursors()` now writes each mandatory Super cursor field when the key is absent **or** when its normalized value differs from the desired value. No Super cursor ownership was moved back into `WorldRepository`; the four-module Pass127/128 architecture remains intact. Existing `WorldRepository.normalize()/payload()` persistence saves the repaired schema once and repeated canonical loads do not ghost-save.

Mandatory closed-mode wire values are:
- `super_chapter_id = 0`
- `super_campaign_id = 0`
- `super_stars = 0`
- `super_bonus_id = 0`

## Validation
Dedicated Pass128.2 wire-contract suite: **4/4 PASS**. It covers fresh level1, level10 Function31-closed, bootstrap-vs-explicit MID112 chapter schema parity, exact eight-key completeness, one-shot persistence, and canonical no-ghost-save.

Original Pass128 progression matrix remains **12/12 PASS**. Pass121 MID117, Pass122 Challenge, Pass123 manual battle/OTA, Pass94 progression, Pass92 MID116, Pass81 Campaign corrections, Pass79 Daily Reset, and Pass75 Campaign ownership all pass. Python compilation passes. Clean-extracted release re-ran the same hotfix/core and neighbor spine successfully.

OTA/local-assets has 142 files and is byte-identical to Pass128.0; OTA remains 1.631.8.

## Roadmap gate
NEXT = **Pass128.3 mandatory fresh/new-account client smoke and reconciliation**. Pass129, Campaign EXP/Mana, RNG closure, and later work remain halted until the Campaign window opens cleanly and the Function31/Super progression gates are runtime accepted.
