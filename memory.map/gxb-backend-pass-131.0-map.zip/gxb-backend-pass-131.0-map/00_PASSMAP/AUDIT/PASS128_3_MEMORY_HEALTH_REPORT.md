# Pass128.3 Memory Health Report — Knowledge-System Self-Heal

## Scope
Research/passmap-only. Backend remains `gxb-backend-v0.15.6-pass128.2.zip` `e7f6b8cfdb29e95eef2f764bd2e8f0968d5cf397d483aeff7d340092295fc743`; OTA 1.631.8 unchanged. This pass did not make uncertain game behavior more certain by documentation.

## 1. What was reorganized
A new `00_PASSMAP/CURRENT/` kernel is now the only unversioned conceptual authority. Startup is reduced to current state, blockers, claims, unknowns, invariants, architecture, routing, negative memory and evidence rules. `HOT/` remains only a compatibility mirror/redirect layer.

The live SQLite path now contains one current catalog. 16 predecessor catalogs (Pass116 through Pass128.2) are preserved byte-for-byte in `99_ARCHIVE/HISTORICAL_KNOWLEDGE_CATALOGS_PASS116_TO_128_2.tar.zst` with individual SHA-256 manifest entries.

## 2. What was consolidated
Canonical claims now use claim IDs with layer + epistemic class + provenance. Repeated narratives are routed to one canonical claim instead of being re-explained at startup. Exact duplicate root Pass index copies were removed where an identical `00_PASSMAP/` copy exists (29 removed); provenance itself was not deleted.

## 3. Stale material quarantined
28 unversioned/HOT files that looked current but carried Pass32–126 state were copied verbatim into `99_ARCHIVE/pass128_3_stale_canonical_like/`. Their live paths now contain current state or explicit routing stubs. High-risk examples were `CURRENT_AUTHORITY_MAP`, `CURRENT_STATUS`, both `AGENT_HANDOFF`/`memory` files, database guides/status, navigation/router, and old HOT architecture/source/firewall snapshots.

## 4. Contradictions found
The contradiction scan records 12 high-impact cases. Most were stale-authority conflicts, not disagreements in raw evidence. Pass128.0's static completion vs Pass128.1 runtime rejection is preserved as historical supersession rather than rewritten. 30005 source-family breadth vs our narrower implemented scope is now explicitly layered instead of conflated.

## 5. Claims downgraded fact → inference/decision
- Challenge `quantity=increase_rate//10000`: source proves rate pattern, not original server division code; current formula remains a compatibility decision/strong inference.
- Sequential visible Super frontier: strong source-consistent inference, not captured official-server cursor algorithm.
- Function31 projection-before-announcement: compatibility transaction decision constrained by immediate client reload, not recovered server ordering.
- `active_campaign_battle`: our source-shaped session model, not recovered server persistence internals.
- MID50/MID117 UUID/UoW exactly-once: compatibility safety architecture, not proof of official-server request identity.

## 6. Claims upgraded by corroboration
- MID112 mandatory numeric-zero cursor completeness is now direct source fact plus reproduced runtime failure evidence.
- 155 Normal↔Super mappings are source-census facts, not arithmetic hypothesis.
- 155-node Super next/last chain is source-census fact; only server advancement trigger remains unknown.
- Challenge Chapter16 gate is direct client/source fact (`24111` gate + translation), not memory-based assumption.

## 7. What remains genuinely unknown
See `CURRENT/CURRENT_UNKNOWNS.json`. Highest impact: Pass128.2 client runtime acceptance; Campaign Player EXP/Mana economy; official repeat-drop algorithm/missing pools; exact original Super cursor/materialization trigger; remaining RNG integration/policy closure. Physical original-server DB schema remains unknown and low priority.

## 8. Highest-value next investigations
First and non-negotiable: Pass128.4 fresh/new-account client smoke. Only if accepted: Campaign EXP+Mana reconciliation, then Pass108 RNG closure, Generated/Unique, Girls/Equipment, deferred verticals. Original-server-only questions should be reopened only when new authoritative evidence appears.

## 9. What a fresh HeadLLM reads first
`00_PASSMAP/CURRENT/README.md`, then the seven current core files listed there. Query the one current SQLite or a single route chosen by `TASK_ROUTING.json`.

## 10. What a fresh HeadLLM should not waste time reading
Do not bulk-read Pass62–Pass128 narratives, historical migration handoffs, old `CURRENT_NEGATIVE_MEMORY_PASS<n>` files, old readiness/frozen reports, predecessor SQLite catalogs, or cold archives unless a routed provenance question requires them.

## Assessment
This is materially healthier: current authority is explicit, uncertainty is queryable, original behavior is separated from compatibility architecture, stale authority is quarantined, historical evidence remains recoverable, and startup no longer depends on understanding 128 passes. No architecture was redesigned merely for cleanliness.
