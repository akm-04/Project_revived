# Pass121.0 — Super MID117 Daily-Limit Atomicity

Pass121 implements only the first accepted Pass120 structural correction. Backend advances to **v0.15.2-pass121.0** (`50fc22fd28b3073903b60cde784e330a5eb5a438849bc1f67073ba56eb3ecbf6`). Effective source remains `app-assets/output/assets/src_64` from canonical assets `89f0f830508b92e5fff6ad53c6a9dae961a14042dbfdf5649008efb8353f5608`. No OTA bytes changed.

## Source feedback loop

Effective `src_64` was re-read before the behavior change. `MapDetailWindow.lua` and `NewMapDetailWindow.lua` use the current non-Normal `dailyLimit` as multi-sweep `sweep_num`; `SweepWindow.lua` replaces local remaining attempts from `response.campaign.daily_limit`. Direct parsing of `campaign.lua` + `chapter.lua` confirms **155 unique Super stages, all baseline daily_limit=3**.

## Implementation

The existing MID117 UUID, permanent receipt and PlayerUnitOfWork boundary remain unchanged. A Super request first proves source Super membership. Inside the existing transaction, after receipt replay and request/VIP validation, the exact unlocked Super row must satisfy `0 < sweep_num <= daily_limit`. This gate runs before cost preflight and RandomOutcomeService. On success, existing costs/rewards apply and then the same row decrements by exactly `sweep_num` before response/receipt staging. A committed same-UUID retry therefore replays first and consumes zero additional attempts.

## Validation

Focused Pass121 tests passed 3→2, 3→1, 3→0, over-limit fail-before-entropy/cost/receipt, same-UUID replay, zero-attempt fail, strict Super source membership, and Normal-MID117 non-regression. Pass117 Campaign reconciliation, Pass92 MID116 reset, and Pass79 Daily Reset neighbor regressions also passed. Python static parsing passed across the backend/tool tree. Runtime client smoke remains deferred to the accepted Pass124 reconciliation cycle.

## Next

Pass122 is now the active implementation target: dedicated raw-source `ChallengeCampaignCatalog`, 144-row/137-edge graph projection/self-heal, seven-root compatibility seeding, deterministic first-clear quantity `increase_rate // 10000`, and Challenge MID113/MID114 progression/reward settlement. Generated/Unique remains paused.
