# Pass114.0 Migration Handoff

Canonical backend is `gxb-backend-v0.15.0-pass114.0.zip` SHA-256 `4876246704d9b00af4839e5a1a2d72988f788b07a471a17253eba1c7daf811a4`. Canonical source remains `all-assest-rechecked.zip` SHA-256 `89f0f830508b92e5fff6ad53c6a9dae961a14042dbfdf5649008efb8353f5608`, effective `app-assets/output/assets/src_64`.

Pass114 activates ordinary MID117 repeat-stack settlement. OTA resource version is 1.631.6. Only ordinary MID117 receives `campaign_sweep_op_id=mid117-<UUIDv4>`; event-specific sweep MIDs remain untouched. Permanent UoW receipts provide no-reroll/no-double-spend replay with exact static per-sweep outcomes and current cumulative projections.

24 positive repeat pools absent from effective source hard-fail before cost/entropy. Pool ID zero remains valid. Campaign repeat policy remains private-server compatibility reconstruction; do not call it official server behavior. MID113 repeat RNG remains disabled. Campaign EXP/Mana/additional remain deferred.

**Runtime status:** static/fresh-extraction accepted; client smoke pending. Next pass should reconcile real Campaign sweeps, including a force-close/retry exactly-once test if practical. Only after runtime acceptance should the roadmap advance to Generated/Unique Instance settlement.

Mandatory `src_64` Architectural Feedback Loop remains binding for all future backend behavior changes.
