# Pass131.0 Technical Report — Campaign Player EXP + Mana Implementation

## Scope
Pass131 implements only the previously researched MID117 Campaign sweep Player EXP + Mana plane. OTA/Lua, MID113/MID114 manual battle semantics, Campaign authorization, RNG/drop policy, persistence schema and the exactly-once UUID receipt architecture are preserved.

## Source feedback loop
Effective source remains `app-assets/output/assets/src_64` from `all-assest-rechecked.zip` SHA256 `89f0f830508b92e5fff6ad53c6a9dae961a14042dbfdf5649008efb8353f5608`. The implementation was rechecked against SweepWindow, BattleWinWindow, SelfPlayer, Backend, CampaignTable, NewMapDetailWindow, campaign.lua, chapter.lua, player.lua and function.lua. All 584 canonical Normal/Super rows match backend metadata for energy_cost, mana_gain, partner_exp, daily_limit and relate_campaign_id.

## Implementation
A stateless `CampaignSweepEconomyPolicy` plans per-run wire rows and cumulative settlement totals. Each successful sweep returns raw `economys[i].exp = energy_cost` and `economys[i].mana = mana_gain`. Cumulative account EXP is applied by the existing PlayerProgressionService and Mana by the existing EconomyLedger/RewardTransactionService within the existing PlayerUnitOfWork. The client-backed <=10 curve is implemented as 1x raw EXP while simulated pre-run level <=10 and 3x for subsequent runs after crossing above 10. This remains an IMPLEMENTATION_DECISION, not recovered original-server internals. Mentor/Student EXP remains deferred.

Duplicate MID117 receipt replay does not reapply rewards: per-run `economys` stays frozen while cumulative player-owned exp/lev/energy and ledger-owned mana/crystal projection refresh from current canonical owners.

## Validation
Focused Pass131 self-test: 10/10 PASS. Key Pass117, Pass121, Pass122, Pass123, Pass128.2, Pass128, Pass129 and PlayerProgression neighbors pass. Forced post-RNG progression failure rolls back EXP, Mana, Energy, Crystal, inventory and receipt state with no persistence commit. Historical Pass113/Pass114 assertions that encode older pre-Pass131 behavior remain historical and are not rewritten.

Backend artifact: `gxb-backend-v0.15.8-pass131.0.zip` SHA256 `64bf1a40f409a9ad0812bf9a1c4284808f6a2d986ae00461fa9fb3531a87e4c7`. OTA remains 1.631.8. Static/regression accepted; real-client MID117 smoke is required before moving to RNG closure.
