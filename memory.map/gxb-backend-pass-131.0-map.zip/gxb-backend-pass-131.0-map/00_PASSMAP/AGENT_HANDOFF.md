# Pass131.0 agent handoff

Canonical current authority is `00_PASSMAP/CURRENT/`. Read that kernel in its documented order, then query only `00_PASSMAP/databases/GAME_KNOWLEDGE_CATALOG_PASS131_0.sqlite` for deeper memory. Historical pass reports and cold SQLite archives are provenance, not current truth.

Current backend: `gxb-backend-v0.15.8-pass131.0.zip` SHA256 `64bf1a40f409a9ad0812bf9a1c4284808f6a2d986ae00461fa9fb3531a87e4c7`. OTA 1.631.8 unchanged. Pass131 implements Campaign MID117 Player EXP + Mana on existing canonical progression/economy/UoW owners and is static/regression accepted. Runtime client smoke is pending.

Next: analyze Pass131 client debug using `00_PASSMAP/PASS131_CLIENT_TEST_PLAN.md`. If clean, mark runtime accepted and move to Pass108 RNG backbone closure. Do not reopen Mentor/Student EXP for core gameplay.

Mandatory: cross-check effective `app-assets/output/assets/src_64` before every future backend behavioral modification.
