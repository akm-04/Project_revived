# Pass130.0 — Campaign Player EXP + Mana implementation blueprint

## Status
Research and planning only. Backend **v0.15.7-pass129.0** (SHA256 `57854049e4f9319026d5703d81a0a0dc922690b29d78fb9e6110132eb1818d41`) and OTA **1.631.8** remain unchanged. Pass129 client smoke is runtime accepted. This blueprint is the authorized next implementation target, but **no backend code is changed in Pass130**.

## Core source contract
1. Canonical Normal/Super Campaign membership comes from `chapter.lua`; all 584 mapped stages have positive `energy_cost` and `mana_gain` from Chapter 1. There is no later EXP/Mana reward unlock level.
2. Manual Campaign account EXP display base is `campaign.energy_cost`; `partner_exp` belongs to Hero/partner EXP, not account EXP.
3. `CampaignTable:gainMana()` reads `mana_gain`.
4. Ordinary MID117 `economys` is one row per sweep. `economys[i].exp` is treated by `SweepWindow` as a **base** amount; `economys[i].mana` is displayed directly. `additional` is a separate item plane.
5. Top-level `economy_` is cumulative authority. `SelfPlayer:economySyncEvent_` advances level from cumulative `exp`, applies level-up Energy client presentation, accepts `new_funcs_`, and synchronizes Mana.
6. Sweep eligibility (3 stars, daily limits, VIP/monthly multi-sweep privilege) is independent from EXP/Mana reward eligibility and already exists in the current MID117 path.

## Selected compatibility policy
Because ordinary official MID117 server settlement code/captures are absent, the low-level multiplier remains an original-server UNKNOWN. For private-server compatibility we will mirror the client-visible rule exactly enough for core play:

- `base_exp = energy_cost` per successful run.
- `wire economys[i].exp = base_exp`.
- `wire economys[i].mana = mana_gain`.
- Begin from the **pre-request** player `(lev, exp)` snapshot.
- For each sweep result in order:
  - if simulated `lev <= 10`, account EXP award for that run is `base_exp`; advance the simulated cumulative EXP/level according to the same source threshold used by `SweepWindow`;
  - once simulated `lev > 10`, account EXP award is `base_exp * 3` for that and all later runs.
- Total Mana award is `mana_gain * sweep_num`.
- Mentor/student bonus is **not included**. It is deferred with the Social/teacher vertical by explicit project scope decision.

This is an `IMPLEMENTATION_DECISION`, not recovered official-server code.

## Architecture — reuse first
The current backend already has the correct owners. Do not create a new Campaign economy subsystem.

### New pure policy only: `CampaignSweepEconomyPolicy`
A small state-free policy/planner should compute the deterministic sweep economy plan. Suggested immutable output:

```text
SweepEconomyPlan
  per_run_economys: tuple[{exp: base_exp, mana: mana_gain}, ...]
  per_run_account_exp: tuple[int, ...]       # audit/test visibility
  total_player_exp_gain: int
  total_mana_gain: int
  simulated_start_level / simulated_end_level
  policy_id / version
```

It must not mutate PlayerState, consume RNG, own persistence, authorize stages, or stage receipts. It is a domain policy seam that can later move behind a `CampaignSweepService` without changing balance ownership.

### Existing owners to reuse
- **RewardTransactionService** — already used by manual MID114 for `mana` + `player_exp`; reuse it for MID117.
- **EconomyLedger** — canonical Mana owner.
- **PlayerProgressionService** — canonical cumulative EXP/level owner, including level-up Energy and FunctionState/Elite Campaign observations.
- **MutationSettlementService** — keep current Energy/ticket/crystal/item settlement. Do not force `exp` into the generic RESOURCE family.
- **PlayerUnitOfWork** — remains the single atomic rollback/commit boundary.
- **MID117 durable receipt** — remains the exactly-once replay boundary; no new receipt namespace/schema is required.

## Planned MID117 order inside the existing UoW
The ordering matters because RNG must not be consumed before deterministic rejection gates.

1. Normalize request + verify MID117 UUID/fingerprint; replay committed receipt if present.
2. Validate Campaign source membership/access, Super row/attempts, repeat pool availability, sweep privilege and existing cost plan.
3. Read source `energy_cost` + `mana_gain`. Build `CampaignSweepEconomyPolicy` plan from the pre-request player progression snapshot.
4. Build a `RewardPlan` with `EconomyGrant("mana", total_mana)` and `EconomyGrant("player_exp", total_player_exp)`; call **`RewardTransactionService.validate()` before RNG**.
5. Consume existing Campaign repeat RNG and build the per-run item rows.
6. Apply the existing cost + item `MutationPlan` through `MutationSettlementService`.
7. Apply the validated Campaign economy `RewardPlan` through `RewardTransactionService` **inside the same PlayerUnitOfWork**. Any failure still rolls back costs/items/RNG-visible committed state.
8. Apply Super daily-attempt decrement, still in the same UoW.
9. Render response:
   - `items` = current per-run item rows;
   - `economys` = immutable policy rows (`base_exp`, `mana_gain`);
   - `additional` unchanged;
   - `campaign` unchanged except existing Super attempt semantics;
   - `economy_` = canonical post-mutation cumulative keys. It must include final `energy`, `mana`, `exp`, and `crystal` when crystal sweep applies; include `lev` if the existing progression projection emits it.
   - `new_funcs_` continues to come from existing UoW semantic deltas; do not synthesize it in Campaign code.
10. Stage the normal MID117 receipt and commit once.

## MID117 replay adjustment
`build_mid117_replay_payload()` already stores the static per-run `economys` and records the cumulative `economy_` key list. The only bounded replay change required is in `WorldRepository._mid117_replay()`:

- if a projected key exists on `PlayerState` (e.g. `energy`, `exp`, `lev`, and compatible player-owned fields), refresh it from PlayerState;
- otherwise query the canonical EconomyLedger for ledger-owned keys such as `mana`/`crystal`;
- keep static `economys` frozen from the committed operation.

This mirrors the existing manual Campaign duplicate projector and preserves exactly-once semantics without inventing a second receipt format.

## Why not merge everything into one MutationPlan?
`exp`/`lev` are explicitly owned by `PlayerProgressionService`, whose `grant_exp()` performs level transitions, level-up Energy grants, FunctionState observation and Elite Campaign unlock coordination. Modeling EXP as a generic scalar RESOURCE would bypass these side effects and violate ResourceRegistry ownership. The correct atomicity boundary is the **outer PlayerUnitOfWork**, not one monolithic leaf plan.

## Implementation surface (bounded)
Expected files for the next pass:

1. **new** `gxb_backend/state/campaign_sweep_economy_policy.py` — pure planner/policy.
2. `gxb_backend/state/world_repository.py` — integrate plan/reward application; replace zero placeholder; widen replay projection to PlayerState-first.
3. `gxb_backend/state/request_services.py` only if explicit policy injection is chosen; prefer no new canonical owner graph because the policy is stateless.
4. Focused tests for policy, MID117 wire projection, replay/idempotency, low-level crossing, level-up Energy/new_funcs behavior, Super attempts, Normal/Super existing suites.

No OTA/Lua change is planned. No persistence schema change is planned. No MID113/MID114 semantic change is planned.

## Required tests before client smoke
- Level >10 Normal one-sweep: base EXP row = `energy_cost`; cumulative EXP delta = `energy_cost*3`; Mana delta = `mana_gain`.
- Level >10 Normal ten-sweep: each row carries raw base; cumulative EXP/Mana exactly match totals; one receipt commit.
- Level 10 crossing batch: first row(s) at `<=10` award 1x, later rows after simulated crossing award 3x; static per-run rows remain raw base.
- Super sweep: same EXP/Mana policy plus existing atomic daily-limit decrement.
- Crystal sweep: final `economy_` includes crystal + energy + mana + exp as appropriate.
- Level-up during sweep: PlayerProgressionService grants source Energy award; final `economy_.energy` reflects cost then level-up award; `new_funcs_` comes from semantic deltas.
- Duplicate identical UUID: no second Energy/ticket/crystal/Mana/EXP/item/attempt mutation; static `economys` replays identically and cumulative fields refresh from current canonical owners.
- UUID fingerprint conflict: fail closed unchanged.
- Unsupported/Challenge sweep: remains blocked; no new economy mutation.
- Missing repeat pool / insufficient costs / invalid source: no RNG consumption and no EXP/Mana grant.
- Mentor/social state: deliberately irrelevant to core policy; no bonus is applied.

## Client reconciliation target
After static tests, use a known 3-star Normal stage and a Super stage:
- verify SweepWindow displays non-zero EXP and Mana on every row;
- verify top-bar/account cumulative EXP/Mana match the backend;
- verify level-up popup/energy behaves normally if a threshold is crossed;
- retry/replay the same MID117 operation where practical and confirm no duplicate rewards;
- verify Super daily limits still decrement once.

## Scope boundary
Mentor/student academy rewards are intentionally deferred. General RNG policy remains the existing Pass112+ private compatibility policy and is not reopened here. After runtime acceptance of this Campaign economy pass, return to the accepted roadmap: **RNG backbone closure → Generated/Unique settlement → Girls/Equipment economy closure → deferred verticals**.
