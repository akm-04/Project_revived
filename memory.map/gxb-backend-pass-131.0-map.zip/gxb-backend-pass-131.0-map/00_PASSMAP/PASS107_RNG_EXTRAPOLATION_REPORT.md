# Pass107.0 — RNG Backbone Stage 1 Extrapolation Report

## Verdict

**Backend remains frozen at `gxb-backend-v0.13.1-pass105.0.zip` (`b89c76c4c8345e216f1233f27939915a51388997091d454dfe04ac60ebf13d06`). No Python backend code was changed.**

Pass107 establishes the broad RNG source census and maps the major client outcome contracts, but **Stage 1 is intentionally not closed yet**. The recovered source contains a large semantic tail—especially event/mode tables and local UI/minigame `math.random` callsites—where a keyword such as `rate`, `weight`, `drop`, `random`, or even `SUMMON` is not enough to prove the exact server algorithm. The next pass should remain Stage 1 and finish that semantic classification/reconciliation before any Stage 2 design.

## Audit method

The effective source authority was `app-assets/output/assets/src_64` from the canonical assets SHA-256 `89f0f830508b92e5fff6ad53c6a9dae961a14042dbfdf5649008efb8353f5608`. The audit used four independent discovery axes:

1. MID declaration + request/callback callsite discovery.
2. Data-table schema scans for `rate`, `weight`, `drop_rate`, `roll_type`, `dropbox`, slot-drop/rate and generated-stat fields.
3. Exact `math.random` / `math.randomseed` call census to separate client-local simulation/presentation randomness from server-authoritative outcomes.
4. Callback mutation inspection to record the shape the client actually consumes after a successful server result.

Machine census totals:

- **152** strong-signal data-table candidates: event_randomization=59, weighted_reward_pool=5, campaign_or_battle_reward=12, random_stock_rotation=41, semantic_candidate=20, generated_or_rerolled_stats=5, world_or_mode_randomization=8, summon_or_draw_policy=2.
- **41** recovered random-stock table families.
- **209** broad RNG/reward/refresh/draw-like MID discovery candidates; **201** have source callsites. This is deliberately over-inclusive and is *not* an RNG-completion count.
- **171** Lua files contain `math.random` or `math.randomseed`: **350** `math.random` calls + **57** `math.randomseed` calls.
- Local-call split found **92** battle-simulation files and **61** UI/minigame/presentation files still needing final semantic split.

## Critical Pass106 authority correction — MID70

Pass106 correctly removed the old *classic Summon MID50/MID70* wording, but one self-heal sentence went too far by saying no MID70 assignment exists. Effective `mid.lua` actually declares:

- `SUMMON_HERO = 50`
- `SUMMON_SUPER_HERO = 305`
- `MAGIC_SUMMON_BUY = 70`
- `MAGIC_SUMMON_SWITCH_HERO = 71`

Therefore the durable rule is: **classic Summon is MID50; Super Summon is MID305; MID70 exists but belongs to Magic Summon.** Cold Pass106 provenance is retained unchanged; Pass107 HOT/SQLite authority supersedes the overbroad sentence.

## Recovered RNG contract families

### 1. Classic Summon — MID50

`SelfPlayer.summonHero()` consumes `result[]`. A row with `is_partner=true` is a full generated Hero object and is immediately added to Hero state; otherwise `{table_id,item_num}` is added to Backpack. The same response may carry `reward`, `extra_reward`, `sakura_items[]`, `stick_items[]`, and `summon_info` free-summon state.

`summon.lua` exposes pool and policy fields including `dropbox`, `super_dropbox`, `special_dropbox`, `rate_bottom`, `rate_step`, `fix_rate`, and `fix_max_num`. These are evidence for domain policy parameters, **not proof of the complete original server probability/pity algorithm**. Stock request flow still has no source-native per-click operation UUID, so the previously accepted UUID bridge remains a prerequisite before MID50 implementation migration.

### 2. Super Summon — MID305

`SelfPlayer.summonSuperHero()` expects `partner_info` as a complete Hero object. This is source-distinct from MID50 and must be audited/migrated independently.

### 3. Magic Summon — MID70

`SelfPlayer.magicSummonHero()` uses `MAGIC_SUMMON_BUY=70`. Its `result[]` has the same hero-or-stack shape as classic Summon, with optional `reward` and `stick_items`. This is a real RNG family but is **not** the initial MID50 migration target.

### 4. Stone Summon — MID59 and Pet Summon — MID781

MID59 returns a full Hero-shaped response and the client removes `stone/stone_num` after success. This is a generated-Hero boundary whose exact pool policy still needs dedicated recovery.

MID781 is summon-like, but the client supplies a Pet `table_id` and populates a Pet from the response. It may be deterministic hatching. Pass107 therefore records it as **randomness unproven**, preventing a false positive from a name-only scan.

### 5. Generic weighted dropboxes

Raw `dropbox.lua` exposes `dropbox_id`, `item_id`, `item_num`, `drop_rate`, and `roll_type`. This proves weighted/roll metadata exists. It does **not** prove the exact original server selection algorithm; client wrappers primarily expose item/count lookup.

### 6. Campaign — MID114 / MID117

MID114 returns stack-style `items[]` rows `{item_id,item_num}` alongside campaign/trial/challenge state. MID117 `SweepWindow` consumes `items` as **an array of per-sweep reward arrays**, adding every row to Backpack; `economys` is separate and `additional[]` is also stack-like.

This reconfirms the Pass106 reorder: Campaign repeat RNG can precede unique-instance settlement. However, `campaign_dropbox.increase_rate` still does not recover a complete roll algorithm and the previously identified **24 referenced repeat pools absent from recovered source remain negative memory/fail-closed**.

### 7. Random gifts/chests — MID241 and related families

The exact source symbol remains the typo `EXCHAGE_CODE_HERO = 241`. `GiftbagUseWindow` sends `{item_id,gift_id,num}`, removes the consumed item on success, and routes returned rewards through `SelfPlayer:handleRewards`.

This response boundary is polymorphic: ordinary stacks, `to_stone` conversions, full generated Hero objects, and a separate `spirit_awards[]` collection for unique Spirit/Horcrux instances. This makes MID241 both an RNG boundary and a future unique-instance consumer.

Raw `gift.lua` has 5,905 rows, of which 294 contain nonzero `drops`. That does not contradict Pass97's 189 count: Pass97 measured the **referenced recovered subset**, whereas Pass107's 294 is the raw table population.

March chest MIDs 339/341 also return generic reward collections but remain a parked March vertical slice.

### 8. Hero/Pet Practice — proposed outcome RNG

Hero Practice MIDs 124–128 and Pet Practice MIDs 129–133 form a different transaction shape from instant grants. The roll returns candidate `info/add_attr` or `add_attrs`; `PRACTICE_SAVE` / `PET_PRACTICE_SAVE` explicitly commits the chosen state. AUTO contains repeated candidate metadata.

`practice_type.lua` exposes limits/weights/cost tiers. Separately, `WashHeroWindow.randomDialog()` is client-local cosmetic randomness and must not be mistaken for stat-roll authority.

### 9. Inscription rebuild — proposed multi-roll RNG

MID1401 rebuild can return `inscript_items[]`; the UI supports one or ten rebuild candidates. MID1405 saves and MID1406 abandons. This is therefore a **propose → choose/save/abandon** lifecycle, not an immediate economic grant.

`inscription.lua` exposes `rand` vectors and `inscription_rate.lua` exposes `rate_suit`, `rate_step`, `max_num`; again these are policy evidence rather than a completely reconstructed selection algorithm.

### 10. Rune generation — unique instance RNG

A Rune is not a stack. `Rune.lua` carries unique `rune_id` plus `table_id`, star/power/rarity, main attribute, extra attribute/value, and up to four bonus attribute/value pairs. `rune.lua` exposes `attr_ids` and `attr_rate`.

Legacy MagicShop source references `LOAD_MAGIC_SHOP` / `SHOP_MAGIC_BUY` / `SHOP_MAGIC_REFRESH`, but these symbols are not assigned in the current recovered `mid.lua`. Numeric authority is therefore unresolved and must not be invented.

### 11. Spirit/Horcrux generation — unique instance RNG

Recovered Spirit/Horcrux state uses unique `spirit_id` plus table/level/main/sub-stat selectors and values. Backpack stores these objects separately from stack inventory. `spirit.lua` exposes main/sub candidates, `sub_num_rate`, and value matrices.

`HUNQI_CREATE=3098` is declared, but this pass did not find an active request callsite. That is recorded as a declaration/callsite gap, not proof of an implemented client route.

### 12. Random shop stock

Shop MIDs 32/33/34/37 operate on returned inventory entries and refresh metadata. **41** recovered table families use slot/drop/rate style data, including general shop, black market, Arena/Guild/Crusade shops, many Team shops, Battle Pass, Vending, and event shops.

Local `ShopTable.lua` `math.random` usage selects presentation/dialogue/sound and is **not** stock generation. Store remains a separate parked vertical slice.

### 13. Event gacha / turntables / wish pools

The source contains a large independent event-RNG surface: Snow gacha, Chocolate slot/pool, Polar Night light/dark gacha, Ragnarok gacha/raffle, Love Letter raffle, Square Turntable, Lvbu summon, Activity1220/Contract summons, Balloon pools, Fifth Anniversary gacha, Wish/Candle Wish, and others.

Common callback shape is often `awards[]` plus event-owned state such as `drop_info`, `base_info`, `award_times`, pool locks/refreshes, or next-pool state. Data tables frequently expose `drop_rate`, `rate`, `weight`, and `pool_id`. These similarities prove reusable *mechanics may later exist*, but **the policies remain event-owned** and must not be flattened into one global probability formula.

### 14. World/exploration/mode randomness

Adventure, Auction, Treasure, Beach, Region, Zhuge, March-like and other tables expose `rate`, `weight`, `drop_rate`, `chest_rate`, `enemy_rate`, `rate_fight`, or `random_base` fields. This is a genuine discovery surface but still contains the largest semantic tail: exact callbacks and server/client responsibility must be resolved family-by-family before Stage1 closes.

### 15. Non-economic server random selection

`GENERATE_PLAYER_NAME=119`, Arena refresh/opponent selection, random-player discovery and similar flows are random but are not economic reward RNG. They form a separate server-selection plane. Authentication/session/token entropy remains excluded as before.

### 16. Client-local battle simulation RNG

The exact local census found 171 Lua files with `math.random`/`math.randomseed`; 92 are battle-simulation files. These calls affect local battle targeting/simulation/replay behavior and are not evidence that a future server `RandomOutcomeService` should absorb them.

### 17. Client-local presentation/minigame RNG

Dialogue, sounds, animations, loading/display choices and some minigames also use local randomness. The audit has 61 UI/minigame/presentation files still requiring semantic closure. This is the principal reason Stage1 remains open rather than falsely declaring “every RNG system” finished from keyword matches.

## Data hygiene / false-friend corrections

The raw schema scanner intentionally over-collects. Four important corrections already prevent false RNG conclusions:

- `partner.lua`, `partner1.lua`, `super_partner.lua`: `attr_1_rate..attr_6_rate` are contextual stat multipliers, not RNG weights.
- `person_display_words.lua`: `is_random/range_random_nums` is presentation randomness.
- `ShopTable.lua` local `math.random` is presentation only.
- `WashHeroWindow.randomDialog()` is presentation only.

The full 152-table signal census, 209-MID broad surface and 171-file local-random census are stored as machine-readable Pass107 artifacts so the next extrapolation pass can close the tail without rescanning from scratch.

## Stage 1 closure decision

**Pass107 does not authorize Stage2.** It establishes that the RNG backbone must eventually coexist with at least six different source-observable outcome lifecycles:

1. immediate stack/generated grants;
2. proposed rolls with explicit save/abandon;
3. generated unique instances;
4. random inventory/encounter selection;
5. event-owned pools with auxiliary state;
6. client-local battle/presentation/minigame randomness that may stay outside server outcome RNG.

Those are *extrapolation facts*, not an architecture design yet.

### Recommended next pass — still Stage 1

Pass108 should close the remaining semantic tail: classify the 61 mixed local-random files; trace Adventure/Auction/Beach/Region/Zhuge/Treasure and representative event callback chains; reconcile declaration/callsite inconsistencies; and produce a final authority matrix of **confirmed server RNG / deterministic selection / client-local RNG / unresolved**. Only then should Stage2 begin.

## Source integrity

Critical source hashes used by this pass are recorded in `PASS107_LIVE_CHECKPOINT.json`/SQLite and the machine census. Effective source SHA-256 remains `89f0f830508b92e5fff6ad53c6a9dae961a14042dbfdf5649008efb8353f5608`; backend SHA-256 remains `b89c76c4c8345e216f1233f27939915a51388997091d454dfe04ac60ebf13d06`.
