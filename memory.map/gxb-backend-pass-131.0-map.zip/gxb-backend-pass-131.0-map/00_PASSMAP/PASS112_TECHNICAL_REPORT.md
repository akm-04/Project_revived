# Pass112.0 Technical Report — Campaign MID117 RNG Audit & Design

## Executive result

Pass112 is an **audit/design-only** pass. Canonical backend remains byte-for-byte `gxb-backend-v0.14.1-pass111.0.zip` SHA-256 `2af196494a344ac5a4a6f968cc5ac9885bff48ec5aa01fb31e375ec86485e9cb`. No Python or OTA backend artifact was modified.

Pass111 is now promoted to **runtime accepted**: the attached debug capture shows OTA 1.631.5 current and 16 captured MID50 requests all carrying source-generated `summon_op_id` values through the real Summon handler; the user's force-close test confirmed exactly-once persistence and non-VIP testing also succeeded.

The Campaign MID117 repeat-item design is now closed enough for phased implementation, but the historical official-server RNG formula is **still not recovered**. The chosen formula is therefore explicitly versioned as a private-server compatibility policy bounded by source facts.

## Source callback contract

Effective `src_64/app/windows/SweepWindow.lua` confirms ordinary sweep defaults to MID117. Event campaign types replace MID117 with their own sweep MIDs and are not part of this design. The normal callback consumes:

- `items`: one item-array per sweep; every row is `item_id/item_num` and is mirrored into Backpack; empty per-sweep arrays are valid.
- `economys`: one `{exp,mana}` row per sweep. These are earned/display deltas, not cumulative economy snapshots. Missing `exp` defaults client-side to 12, so the existing backend's explicit zero rows are an intentional anti-fabrication safeguard.
- `additional`: extra item rows, separately mirrored into Backpack.
- `campaign`: current campaign/daily-limit/reset-count projection.
- optional `trial`, `challenge`, and `chapter_event` state.
- generic `economy_` remains the client's absolute cumulative projection path and must be rendered live during replay rather than frozen.

MapDetail/NewMapDetail source confirms sweep costs/gates: `energyCost * sweep_num` plus either one Raid Ticket per ITEM_SWEEP or one Crystal per CRYSTAL_SWEEP, with multi-sweep privilege checks. Pass99 already owns those server mutations atomically.

## Drop-table structural finding

The effective source catalog contains 15122 raw Campaign drop rows, 917 Campaign rows, and 24 positive repeat pool references with no source rows. For the repeat plane specifically there are 479 unique populated referenced pools and 6500 unique referenced rows.

The important numeric facts are decisive:

- every one of the 479 populated referenced repeat pools has a total `increase_rate` above 10,000; the minimum pool total is 13197 and maximum is 793333;
- an individual row reaches 360000;
- 597 unique referenced repeat rows exceed 10,000;
- 349 of those are exact multiples of 10,000 and 248 additionally carry a residual;
- the table has no quantity column;
- previously preserved Pass48 classification showed high-rate rows are stackable item types.

Therefore `increase_rate` cannot represent a normalized one-of-pool weighted choice. A call to `RandomOutcomeService.weighted_index()` for this plane is specifically rejected by the Pass112 design.

## Locked compatibility algorithm

Policy: `campaign_repeat_rate_decomposition_v1`. Evidence class: **PRIVATE_SERVER_COMPATIBILITY_POLICY_SOURCE_BOUNDED_NOT_RECOVERED_OFFICIAL_SERVER_CODE**.

For each sweep independently, iterate source rows in preserved `pool_ordinal` order. For a row with integer nonnegative rate `r`:

```text
guaranteed, residual = divmod(r, 10000)
quantity = guaranteed
if residual > 0:
    draw = ROS.randbelow("campaign.repeat.residual", 10000)
    if draw < residual:
        quantity += 1
```

No entropy is consumed when residual is zero. Materialized occurrences are aggregated by item ID in first-source-occurrence order for that sweep. The existing deterministic `campaign.lua` `sweep_reward/sweep_reward_num` award remains a separate source-certain component and can be combined into the same per-sweep stack array.

This formula explains rates above 10,000 without inventing an absent quantity column: e.g. 360,000 means 36 guaranteed units; 13,332 means one guaranteed unit plus a 33.32% residual opportunity. It is reproducible with Pass110's scripted entropy contract and does not require persisted RNG state.

If later native/server/alternate-build evidence reveals the original formula, it must enter as a new policy version. Existing committed MID117 receipts remain replay authority.

## Missing-pool policy

Three states are frozen:

1. `repeat_dropbox_id == 0`: valid **no-random-pool** source state. Continue deterministic sweep settlement; never synthesize a pool.
2. Positive repeat pool with source rows: execute the versioned repeat policy.
3. Positive repeat pool with no rows: **fail closed before costs, RNG, mutation, or receipt commit** with a Campaign content-unavailable error.

The third state covers exactly 24 source references, all preserved in `PASS112_CAMPAIGN_MISSING_POOL_POLICY.json`; they are concentrated in Normal Campaign chapters 22 and 23. Adjacent-stage substitution is forbidden.

## MID117 source-native operation identity

Pass112 freezes `campaign_sweep_op_id = mid117-<UUIDv4>`. The future OTA patch belongs only in `SweepWindow.lua::willOpen()` after the actual request MID has been resolved. It must inject only when `var_26_0 == xyd.mid.SWEEP_CAMPAIGN`, and only when the field is absent/empty. This prevents contaminating Sakura/Chocolate/Fourth Anniversary/Polar Night event sweep protocols.

`Backend.lua` retries the same params table, so the identity survives transport retry exactly as MID50's source-native bridge does. The provisional next cumulative resource version is 1.631.6, but Pass112 does not build it.

Fingerprint preimage is locked to `(MID117,campaign_id,campaign_type,sweep_num,sweep_type,awake_mission-or-0)`. UI-only `itemComposeID/needItemComposeNum`, balances, current Campaign state, pool content, and policy version are excluded.

## UoW receipt/replay design

Receipt domain: `mid117_campaign_sweep`; mode `CLIENT_UUID_V4`; retention `CLIENT_UUID_PERMANENT`.

Static replay authority contains exact committed `items` (array of per-sweep arrays), exact `economys` earned rows, exact `additional`, and optional `chapter_event`. Cumulative `economy_`, `campaign`, `trial`, and `challenge` are projections and are rendered from **current** state on replay.

Execution order is frozen as:

**identity/fingerprint → committed receipt replay/conflict → request/source/eligibility validation → UoW open → receipt recheck → cost validation → materialize deterministic + repeat outcomes through ROS → stage costs/rewards/state → build static replay payload → stage receipt → atomic commit**.

A compatible committed retry spends nothing, draws nothing, grants nothing again, and does not consume daily-limit state.

`SweepWindow` locally mirrors Raid Ticket removal after a successful callback. Normal transport retry delivers only the eventual successful callback, so replay must simply avoid a second server debit. Pass112 does not invent an unsupported Backpack snapshot field for hypothetical duplicate callback delivery.

## Deterministic economy boundary

`campaign.lua` exposes `energy_cost`, `partner_exp`, and `mana_gain`; the client displays per-sweep `economys.exp/mana`. Existing battle source also shows Normal Campaign battle EXP presentation derives from Campaign energy cost and client EXP multiplier logic. However the exact MID117 persisted economy/level boundary was not needed to close repeat-item RNG and is not being silently inferred here.

For the next two implementation passes, keep the existing explicit `economys={exp:0,mana:0}` and `additional=[]` unless a separately bounded source reconciliation explicitly authorizes those mutations. This avoids turning the RNG migration into an unrelated progression change.

## Backend fit

The existing architecture is already suitable:

- `WorldRepository.sweep()` is UoW-backed and owns costs/deterministic `sweep_reward` settlement.
- `CampaignDropPlanner` already separates source catalog, policy, randomness, occurrences, and aggregation, but repeat is currently `disabled_unknown`.
- `RandomOutcomeService` is request-scoped and proven through MID50.
- MID117 currently has no durable operation identity and its MutationPlan idempotency is `NONE`.

No rewrite is required; this is a migration of existing seams.

## Recommended implementation split

**Pass113 — Phase C1, inert foundation:** implement the versioned `campaign_repeat_rate_decomposition_v1` planner strategy, adapt Campaign entropy to RandomOutcomeService, add strict scripted tests, and implement MID117 identity/fingerprint/receipt helper code. Do not activate live MID117 RNG and do not ship an OTA bridge yet.

**Pass114 — Phase C2, activation:** add cumulative OTA identity bridge, activate receipt/replay in `WorldRepository.sweep`, settle materialized repeat stacks atomically with existing sweep costs/rewards, enforce the 24-pool fail-close policy, then run fresh-extraction and client smoke tests.

Generated/unique-instance settlement remains the next roadmap subsystem after Campaign completion.
