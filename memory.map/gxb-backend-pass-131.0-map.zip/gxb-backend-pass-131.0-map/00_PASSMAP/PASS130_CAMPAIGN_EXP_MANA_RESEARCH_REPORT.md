# Pass130.0 — Campaign Player EXP + Mana source reconciliation research

## Scope
Research/extrapolation only. Backend **v0.15.7-pass129.0** and OTA **1.631.8** are frozen. Pass129 client smoke from `debug.zip` is accepted before this research.

## Runtime gate
`debug.zip` SHA256 `24edfd5e78b83bcf9e393e0ae3743342c06845df85742ce27b56ab4ad437f5c7` shows clean Pass129 Campaign operation: MID112, Normal MID113→MID114, Super MID113→MID114, Super MID117 x2 and Normal MID117 x10 all complete without architecture/composition exceptions. Manual Normal 200019 produces EXP +18 and Mana +752 from energy_cost=6/mana_gain=752; Super 200024 produces EXP +36 and Mana +1608 from energy_cost=12/mana_gain=1608. Current MID117 intentionally returns zero EXP/Mana rows; this is the known deferred gap.

## SOURCE_FACT findings
- `BattleWinWindow.lua` uses `campaign:energyCost(campaignID)` as the manual player/account EXP display base. `partner_exp` is **not** the player EXP field.
- `SelfPlayer:getExpMulti()` returns 3. Manual runtime deltas in this smoke match `energy_cost * 3` exactly for Normal and Super.
- `CampaignTable:gainMana()` reads `mana_gain`; manual battle setup distributes that total across monsters and the runtime MID114 Mana delta exactly matches the row value.
- `SweepWindow` consumes one `economys` row per sweep. It treats `economys[i].exp` as a base amount, applies its own multiplier/display function, and displays `economys[i].mana` directly. `additional` is a separate item-award plane.
- `Backend.lua` dispatches top-level `economy_` generically; `SelfPlayer.economySyncEvent_` treats `economy_.exp` and `.mana` as cumulative authoritative balances and performs level-up handling from cumulative EXP.
- Sweep is stage-state gated: `NewMapDetailWindow` hides it below 3 stars. At 3 stars, Normal and Super are exempt from the generic level>=55 visibility gate. Normal defaults to 10 sweeps; Super uses remaining daily limit. Multi-sweep additionally requires VIP quick-sweep or monthly privilege, while one-sweep does not.
- Canonical membership must come from `chapter.lua`, not raw `campaign_type`. The census contains 429 Normal + 155 Super rows. **Every one** has positive `energy_cost`, `mana_gain`, and `partner_exp`, beginning in Chapter 1/open_lv 1. There is no separate Campaign-level EXP/Mana reward unlock threshold in those source fields. Function31/Super accessibility is a separate mode gate.

## STRONG_INFERENCE findings
- Ordinary MID117 `economys[i].exp` should be the raw/base stage EXP, very likely `energy_cost`, not `energy_cost*3`.
- Ordinary MID117 `economys[i].mana` should be the stage `mana_gain` per successful sweep.
- The <=10 sweep branch is likely an authoritative award curve: the client snapshots pre-request level/EXP, uses 1x while simulated level<=10, advances that snapshot per row, then changes later rows to 3x once it passes level 10. This is strong but not recovered server code.
- Mentor/student bonus likely belongs in account EXP settlement, but exact server ownership/rounding remains unrecovered.

## Backend fit — no implementation in this pass
The current backend already has the right owners: PlayerProgressionService for account EXP/level/function unlocks, EconomyLedger/Repository for Mana, MutationSettlementService + PlayerUnitOfWork for atomic MID117 costs/rewards/receipts, and Campaign source metadata for energy_cost/mana_gain. `_sweep_mutation()` explicitly hardcodes zero EXP/Mana with a comment saying the plane was deferred. Do **not** create another Campaign economy subsystem.

## Research disposition
The core wire/data/ownership map is complete enough for a planning pass. Two fidelity edges remain explicitly open: the exact official <=10 sweep cumulative EXP rule and exact teacher-bonus server rounding/ownership. They should be handled as bounded UNKNOWN/STRONG_INFERENCE, not fabricated as SOURCE_FACT.


## Planning continuation / disposition
The user explicitly deferred Mentor/Student EXP with the Social/teacher vertical. It is therefore no longer a core Campaign implementation blocker. The official-server low-level MID117 formula remains epistemically unrecovered, but the implementation decision is now to mirror `SweepWindow`'s client-visible pre-request simulation: raw `energy_cost` in each `economys.exp` row, 1x cumulative account EXP while simulated level <=10, then 3x after crossing.

Backend comparison confirms the existing ownership graph is sufficient. Manual MID114 already uses `RewardTransactionService` for Mana + `player_exp`; MID117 should reuse that service inside its existing `PlayerUnitOfWork`. The only new domain component proposed is a pure `CampaignSweepEconomyPolicy`, with no persistence/RNG/authorization authority. See `PASS130_CAMPAIGN_EXP_MANA_IMPLEMENTATION_BLUEPRINT.md`.
