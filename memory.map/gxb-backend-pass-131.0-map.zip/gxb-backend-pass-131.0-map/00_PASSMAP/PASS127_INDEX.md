# Pass127.0 Index — Progression Gates Modular Design

- `00_PASSMAP/PASS127_TECHNICAL_REPORT.md` — human technical report.
- `00_PASSMAP/PASS127_SRC64_FEEDBACK_LOOP.json` — fresh effective-source cross-check.
- `00_PASSMAP/PASS127_MODULAR_ARCHITECTURE.json` — module ownership/wiring.
- `00_PASSMAP/PASS127_FUNCTION31_BOOTSTRAP_DESIGN.json` — level11 + legacy lifecycle.
- `00_PASSMAP/PASS127_SUPER_ACCESS_POLICY_DESIGN.json` — MID113/MID117 bouncer and error policy.
- `00_PASSMAP/PASS127_SUPER_PROJECTION_DESIGN.json` — first/next frontier and cursor invariants.
- `00_PASSMAP/PASS127_QA_DECOUPLING_DESIGN.json` — Pass75 seed isolation.
- `00_PASSMAP/PASS127_TRANSACTION_ORDER.json` — exact future mutation ordering.
- `00_PASSMAP/PASS127_IMPLEMENTATION_TEST_MATRIX.json` — Pass128 acceptance matrix.
- `00_PASSMAP/PASS127_BACKEND_FIT_AUDIT.json` — frozen backend seams.
- `00_PASSMAP/PASS127_READINESS_DECISION.json` — implementation readiness.
- `00_PASSMAP/CURRENT_NEGATIVE_MEMORY_PASS127_0.json` — do-not-regress constraints.
- `00_PASSMAP/PASS127_LIVE_CHECKPOINT.json` — migration checkpoint.
- `00_PASSMAP/databases/GAME_KNOWLEDGE_CATALOG_PASS127_0.sqlite` — promoted machine knowledge.
