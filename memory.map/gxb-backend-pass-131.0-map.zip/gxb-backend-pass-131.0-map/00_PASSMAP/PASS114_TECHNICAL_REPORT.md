# Pass114.0 Technical Report — Campaign MID117 RNG Phase C2 Activation

Canonical backend: `gxb-backend-v0.15.0-pass114.0.zip`  
SHA-256: `4876246704d9b00af4839e5a1a2d72988f788b07a471a17253eba1c7daf811a4`

Pass114 activates ordinary **MID117 Campaign sweep repeat rewards** on the Pass110–113 RNG/UoW foundation. Effective `src_64` was re-audited before both Python and OTA behavior changes.

## Source-native identity and OTA 1.631.6

`SweepWindow.lua::willOpen()` first resolves the actual sweep MID. The cumulative 1.631.6 override then adds `campaign_sweep_op_id = mid117-<xyd.generateUUID()>` only when the resolved MID is ordinary `SWEEP_CAMPAIGN` (117), and only when no ID already exists. `Backend.lua` retains and retries the same params table, so transport retry preserves the operation identity. Sakura, Chocolate, Fourth Anniversary, Polar Night and other event-specific sweep MIDs receive no MID117 identity.

Because recovered `SweepWindow` performs local Raid-Ticket removal and Backpack reward mirroring on transport-success callbacks, the ordinary MID117 OTA callback also suppresses those local mutations when the JSON body contains a nonzero application `error_code`. Event-specific callbacks are unchanged.

OTA 1.631.6 contains **132** overrides: all **130** prior 1.631.5 overrides are byte-preserved; only src_32/src_64 SweepWindow are new.

## Durable exactly-once settlement

Live request-scoped MID117 now requires `campaign_sweep_op_id`. Receipt domain is `mid117_campaign_sweep`, mode `CLIENT_UUID_V4`, retention `CLIENT_UUID_PERMANENT`.

Execution order is deliberately bounded: operation identity/fingerprint → committed replay/conflict → source missing-pool preflight → open UoW → receipt recheck → request/VIP/type validation → **cost eligibility validation before entropy** → one `plan_repeat_sweep()` per constituent sweep → atomic Energy + Ticket/Crystal + deterministic `sweep_reward` + repeat stacks → permanent receipt → UoW commit.

A committed retry performs zero cost, zero RNG, zero reward mutation and zero duplicate receipt. Static authority preserves exact `items` array-of-arrays, `economys`, and `additional`; replay renders current Energy and, for CRYSTAL_SWEEP, current Crystal, plus current Campaign state. This prevents both rerolls and stale absolute-economy rewinds.

## RNG policy preservation

Pass114 does not alter Campaign RNG policy code. `campaign_drop_policy.json`, `campaign_repeat_rng_policy.json`, and `campaign_drop_planner.py` are byte-identical to Pass113. Live MID117 is simply connected to the already-approved `campaign_repeat_rate_decomposition_v1` policy through `campaign.repeat.residual`.

The policy remains an explicit **source-bounded private-server compatibility reconstruction**, not recovered official-server code. `weighted_index()` is not used.

## Missing-pool safety

The 24 positive repeat-pool references whose rows are absent from effective source fail closed before cost, entropy, deterministic partial reward, or receipt creation. `repeat_dropbox_id=0` remains valid deterministic-only. No neighboring or inferred pool substitution exists.

## Preserved boundaries

MID113 repeat battle RNG remains `disabled_unknown`. Event sweep protocols remain separate. Campaign EXP/Mana `economys` remains zero and `additional=[]` until those planes receive their own source-bounded reconciliation.

## Validation

Pass114 focused tests prove UUID fail-close, atomic first settlement, exact static/live-projection replay, fingerprint conflict, cost-before-entropy, independent multi-sweep arrays, all 24 missing-pool fail-closes, pool-zero deterministic behavior, Crystal replay projection, MID113 isolation, OTA preservation, MID117-only UUID injection, and the ordinary-MID117 application-error callback guard.

Fresh extraction also passes implementation-manifest verification, compileall, current Pass110 ROS, Pass111 MID50 behavioral checks, Pass105 firewall, Pass98 consumables, Pass96 Economy/VIP, Pass75 Campaign ownership and Pass70.1 Stone Summon regressions.

**Client runtime smoke remains pending.** The mandatory loop requires runtime/debug reconciliation before Generated/Unique Instance settlement becomes the active implementation subsystem.
