# Pass115.0 Targeted Campaign Bug Investigation

## Scope
Research/memory only. Backend remains `gxb-backend-v0.15.0-pass114.0.zip` SHA-256 `4876246704d9b00af4839e5a1a2d72988f788b07a471a17253eba1c7daf811a4`. No Python or OTA modifications were made. Debug evidence SHA-256 `1dfee34b4d30b73708c99240080d99edc9e5593d5d99695aa953ba0aec5c76ba`.

## Runtime reconciliation
Pass114 MID117 transaction/receipt mechanics are functioning in the supplied smoke log. Ordinary Normal and Super sweeps returned `error_code=0` and source-generated `mid117-*` operation IDs. The reported discrepancy is semantic/presentation rather than a transport or exactly-once failure.

## Finding 1 — Available Drops is not the raw reward whitelist
`NewMapDetailWindow.lua` / `MapDetailWindow.lua` render `campaign.lua.item_display` after a stage is cleared, while uncleared presentation uses `first_display`. Actual repeat reward rows come from `campaign.lua.dropbox -> campaign_dropbox.lua`. Many UI entries are finished/composed items while the reward pool contains their source fragments/components, linked through `item.lua.compose_item`. `Item.lua::initDrop()` also accepts actual Campaign drops absent from `itemDisplay()` and assigns them to battle-monster presentation, proving that the UI list is curated rather than exhaustive.

For runtime-tested Normal stage 1900019 and Super stage 1600022, every observed random MID117 reward was present in the configured source repeat pool; zero observed random items were outside source. Therefore Pass115 explicitly forbids changing MID117 to `item_display` or auto-composing raw components solely to match the panel.

## Finding 2 — First-clear reward staging is genuinely incomplete
MID113 currently relies on `legacy_first_clear_rate_10000_v1`, which stages only init rows whose `increase_rate == 10000`. Normal 1900019 and Super 1600022 contain no such rows, explaining the empty battle reward staging. Source/backend lifecycle still supports MID113 as the battle-visible staging boundary and MID114 as the later commit boundary.

However, `first_display` is not evidence that every displayed icon is guaranteed. Across Normal/Super init pools, rates are at most 10000, many pool totals exceed 10000, and Super 1600022 even displays 50021004 in `first_display` although that item is absent from its `init_dropbox`. The official first-clear sampler remains unrecovered and must not be invented in Pass115.

## Finding 3 — Super Campaign uses the same reward plane
No separate Super reward sampler/table was recovered. Super stages still use `campaign.dropbox -> campaign_dropbox.increase_rate` with Super-specific pool IDs. Normal repeat rows in the audited mode slice max at 6666; Super repeat rows reach 13332 and have materially higher aggregate pool rates. The small smoke sample does not establish a Super probability defect.

## Finding 4 — Challenge unlock projection gap
`MapWindow.changeToChallenge()` gates on the presence of Campaign **24111** in the client's `worldMaps_`/campaign map. `SelfPlayer.worldMapEvent_()` builds that state from `LOAD_WORLD_MAP.normal`, `.super`, and `.challenge`. Runtime projection shows Normal Chapter 23 / campaign 2300018 but `challenge={}`; therefore the client never receives 24111 even though Chapter 16's terminal Normal campaign 1600016 is already cleared. This is a real backend projection gap. Pass115 records the exact client contract but does not design or implement the correction.

## Roadmap state
Generated/Unique Instance settlement is paused. Campaign reconciliation remains the active blocker, specifically first-clear init-dropbox policy and Challenge 24111 projection. No corrective architecture is frozen in this pass.
