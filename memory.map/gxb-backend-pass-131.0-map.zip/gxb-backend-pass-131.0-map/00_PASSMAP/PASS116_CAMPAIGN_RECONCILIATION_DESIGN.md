# Pass116.0 — Campaign Reconciliation Design Freeze

**Scope:** design/architecture only. Backend remains byte-identical to `gxb-backend-v0.15.0-pass114.0.zip` (`4876246704d9b00af4839e5a1a2d72988f788b07a471a17253eba1c7daf811a4`). No Python or OTA implementation is performed in this pass.

## 1. First-clear `init_dropbox` policy

Pass116 broadened the Pass115 first-clear audit to the **full wire-mode membership from `chapter.lua`**, rather than the source-`campaign_type` slices used by the UI/display comparison. The complete Normal/Super first-clear universe is:

- Normal: 429 stages, 1593 init rows, zero missing positive init pools, rates 0..10000, 394 pools with total rate >10000, `first_number=0` throughout.
- Super: 155 stages, 849 init rows, zero missing positive init pools, rates 0..10000, 149 pools with total rate >10000, `first_number=0` throughout.

This source shape rejects normalized one-choice weighting. The frozen compatibility policy is `campaign_first_clear_bernoulli_v1`: each source row is an independent 10,000-scale Bernoulli; 0 never drops, 10,000 is guaranteed, intermediate values use `RandomOutcomeService.randbelow("campaign.first_clear.row", 10000) < rate`. A row can yield at most one occurrence because `init_dropbox` has no quantity column and all audited Normal/Super rates are <=10000. Duplicate source rows remain independent occurrences and are aggregated only for canonical inventory totals after the roll.

This is **source-bounded private-server compatibility policy, not recovered official-server probability code**. Challenge wire type 24 is explicitly excluded until Challenge battles become their own slice.

## 2. MID113 → MID114 durable state machine

The current backend already freezes a `CampaignDropPlan` in `player.active_campaign_battle`, and MID114 commits that frozen plan without rerolling. The remaining weakness is transport identity: a lost MID113 response can currently cause the same legitimate start to be evaluated again because MID113 has no source-native operation token.

The frozen design introduces one client identity, `campaign_battle_op_id = mid113-<UUIDv4>`, generated at the Normal/Super MID113 start boundary and carried unchanged through the local battle into MID114. `Backend.lua` already retries the same params table, so transport retry preserves that identity. `xyd.generateUUID()` remains identity entropy outside gameplay ROS.

Future OTA 1.631.7 (not built here) will patch both active team-selection implementations plus `BattleCreate`: generate/preserve the ID in MID113 params, copy it into battle-scene params, retain it in `BattleCreate`, and send it back in MID114. MID113 application errors must not push a local battle.

Server state becomes `NONE → STAGED → SETTLED_WIN/SETTLED_LOSS`, with a newer legitimate MID113 allowed to mark the previous uncommitted session `SUPERSEDED`.

MID113 receives a permanent UoW receipt (`mid113_campaign_battle_stage`) containing exact battle-visible static response and the frozen DropPlan audit. Retry of the same still-active operation replays exact items with zero entropy. A stale receipt whose session has been superseded fails closed rather than reactivating an old battle. MID113 still performs **no Backpack reward mutation**.

MID114 uses the same operation ID under a separate permanent result receipt (`mid114_campaign_battle_result`). It must verify the committed MID113 stage receipt and the exact active session before settlement. It never invokes the planner. On victory, the frozen canonical awards, Energy/result mutations and progression commit atomically; on loss, first-clear items are not granted and a new attempt receives a new UUID/roll.

The source-required wire rule remains: the staged drops stay in `BattleCreate.dropItems`; MID114 `items` remains empty for those drops because `BattleWinWindow` locally credits the battle-drop list after victory. Returning them again from MID114 would double the client mirror.

For result retries, the design extends the established static-vs-projection pattern: immutable committed result deltas are replayed exactly, while cumulative `economy_`, `chapter_info`, and the originally touched Campaign rows are rendered from current canonical state.

## 3. Challenge projection

The client gate is exact: both `MapWindow.changeToChallenge()` and Task Challenge logic require Campaign `24111` to exist in `selfPlayer.worldMaps_`. `SelfPlayer.worldMapEvent_()` obtains this from the `LOAD_WORLD_MAP.challenge` **array** and reads `campaign_id`, `star`, `daily_limit`, and `reset_count`.

The current backend's `challenge={}` projection is therefore the wrong shape and omits the unlock signal.

Chapter 16's terminal Normal source campaign is `1600016`. The future eligibility rule is: source row `1600016` with `star>0` is primary authority; `normal_chapter_id>16` is a safe legacy/compact fallback; `normal_chapter_id==16` alone is not enough. Client level 80 remains its own button-visibility gate and need not be duplicated in the row derivation.

When eligible with no existing Challenge progression, `LOAD_WORLD_MAP.challenge` should minimally contain:

```json
{"campaign_id":24111,"star":0,"daily_limit":0,"reset_count":0}
```

Do not synthesize the rest of Challenge progression. Existing/future Challenge rows should be preserved. On the first successful canonical MID114 clear of `1600016`, the same `24111` row should also appear in the MID114 `campaigns` projection so the existing `BattleCreate` callback unlocks Challenge immediately without requiring relog. `challenge_info` and Challenge battles remain separate parked domains.

## 4. Implementation sequencing recommendation

Pass116 freezes architecture only. Recommended bounded implementation is two passes:

1. **Pass117A — first-clear transaction/identity foundation + policy activation:** implement `campaign_first_clear_bernoulli_v1`, MID113/MID114 operation helpers/receipts, OTA 1.631.7 identity bridge, and deterministic no-reroll tests. Preserve MID113 repeat RNG disabled.
2. **Pass117B — Challenge projection:** convert `world_map.challenge` to list semantics, derive/synthesize only 24111 after canonical Chapter16 clear, add live MID114 unlock projection, and runtime smoke both restart/login and immediate unlock paths.

The two can be combined only if regression surface remains bounded. Generated/Unique Instance settlement stays paused until these Campaign corrections pass client smoke.
