# Pass126.0 Technical Report — Progression Extrapolation III

## Scope
Pass126 is **extrapolation / planning only**. No Python backend, OTA, migration, gameplay behavior, or test behavior changed. Canonical backend remains `gxb-backend-v0.15.4-pass123.0.zip` SHA-256 `68f7403a605d2e707361e17e8ba7bfdee85986cc00bc614f7cccbb1657590fe9` and OTA remains **1.631.8**. Effective source is `app-assets/output/assets/src_64`.

Pass126 does **not** finalize the modular architecture. Its job is to push the source evidence far enough that the next pass can design without guessing.

## 1. FunctionID31 deep dive — the client expects Super map state to change at unlock
`function.lua` identifies FunctionID31 as **Elite Campaign**, level condition `1|11`, with the user-facing tip “Unlock when Academy level reaches 11.” `FunctionOpenTable` parses type `1` as a level threshold.

The important authority detail is that `SelfPlayer.isFuncOpen()` does not recompute this locally. Login takes `func_ids` from the server, level-up news may carry `news.funcIDs`, and `NEW_FUNC_OPEN` updates `openFuncMap` from those server-issued ids.

FunctionID31 is special inside `SelfPlayer.onNewFuncOpen()`: when it arrives, the client sets `worldMapLoaded_ = false` and immediately reloads `LOAD_WORLD_MAP`. MainScene then starts `GUIDE_SUPER_BATTLE_START`.

MapWindow does **not** enable the Super selector by calling `isFuncOpen(31)`. It uses:

`campaignOpenState[SUPER] = maxSuperChapter > 0`

and `maxSuperChapter` comes directly from server `super_chapter_id`.

The Function31 guide then points to `menu_1`; when MapWindow begins in Normal, `menu_1` is the Super selector. Therefore the coherent post-unlock lifecycle is:

**server grants Function31 → client forces LOAD_WORLD_MAP → returned Super cursor/projection makes Super mode visible → guide points at Super.**

This is strong evidence that Function31 grant is meant to synchronize with **Super cursor activation**. Otherwise the guide would immediately target a disabled Super selector.

What is not captured is the exact server payload. `src_64` cannot prove byte-for-byte that row `100019` was inserted at the same moment rather than only setting a cursor. However, first-frontier row materialization on the same reload is now a **high-confidence compatibility deduction**, not a blind guess.

### Two gates, not one
The first Super row is `100019`, related to Normal `100001`. Both source rows have `open_lv=1`, while FunctionID31 itself opens at level 11. This alone proves that stage `open_lv` is not the Elite feature authority.

The source therefore supports a two-gate model:

1. **Feature gate:** FunctionID31 / server `func_ids` exposes Elite Campaign.
2. **Per-stage progression gate:** the related Normal anchor must pass `checkNomalCampaignThrough()` before the player can enter a materialized Super node.

So “opens at level 11” and “must clear the related Normal stage” are not competing explanations. They are separate conditions.

## 2. Super is explicitly linear in raw source
Pass125 proved 155 Normal↔Super relations. Pass126 adds another raw invariant: all **155 Super rows form one exact source-authored `last_campaign_id` / `next_campaign_id` chain**.

Audit result:
- 155 Super rows
- 154 forward edges
- zero `next_campaign_id` mismatches
- zero `last_campaign_id` mismatches
- 22 cross-chapter edges
- first Super: `100019` (`last=0`, `next=100020`)
- terminal Super: `2300024` (`next=0`)
- all 155 Super/Normal pairs have identical `open_lv`

The chain crosses chapters directly, e.g. `100024 → 200022 → ...`, and its order exactly matches the concatenated `chapter.lua.super` lists.

This makes the Super mode fundamentally different from Challenge: **Super has an explicit single progression spine**.

## 3. Sequential versus Normal-prerequisite materialization
The key MapWindow ordering is:

1. resolve the real Super id from the Normal plot slot via `relateCampaign()`;
2. render the node;
3. only if that Super row exists in `selfPlayer.worldMaps_`, attach the Campaign click handler;
4. when clicked, for non-Normal modes call `checkNomalCampaignThrough(chapter, normal_anchor)`;
5. only then open the detail window.

That sequence is highly informative. The client explicitly supports a state where a **Super row is already materialized and clickable, yet the related Normal anchor still blocks entry** and produces `NORMAL_MAP_ALERT`.

If official progression always withheld the next Super row until its Normal anchor was already cleared, this Super-specific situation would be largely redundant under valid server state. The raw linear Super chain plus this materialized-row→Normal-gate ordering make the strongest source-consistent deduction:

> **A Super win advances the own-Super frontier to the next raw Super node immediately. The next row may be visible/materialized before its related Normal prerequisite is satisfied. Normal clearance is an independent entry gate, not the trigger that creates the next Super frontier.**

This remains a deduction rather than captured official server behavior, but it is now materially stronger than the competing Normal-driven-projection model.

A wait-for-Normal model would also require Normal MID114 settlement to cross-materialize a Super row. The generic response parser can technically accept that, but `newOpenCampaignId` presentation is oriented around the currently displayed map and does not clearly model a cross-mode unlock. The Function31-specific world-map reload and dedicated Super next-chain are cleaner evidence for an own-frontier lifecycle.

## 4. Cursor semantics — safest source-consistent interpretation
`src_64` still never advances the cursors itself; all values are server-owned. But their consumers now constrain what they mean.

`super_campaign_id` is used by ItemCompose/ElementEquip source UI as a numeric **reached threshold**. `super_chapter_id` is used by MapWindow as `maxSuperChapter`, controls whether the Super selector exists at all, and is reused by item/mission source windows as a reached chapter threshold.

MapWindow also treats a materialized row with `star=0` as the **last/current frontier node**.

The safest logical interpretation to carry into Pass127 design is therefore:

- **`super_campaign_id` = highest materialized/reached Super node in the source chain, including the current unbeaten `star=0` frontier.**
- **`super_chapter_id` = chapter containing that highest reached frontier. `0` means Elite Campaign has not been exposed.**
- The frontier can be temporarily **Normal-blocked**. Cursor reachability and battle playability are not identical.
- Earlier cleared Super rows remain materialized/replayable for daily farming.
- At the terminal Super, the cursor naturally remains on the terminal id after clear because there is no next node.

This fits the Function31 reload, star-0 frontier handling, linear source chain, and per-node Normal gate with the fewest invented rules.

## 5. Frozen backend comparison — no code changed
The current Pass123 backend already follows the raw flat Super order and materializes the next Super row after a successful Super result. That behavior happens to align with the strongest Pass126 deduction.

However, it is incomplete in three important ways already documented in Pass125:

- fresh non-QA state has no Function31/first-Super bootstrap path;
- MID113/MID117 do not independently validate the related Normal anchor;
- Pass75 QA preseed materializes all Super rows, so derived cursors become final Chapter23 and cannot serve as production authorization.

Pass126 changes none of those. They become design inputs for Pass127.

## 6. What remains unrecovered
Three important facts are still outside `src_64`:

1. the exact `LOAD_WORLD_MAP` payload the official server returned at FunctionID31 grant;
2. the exact official server error/result used when a modified client attempted a Super stage whose Normal anchor was uncleared;
3. the official persistence engine/schema and exact transaction implementation.

These unknowns do **not** prevent modular design. The client-visible invariants are now sufficient to design a bounded reconstruction while marking compatibility policy honestly.

## Readiness decision
**Another extrapolation pass is NOT required.** The remaining unknowns are server-internal details that the recovered client source cannot answer. Unless a new official-server capture or additional artifact appears, another source-only pass would likely repeat the same boundary.

**Official next step: Pass127.0 — Modular Design ONLY.** Pass127 should turn the two-gate model and sequential-frontier/cursor deductions into modules, invariants, transaction order, legacy reconciliation rules, and a QA matrix. **Implementation should move to Pass128.0 only after Pass127 design acceptance.**

## Passmap health
Promoted SQLite: `PRAGMA integrity_check = ok`; project tables = **739**. Backend SHA remains `68f7403a605d2e707361e17e8ba7bfdee85986cc00bc614f7cccbb1657590fe9`.
