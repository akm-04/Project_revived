# Pass117.0 Migration Handoff

Canonical backend: `gxb-backend-v0.15.1-pass117.0.zip` SHA-256 `b4d2790be9d34198bd2a62fcfa499060a0cb02c4acab6a24e4c7067a84ffce80`.

Pass117 implements the accepted Pass116 Campaign reconciliation design. Normal/Super first-clear `init_dropbox` uses `campaign_first_clear_bernoulli_v1` at MID113; one `campaign_battle_op_id = mid113-<UUIDv4>` is retained through MID114 and durable stage/result UoW receipts prevent reroll or duplicate settlement. MID113 repeat RNG remains disabled. OTA 1.631.7 is cumulative with 138 overrides and preserves all 132 prior 1.631.6 overrides. Challenge unlock is source-shaped Campaign 24111 in the `LOAD_WORLD_MAP.challenge` array after Normal 1600016 clear, also emitted live by MID114.

Static/fresh-extraction validation is accepted; **client runtime smoke is still pending**. Do not claim runtime acceptance or resume Generated/Unique Instance settlement until smoke reconciliation.
