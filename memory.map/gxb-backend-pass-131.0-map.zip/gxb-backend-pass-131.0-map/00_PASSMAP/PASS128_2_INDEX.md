# Pass128.2 Index — MID112 New-Account Wire Hotfix

- `PASS128_2_TECHNICAL_REPORT.md` — source/root-cause/implementation/validation report.
- `PASS128_2_SRC64_FEEDBACK_LOOP.json` — stock SelfPlayer/MapWindow wire contract.
- `PASS128_2_HOTFIX_IMPLEMENTATION.json` — bounded missing-vs-zero code change.
- `PASS128_2_MID112_WIRE_CONTRACT_SELFTEST.json` — fresh level1/level10 schema tests.
- `PASS128_2_VALIDATION.json` — Pass128 and neighbor regression results.
- `PASS128_2_IMPLEMENTATION_FILE_MANIFEST.json` — VCS-style backend delta.
- `PASS128_2_ROADMAP.json` — runtime smoke gate and halted later roadmap.
- `CURRENT_NEGATIVE_MEMORY_PASS128_2.json` — do-not-regress rules.
- `PASS128_2_LIVE_CHECKPOINT.json` — current continuation authority.
- `evidence/pass128_2_mid112_hotfix/` — source excerpts and dedicated self-test.
- `databases/GAME_KNOWLEDGE_CATALOG_PASS128_2.sqlite` — promoted knowledge catalog.
