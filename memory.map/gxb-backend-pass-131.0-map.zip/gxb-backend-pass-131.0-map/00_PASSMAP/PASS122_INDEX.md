# Pass122 current authority index

- `PASS122_LIVE_CHECKPOINT.json` — current implementation checkpoint and next pass.
- `PASS122_RUNTIME_LOG_REVIEW.json` — Pass121 user debug trace acceptance.
- `PASS122_SRC64_FEEDBACK_LOOP.json` — effective-source hashes and recovered Challenge facts.
- `PASS122_IMPLEMENTATION.json` — bounded code scope and preserved contracts.
- `PASS122_TECHNICAL_REPORT.md` — human-readable technical changelog.
- `PASS122_VALIDATION.json` / `PASS122_REGRESSION_MATRIX.json` — final test evidence.
- `PASS122_COMMIT.json` — version-control message/scope.
- `CURRENT_NEGATIVE_MEMORY_PASS122_0.json` — anti-regression constraints.
- `PASS120_MANUAL_BATTLE_SIMPLIFICATION_DESIGN.json` + `PASS120_OTA_ROLLBACK_MIGRATION.json` — accepted Pass123 design authority.
- `databases/GAME_KNOWLEDGE_CATALOG_PASS122_0.sqlite` — canonical queryable memory.
