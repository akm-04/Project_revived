# Pass128.5 — Client Smoke Reconciliation / Tutorial-State Diagnosis

## Scope
Research/reconciliation only. Backend remains `gxb-backend-v0.15.6-pass128.2.zip` SHA256 `e7f6b8cfdb29e95eef2f764bd2e8f0968d5cf397d483aeff7d340092295fc743` and OTA remains 1.631.8. Runtime evidence: `debug.zip` SHA256 `9c0cc9971d4ed5d0c79c0f4dad9c374682f550aa29da1dfe0754af4ff7a7c0ff`.

## Campaign result — ACCEPTED
The fresh level-1 account received a complete explicit MID112 with numeric zero Super fields (`super_chapter_id`, `super_campaign_id`, `super_stars`, `super_bonus_id` all 0), Campaign opened, and Normal progression advanced through 100001 -> 100002 -> 100004. The Pass128.0 MapWindow nil hardlock did not recur. **Pass128.2 is runtime accepted for the fresh-account Campaign wire contract.**

## Tutorial/vending result — separate issue
The first SAVE_STORY emitted by the newly created server account already carried `guide_id=100109`, the source constant `GUIDE_SUMMON_END`, before any MID50 summon request. Later guide state reached 100262 while Lavia had never been awarded. When the client finally sent the source-shaped small free MID50 `(summon_type=1, summon_index=1)`, the backend returned `error_code=1`.

Fresh `src_64` explains the skip. `StoryData.updateDataFromStorage()` promotes local `storyGuideData` when its story/guide values are greater than the newly hydrated server values. `StoryGuideData` stores a single local SQLite row `id=0`, not a per-player row. `LoadingScene.updateMeta_()` clears local game data only on a player-ID transition where the previous stored playerID is nonzero. Therefore a supposedly new backend account can inherit old guide progress whenever that local row survives identity transition/reset. Restarting the app does not clear this SQLite state.

The exact reason the row survived in this run is not server-log-provable. Player-ID reuse or an identity/meta path that did not trigger `clearGameData()` is the strongest explanation. The backend allocator is normally monotonic while its region counter persists, but destructive server-state resets can restart identity allocation if that counter is also removed. Do not promote that infrastructure explanation to recovered game behavior.

## Why small vending returned error 1
This is a real backend rejection but a **downstream safety consequence**, not evidence that the MID50 type mapping is wrong. `SummonRepository._tutorial_mana()` deliberately refuses a fresh one-shot Lavia grant once `guide_id >= 100105` if Lavia is absent and no committed tutorial receipt/legacy adoption marker authorizes replay. In the corrupted state the client claimed to be past the summon tutorial while the tutorial hero was absent, so fail-closed behavior was triggered.

Do **not** loosen this rule merely to make contaminated clients summon: doing so would make guide-state inconsistency an authorization signal for tutorial rewards.

## Recommended handling
1. Mark Pass128.2 Campaign hotfix runtime accepted and close the Campaign hardlock blocker.
2. Before another tutorial correctness smoke, clear application/game data (not just restart) or guarantee a truly novel client identity.
3. Treat that clean-data summon smoke as a focused confirmation of the client-local diagnosis, **not a blocker for the accepted Campaign architecture-hygiene roadmap**.
4. If private-server QA frequently destroys server state and reuses player IDs, consider a later bounded test-infrastructure identity-hygiene design. Do not alter original-game compatibility semantics casually.
5. Preserve MID50 tutorial fail-closed semantics unless new source/runtime evidence proves a safe recovery contract.

## Roadmap after this reconciliation
- Campaign Pass128 runtime gate: CLOSED / ACCEPTED.
- Next accepted roadmap item: one behavior-neutral architecture-hygiene/strangler-preparation pass (shared Campaign construction, identity invariants, WorldRepository extraction seams; no gameplay changes).
- Then Campaign Player EXP + Mana sweep economy.
- Then RNG backbone closure.
- Then Generated/Unique, Girls/Equipment, and deferred source-bounded verticals.
- Tutorial clean-data confirmation remains a small non-blocking summon QA item unless it reproduces after storage is truly fresh.
