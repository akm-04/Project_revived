# Pass115.0 Migration Handoff

Canonical backend remains **unchanged**: `gxb-backend-v0.15.0-pass114.0.zip` SHA-256 `4876246704d9b00af4839e5a1a2d72988f788b07a471a17253eba1c7daf811a4`. Canonical source remains `all-assest-rechecked.zip` SHA-256 `89f0f830508b92e5fff6ad53c6a9dae961a14042dbfdf5649008efb8353f5608` with effective `app-assets/output/assets/src_64`.

Pass115 is a targeted investigation/memory pass only. The Pass114 MID117 exactly-once/transaction path is working in the supplied debug evidence. Do **not** interpret the Campaign panel's `item_display` as the raw reward whitelist: actual repeat rewards come from `campaign.dropbox -> campaign_dropbox`, and many UI entries are composed/finished representatives of source fragments/components via `item.compose_item`. Runtime-tested Normal 1900019 and Super 1600022 produced zero random rewards outside their configured source pools.

Real unresolved Campaign defects are: (1) MID113 first-clear staging still uses the legacy `increase_rate == 10000` stub, causing empty first-clear rewards on ordinary stages whose init rows are below 10000; the official init-dropbox sampler remains unrecovered and `first_display` is not guaranteed-all authority. (2) Challenge Mode is locked because `LOAD_WORLD_MAP.challenge` is empty; the client gate is presence of Campaign **24111** in `worldMaps_`, even though the dev state has already cleared Chapter 16.

Super Campaign uses the same `campaign.dropbox -> campaign_dropbox.increase_rate` plane with Super-specific pools; no separate Super sampler was recovered. Do not tune Super rates from the four-sweep smoke sample.

Generated/Unique Instance settlement is **paused**. The next pass, only after explicit authorization, should design the Campaign corrective slices. Pass115 itself freezes no correction design and changes no backend behavior.

Mandatory `src_64` Architectural Feedback Loop remains binding. Query the Pass115 SQLite tables and report before cold historical provenance.
