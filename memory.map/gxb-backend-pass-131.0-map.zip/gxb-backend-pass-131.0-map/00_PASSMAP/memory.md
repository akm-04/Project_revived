# Current memory pointer — Pass130.0

Canonical memory is `CURRENT/`. Read `CURRENT/README.md` in its declared startup order, then use `CURRENT/TASK_ROUTING.json` and the single live Pass130 SQLite. Pass129 architecture hygiene is runtime accepted; Pass130 Campaign Player EXP + Mana research and implementation planning are complete. Backend v0.15.7-pass129.0 / OTA 1.631.8 remain unchanged. Historical pass reports remain evidence, not present authority.
