# Pass127.0 Technical Report — Progression Gates Modular Design

## Scope
Pass127 is **MODULAR DESIGN ONLY**. The Python backend remains frozen at `gxb-backend-v0.15.4-pass123.0.zip` SHA-256 `68f7403a605d2e707361e17e8ba7bfdee85986cc00bc614f7cccbb1657590fe9` and OTA remains **1.631.8**. No backend or OTA bytes changed.

Effective source feedback was repeated against `app-assets/output/assets/src_64` before locking this blueprint. Pass126's source model remains intact: Function31 is the level-11 Elite feature gate; Super has a source-authored 155-node linear frontier; every Super node maps by `relate_campaign_id` to one Normal anchor; a materialized Super node can still be blocked by `checkNomalCampaignThrough()`.

## Design decision
Use four bounded responsibilities:

1. **SuperCampaignCatalog** — source-only relation/chain/chapter/daily-limit facts.
2. **SuperCampaignAccessPolicy** — pure read-only server bouncer.
3. **SuperCampaignProjectionService** — world_map row materialization and derived Super cursor/frontier projection.
4. **EliteCampaignUnlockCoordinator** — the only cross-domain bridge between Function31 eligibility/announcement and Super bootstrap.

`world_map` stage rows remain the durable player progression authority. `chapter_info.super_*` remains a derived/cache projection for client navigation and visibility.

## Function31 level-11 bootstrap
Fresh canonical level crossing follows one atomic lifecycle:

`level>=11` → Function31 **eligible/pending** → insert first Super `100019` (`star=0`, source `daily_limit=3`) → derive `super_campaign_id=100019`, `super_chapter_id=1` → announce Function31 / stage `new_funcs_=31` → commit.

The ordering is deliberate. `SelfPlayer.onNewFuncOpen(31)` immediately invalidates/reloads world-map state and the guide points at the Super selector. Announcing first and projecting later would create a client-visible half-open state.

FunctionStateRepository should stay generic: its Function31 policy becomes a domain-readiness pending policy rather than directly mutating Campaign state. PlayerProgressionService should expose a narrow post-level-transition callback; the coordinator uses it without introducing a PlayerProgression→WorldRepository dependency.

### Legacy cases
- Function31 already announced but Super rows empty: LOAD_WORLD_MAP projection self-heals `100019` and cursors; no duplicate `new_funcs_`.
- Historical credential player already level>=11 but Function31 remained unannounced because of our old unresolved policy: one-time login/bootstrap migration marks it eligible+announced and ensures the first frontier, without forcing a retroactive mid-session guide popup.
- Function31 not announced and level<11: production Super cursors remain zero.
- Pass75 sandbox is preserved unchanged.

## Server-side bouncer
For every **new** Super MID113 staging request and every **new UUID** Super MID117 operation, the server validates:

source Super membership → Function31 announced → exact Super row materialized → source `relate_campaign_id` resolves → related Normal row exists with `star>0` → operation-specific attempts/cost/RNG checks.

The policy is mutation-free. It returns a structured decision; protocol adapters render the error.

The safe compatibility fallback is **`error_code=1`**, with an internal message such as `campaign_normal_prerequisite_locked`. The exact original server code is not recovered. We explicitly **do not use 30005**: `src_64` assigns that to `errorIdFightExist`/result-compatible handling, and the project permanently forbids generalizing that semantic.

### MID113 ordering
Pass123 sticky same-stage `STAGED` replay stays first. A previously authorized battle remains replayable with zero RNG. For a new stage, the bouncer runs before daily attempts, energy, drop planning/RNG, or active-session replacement. Denial creates no session and mutates nothing.

### MID117 ordering
Pass121 committed UUID receipt replay remains first. After static identity/source checks, the bouncer runs inside the existing UoW **before** attempt preflight, cost validation, entropy, reward mutation, attempt decrement and receipt staging. A denied new UUID creates no receipt.

## Sequential Super projection
Canonical Super victory continues to materialize the raw `next_campaign_id` immediately as an unbeaten star-0 frontier, even if that next Super node's Normal anchor is not yet cleared. The Normal prerequisite gates **entry**, not visibility.

Cursors are derived from the highest source-order materialized Super row when Function31 is open. At terminal `2300024`, no phantom row is created.

## QA decoupling
Pass75 remains a PRIVATE_SERVER_POLICY test seed. It may continue materializing all 155 Super rows. There is **no sandbox bypass** in the bouncer.

The default sandbox already seeds every Normal row with `star>=1`, so it naturally passes. To prove decoupling, Pass128 tests must use a low-progress fixture or a clone where one chosen Normal anchor is `star=0` while its Super row remains materialized. Both MID113 and MID117 must still block.

## Implementation boundary
Pass128 may add the four modules/wiring above and refactor only the Super progression/gating paths. It must preserve MID50/MID117 UUID bridges, Pass121 MID117 receipt/decrement order, Pass122 Challenge, Pass123 `active_campaign_battle`, OTA1.631.8, and `disabled_unknown` repeat RNG policy.

## Readiness
The blueprint is mature enough for full implementation. No additional design/extrapolation pass is required unless new source/runtime evidence contradicts these invariants.
