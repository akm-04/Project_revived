# Pass128.1 Emergency Research — New Account Campaign Hardlock

## Executive conclusion
Pass129 is aborted. Pass128.0 is **runtime rejected** for new/Function31-closed accounts. The four-module progression design is not disproven. The hardlock is a precise wire-schema regression in the Pass128 cursor projection implementation.

## Runtime evidence
`debug.zip` SHA-256 `54de8945596c1cc9702cb3cdb691ea9319c3c831f1c7bf0ab78c6b50a1a943e1` contains two client errors with `MapWindow.lua:174: attempt to compare number with nil`. The failing explicit MID112 response is:

`chapter_info = {normal_chapter_id=1, normal_campaign_id=100001, normal_stars=0, normal_bonus_id=0, super_bonus_id=0}`

It omits `super_chapter_id`, `super_campaign_id`, and `super_stars`. The same account's login/bootstrap embedded MID112 had all three fields set to numeric zero. Thus login hydration is safe, then explicit `LOAD_WORLD_MAP` overwrites `SelfPlayer.super_chapter_id` with nil and MapWindow crashes when it evaluates `maxSuperChapter > 0`.

A progressed Function31-open account in the same log receives the complete Super cursor shape and does not hit this failure.

## `src_64` contract
`SelfPlayer.worldMapEvent_()` directly assigns all eight `chapter_info` fields with no nil defaults. `MapWindow.layout()` copies `selfPlayer.super_chapter_id` to `maxSuperChapter`; `updateChapterTypeBtnShowInfo()` performs `maxSuperChapter > 0`. Therefore zero-valued Super cursor fields are mandatory wire fields when Elite Campaign is closed.

## Exact regression mechanism
Pass123 `WorldRepository.normalize()` always materialized `super_chapter_id`, `super_campaign_id`, and `super_stars`, including zero. Pass128 intentionally delegated those fields to `SuperCampaignProjectionService.recompute_cursors()`.

That service currently checks whether `int(existing-or-missing, 0) != desired`. When the key is absent and desired is `0`, the comparison says "no change" and never inserts the key. This affects the exact state we care about for fresh accounts: Function31 closed -> frontier 0 -> chapter 0 -> stars 0.

Bootstrap does not expose the bug because `PlayerState.world_map_payload()` independently overlays a complete default chapter schema. Explicit MID112 uses `WorldRepository.payload()` and therefore exposes the raw missing keys.

## Design verdict
**Retain the Pass126/127 progression architecture.** Sequential Super visibility, Function31 level-11 coordination, related-Normal authorization, QA separation, and MID113/MID117 ordering are not contradicted by the runtime failure.

One design invariant was under-specified: the projection owner must own **wire-schema completeness**, not only numeric cursor meaning. In Lua protocol terms, missing and zero are observably different.

## Next pass — Pass128.2 hotfix boundary
The bounded fix should make `SuperCampaignProjectionService.recompute_cursors()` write a field when the field is absent **or** its normalized value differs. That restores complete zero-valued Super cursor state while keeping one owner for Super cursor semantics.

Do not redesign Function31, do not weaken the Normal bouncer, do not touch OTA, and do not advance the roadmap.

Mandatory new regression cases: fresh level1 MID112, level10 Function31-closed MID112, bootstrap/explicit-MID112 schema parity, one-time missing-zero persistence heal, then the complete Pass128 and Campaign/reset neighbor suites.

After Pass128.2, a real fresh-account client smoke is mandatory before the issue is considered closed.
