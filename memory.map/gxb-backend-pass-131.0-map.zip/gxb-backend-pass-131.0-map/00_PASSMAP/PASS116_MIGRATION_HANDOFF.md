# Pass116.0 Migration Handoff

Backend remains frozen at `gxb-backend-v0.15.0-pass114.0.zip` SHA-256 `4876246704d9b00af4839e5a1a2d72988f788b07a471a17253eba1c7daf811a4`.

Pass116 is design-only and freezes three authorities:

1. `campaign_first_clear_bernoulli_v1`: independent per-source-row 10,000-scale Bernoulli for Normal/Super `init_dropbox`; official sampler still unrecovered.
2. `campaign_battle_op_id = mid113-<UUIDv4>` spanning MID113 staging and MID114 settlement with permanent stage/result UoW receipts; MID114 never rerolls.
3. Challenge unlock is source-shaped Campaign `24111` in the `LOAD_WORLD_MAP.challenge` list after canonical Normal `1600016` clear; do not fabricate the rest of Challenge.

Read `PASS116_CAMPAIGN_RECONCILIATION_DESIGN.md`, the three design JSON files, `CURRENT_NEGATIVE_MEMORY_PASS116.json`, HOT authority, then query `GAME_KNOWLEDGE_CATALOG_PASS116_0.sqlite`.

Do not implement or resume Generated/Unique Instances unless the user explicitly authorizes the next pass.
