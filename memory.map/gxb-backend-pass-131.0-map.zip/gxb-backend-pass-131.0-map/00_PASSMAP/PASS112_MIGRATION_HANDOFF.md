# Pass112.0 Migration Handoff — Campaign MID117 Audit & Design

Canonical backend remains **unchanged**: `gxb-backend-v0.14.1-pass111.0.zip` SHA-256 `2af196494a344ac5a4a6f968cc5ac9885bff48ec5aa01fb31e375ec86485e9cb`. Canonical source remains `all-assest-rechecked.zip` SHA-256 `89f0f830508b92e5fff6ad53c6a9dae961a14042dbfdf5649008efb8353f5608` with effective `app-assets/output/assets/src_64` (4,370 files).

Pass111 is now **runtime accepted**. User tested SX, Medium, Small and Gachapon pulls, force-closed during a Medium 10x and confirmed exactly one Crystal spend with rewards persisted, and tested a non-VIP account. `debug.zip` SHA-256 `ab47cb386a765e975283b6e83c82cb973d54af0883bd16a36cba4451e2e4c58c` shows OTA 1.631.5 current and 16 captured MID50 requests all carrying `summon_op_id` through the real handler with no captured MID50 server failure.

Pass112 made no Python/OTA changes. It closed the **MID117 stackable repeat-item design**. Official server RNG code remains unrecovered. The frozen implementation policy is explicitly private-server compatibility policy `campaign_repeat_rate_decomposition_v1`: per source row `q,r=divmod(increase_rate,10000)`, grant q units, and when r>0 use one `RandomOutcomeService.randbelow("campaign.repeat.residual",10000)` draw for one extra unit if draw<r. Do not use weighted_index.

Why: every populated referenced repeat pool sums above 10,000; individual rows reach 360,000; there is no quantity column; SweepWindow accepts zero/many stack rows. This is source-bounded reconstruction, not a claim about original official-server code.

Missing pool rule: `repeat_dropbox_id=0` is valid deterministic-only. A positive repeat pool with no rows is a hard pre-mutation failure. Exactly 24 such source references exist, concentrated in Normal chapters 22/23. Never substitute adjacent pools.

Future MID117 identity is frozen as `campaign_sweep_op_id=mid117-<UUIDv4>` at `SweepWindow::willOpen`, injected **only when actual MID is SWEEP_CAMPAIGN**, never for event sweep MIDs. Fingerprint: MID117 + campaign_id + campaign_type + sweep_num + sweep_type + awake_mission-or-0. Receipt domain `mid117_campaign_sweep`, permanent CLIENT_UUID_V4. Static replay preserves exact per-sweep `items`, per-sweep `economys`, `additional`, optional chapter_event; live projection re-renders cumulative `economy_`, campaign/trial/challenge state.

Keep `economys={exp:0,mana:0}` and `additional=[]` during repeat-item RNG implementation unless a separate source-reconciliation pass closes those persistence semantics. Do not widen Pass113/114 into progression or awaken-drop behavior.

Next split:
1. **Pass113 Phase C1 inert foundation** — implement versioned Campaign repeat policy, ROS adapter, scripted tests, and MID117 identity/receipt helpers. No live MID117 RNG and no OTA activation.
2. **Pass114 Phase C2 activation** — cumulative OTA identity bridge, WorldRepository UoW replay/settlement, missing-pool hard fail, runtime smoke.

Commit: `Pass112.0: promote Pass111 runtime acceptance and freeze source-bounded MID117 repeat-item RNG, missing-pool, UUID, and UoW replay design with backend unchanged`
