# Historical routing stub

This unversioned file previously contained a **Pass62 architecture snapshot** and could be mistaken for current authority. The original is preserved verbatim at `99_ARCHIVE/pass128_3_stale_canonical_like/00_PASSMAP/BACKEND_ARCHITECTURAL_INVARIANTS.md`.

Current replacement: `00_PASSMAP/CURRENT/CURRENT_INVARIANTS.json`.
