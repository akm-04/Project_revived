# Current Database Guide — Pass131.0

Use exactly one live knowledge DB: `00_PASSMAP/databases/GAME_KNOWLEDGE_CATALOG_PASS131_0.sqlite` (SHA256 `8ba19e436212e7acaaf20efb6b1aa15f26ab34eb627169da4822033784d5ddba`). Historical catalogs are cold-storage provenance only: Pass116–128.4 remain in the existing tar.zst; exact Pass128.5, Pass129.0 and Pass130.0 are separately preserved. Historical catalog count: **21**. Follow `CURRENT/TASK_ROUTING.json`; do not recover/query all historical databases during startup.

Health: `integrity_check=ok`, `quick_check=ok`, 0 foreign-key violations, 860 project tables, one live SQLite, no WAL/SHM sidecars.
