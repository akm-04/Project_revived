# Pass120.1 migration handoff

This is a **migration-only checkpoint**. Backend and OTA are unchanged from Pass117. Pass120 architecture was explicitly accepted by the user and is ready for bounded implementation **only after the user's second message in the new chat**.

Canonical uploads for the new chat:
1. `gxb-backend-pass-120.1-map.zip` — current machine memory.
2. `gxb-backend-v0.15.1-pass117.0.zip` — backend, SHA-256 `b4d2790be9d34198bd2a62fcfa499060a0cb02c4acab6a24e4c7067a84ffce80`.
3. `all-assest-rechecked.zip` — canonical source/assets, SHA-256 `89f0f830508b92e5fff6ad53c6a9dae961a14042dbfdf5649008efb8353f5608`; effective source `app-assets/output/assets/src_64`.

First-turn rule in new chat: verify/reorient only. Read `READ_FIRST.md`, HOT, Pass120.1 checkpoint/handoff, then Pass120 frozen designs. Do **not** implement, modify, or regenerate artifacts. Confirm the accepted roadmap and wait for the user's second prompt.

Accepted Pass120 structural design:
- Super MID117: keep existing UUID/UoW, preflight `sweep_num <= daily_limit` before entropy/cost, decrement exactly `sweep_num` in the same atomic transaction.
- Challenge: dedicated raw 144-row/137-edge source topology catalog/projector; deterministic first-clear quantity `increase_rate // 10000`; project all graph children; no Challenge sweep plane.
- Manual MID113/MID114: simplify back to server-owned `active_campaign_battle` v2; retire cross-request `campaign_battle_op_id` and new MID113/MID114 permanent receipts; future OTA 1.631.8 explicitly restores six Pass117 Campaign battle files while preserving MID50/MID117 UUID patches.

Implementation sequence accepted:
1. Super MID117 daily-limit exploit fix.
2. Challenge graph/progression/deterministic rewards.
3. Manual battle simplification + OTA 1.631.8 rollback.
4. Client smoke/debug and source-bounded fixes.
5. Campaign Player EXP + Mana sweep economy reconciliation.
6. RNG Backbone final closure/reality check and remaining prioritized core RNG integrations.
7. Generated/Unique Instance settlement.
8. Girls/Equipment economy closure.
9. Resume deferred vertical slices (Store, Battle Pass, Arena, Pet, Guild, March, World Boss, Task/Sign, Monthly Privilege, etc.).

Project rule remains mandatory: source/research → decide → bounded implementation → static/self-test → client smoke → reconciliation → next subsystem. Never fabricate missing official-server behavior.
