# Agent Database Guide — Pass121.0

Current evidence bank: `00_PASSMAP/databases/GAME_KNOWLEDGE_CATALOG_PASS121_0.sqlite` (`PRAGMA integrity_check = ok`, 689 project tables). Query `pass121_*` first for the current implementation checkpoint. Pass120 design tables remain the accepted architecture authority for Pass122/Pass123; older tables are provenance.
