Read `00_PASSMAP/READ_FIRST.md` first. Backend is frozen v0.15.4-pass123.0 and OTA1.631.8. Pass126 completed source-only progression extrapolation: Function31 forces world-map reload and Super UI visibility is super_chapter_id>0; all 155 Super rows form an exact linear next/last chain; strongest source-consistent model is sequential Super frontier plus independent related-Normal entry gate; cursor is highest materialized frontier/chapter. No more extrapolation is required. NEXT = Pass127 MODULAR DESIGN ONLY; Pass128 implementation after acceptance.


## Pass127 handoff
Use `00_PASSMAP/READ_FIRST.md` and Pass127 current authority. Backend is still Pass123. Pass128 is implementation-only after user acceptance of the locked four-module Super progression design.


## Pass128 handoff
Use `00_PASSMAP/READ_FIRST.md` and Pass128 current authority. Backend is v0.15.5-pass128.0. Next is Pass129 client smoke/debug reconciliation; do not redesign progression gates absent new source/runtime contradiction.

## Pass128.1 emergency handoff
Pass128 runtime is REJECTED. Read `00_PASSMAP/READ_FIRST.md`. Do not start Pass129/EXP-Mana/RNG. Next is Pass128.2 only: fix missing zero-valued Super chapter_info keys on explicit MID112, preserve Pass127 progression architecture, then require fresh-account client smoke.

## Pass128.2 handoff
Canonical backend v0.15.6-pass128.2 hotfix is packaged/static-accepted. Read `00_PASSMAP/READ_FIRST.md`. Do not resume Pass129/EXP-Mana/RNG. Next is mandatory fresh/new-account Campaign smoke. If it passes, runtime-accept Pass128; if it fails, remain in bounded 128.x reconciliation.
