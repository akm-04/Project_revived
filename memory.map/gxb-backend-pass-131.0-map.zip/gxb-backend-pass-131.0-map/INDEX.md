## CURRENT PASS131.0 ROUTING

Current authority: `00_PASSMAP/CURRENT/README.md`; live DB: `00_PASSMAP/databases/GAME_KNOWLEDGE_CATALOG_PASS131_0.sqlite`. Backend v0.15.8-pass131.0 is static/regression accepted, client smoke pending. Historical indices below are provenance.

# Passmap root index

Start with `00_PASSMAP/CURRENT/README.md`. Pass-specific indexes live under `00_PASSMAP/`. Duplicate root copies were removed in Pass128.3 because they were byte-identical retrieval noise.
