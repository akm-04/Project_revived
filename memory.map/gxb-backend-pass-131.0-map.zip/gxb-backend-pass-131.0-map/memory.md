# CURRENT PASS131.0 CHECKPOINT

- Backend: gxb-backend-v0.15.8-pass131.0.zip SHA256 64bf1a40f409a9ad0812bf9a1c4284808f6a2d986ae00461fa9fb3531a87e4c7
- Status: Campaign MID117 Player EXP + Mana implemented; static/regression accepted; real-client smoke pending.
- Source: all-assest-rechecked.zip SHA256 89f0f830508b92e5fff6ad53c6a9dae961a14042dbfdf5649008efb8353f5608; effective src_64 app-assets/output/assets/src_64.
- OTA: 1.631.8 unchanged.
- Next: client reconciliation, then Pass108 RNG backbone closure.
- Use 00_PASSMAP/CURRENT + sole live Pass131 SQLite; historical narratives/cold DBs are provenance.

---

# Current memory redirect

Use `00_PASSMAP/CURRENT/README.md`.
