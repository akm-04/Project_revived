# Pass118.0 Index

See `00_PASSMAP/READ_FIRST.md`, current HOT authority, `PASS118_TECHNICAL_REPORT.md`, and `GAME_KNOWLEDGE_CATALOG_PASS118_0.sqlite`. Pass118 is a targeted runtime/source audit; backend remains frozen at v0.15.1-pass117.0.
