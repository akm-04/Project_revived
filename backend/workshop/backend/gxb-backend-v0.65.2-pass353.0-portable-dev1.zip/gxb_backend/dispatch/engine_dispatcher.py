"""MID dispatcher for the engine/game HTTP surface."""

from __future__ import annotations

import json
from collections.abc import Callable
from typing import Any

from gxb_backend.config import Settings
from gxb_backend.auth.perimeter import AuthScopeRegistry, LegacyAuthPerimeter
from gxb_backend.foundation.observability import redact
from gxb_backend.identity.errors import IdentityError
from gxb_backend.handlers.activities import ActivityHandlers
from gxb_backend.handlers.achievement import AchievementHandlers
from gxb_backend.handlers.arena import ArenaHandlers
from gxb_backend.handlers.bootstrap import BootstrapHandlers
from gxb_backend.handlers.battle import BattleHandlers
from gxb_backend.handlers.center import CenterHandlers
from gxb_backend.handlers.chat import ChatHandlers
from gxb_backend.handlers.compatibility import CompatibilityHandlers
from gxb_backend.handlers.context import HandlerContext
from gxb_backend.handlers.deferred_status import DeferredStatusHandlers
from gxb_backend.handlers.message_push import MessagePushHandlers
from gxb_backend.handlers.courses import CourseHandlers
from gxb_backend.handlers.workshop import WorkshopHandlers
from gxb_backend.handlers.guild import GuildHandlers
from gxb_backend.handlers.gods_trial import GodsTrialHandlers
from gxb_backend.handlers.heroes import HeroHandlers
from gxb_backend.handlers.horcrux import HorcruxHandlers
from gxb_backend.handlers.illusion import IllusionHandlers
from gxb_backend.handlers.inventory import InventoryHandlers
from gxb_backend.handlers.library import LibraryHandlers
from gxb_backend.handlers.mail import MailHandlers
from gxb_backend.handlers.occult import OccultHandlers
from gxb_backend.handlers.player import PlayerHandlers
from gxb_backend.handlers.practice import PracticeHandlers
from gxb_backend.handlers.rewards import RewardHandlers
from gxb_backend.handlers.shop import ShopHandlers
from gxb_backend.handlers.social import SocialHandlers
from gxb_backend.handlers.summon import SummonHandlers
from gxb_backend.handlers.system import SystemHandlers
from gxb_backend.handlers.tasks import TaskHandlers
from gxb_backend.handlers.world import WorldHandlers
from gxb_backend.observability.resource_gateway import ResourceGateway
from gxb_backend.observability.runtime_logger import RuntimeLogger
from gxb_backend.protocol.mids import MID
from gxb_backend.protocol.registry import ProtocolRegistry
from gxb_backend.protocol.mutation_contracts import MutationContractRegistry, MutationSafetyFirewall
from gxb_backend.protocol.routing import RouteClass, classify_mid
from gxb_backend.state.repository import StateRepository
from gxb_backend.state.projection_profiles import ProjectionProfileRegistry
from gxb_backend.state.resource_registry import ResourceRegistry
from gxb_backend.state.response_projector import ResponseProjector
from gxb_backend.state.daily_reset import merge_daily_reset_projection
from gxb_backend.synchronization import DeferredStatusMutationFenceValidator
from gxb_backend.transport.result import EngineTransportResult
from gxb_backend.transport.responses import engine_ok
from gxb_backend.transactions.errors import (
    ReceiptReplayConflict,
    StateVersionConflict,
    TransactionRetryExhausted,
    is_retryable_transaction_error,
)

Handler = Callable[[dict[str, Any]], Any]


class EngineDispatcher:
    CENTER_DISCOVERY_MID = 20480
    VERSION_CHECK_MID = 2

    def __init__(
        self,
        state: StateRepository,
        settings: Settings,
        resource_gateway: ResourceGateway | None = None,
        post_commit_sink: Callable[[str, tuple[object, ...]], None] | None = None,
        realtime_runtime: object | None = None,
    ) -> None:
        self.state = state
        self.settings = settings
        # App-scoped transient runtime injection follows the frozen R5/R6
        # composition. Wave E consumes only its room-directory/post-commit seams.
        self.realtime_runtime = realtime_runtime
        # Post-commit sink is always invoked after the repository request scope has
        # exited. Wave E binds the realtime.transient topic through the typed runtime.
        self._post_commit_sink = post_commit_sink
        ctx = HandlerContext(state=state, settings=settings, resource_gateway=resource_gateway)

        self.center = CenterHandlers(ctx)
        self.system = SystemHandlers(ctx)
        self.bootstrap = BootstrapHandlers(ctx)
        self.battle = BattleHandlers(ctx)
        self.practice = PracticeHandlers(ctx)
        self.deferred_status = DeferredStatusHandlers(ctx)
        self.message_push = MessagePushHandlers(ctx)
        self.player = PlayerHandlers(ctx)
        self.heroes = HeroHandlers(ctx)
        self.horcrux = HorcruxHandlers(ctx)
        self.inventory = InventoryHandlers(ctx)
        self.library = LibraryHandlers(ctx)
        room_directory = getattr(self.realtime_runtime, "room_directory", None)
        self.chat = ChatHandlers(ctx, room_directory=room_directory)
        self.summon = SummonHandlers(ctx)
        self.illusion = IllusionHandlers(ctx)
        self.social = SocialHandlers(ctx)
        self.guild = GuildHandlers(ctx)
        self.gods_trial = GodsTrialHandlers(ctx)
        self.activities = ActivityHandlers(ctx)
        self.achievement = AchievementHandlers(ctx)
        self.arena = ArenaHandlers(ctx)
        self.tasks = TaskHandlers(ctx)
        self.mail = MailHandlers(ctx)
        self.occult = OccultHandlers(ctx)
        self.shop = ShopHandlers(ctx)
        self.world = WorldHandlers(ctx)
        self.rewards = RewardHandlers(ctx)
        self.courses = CourseHandlers(ctx)
        self.workshop = WorkshopHandlers(ctx)
        self.protocol_registry = ProtocolRegistry.load(settings.protocol_registry_path)
        self.resource_registry = ResourceRegistry.load(settings.resource_registry_path)
        try:
            self.projection_profiles = ProjectionProfileRegistry.load(
                settings.projection_profile_registry_path
            )
        except Exception as exc:
            # Projection metadata should not make an otherwise-compatible EOL
            # backend unbootable. The fallback adds only the proven optional
            # global envelope and never synthesizes STACK awards.
            print(
                f"[PROJECTION] registry unavailable at "
                f"{settings.projection_profile_registry_path}: {exc}; "
                "using safe global-envelope fallback"
            )
            self.projection_profiles = ProjectionProfileRegistry.safe_default()
        self.compat = CompatibilityHandlers(settings, self.protocol_registry.label)
        self.runtime_logger = RuntimeLogger(settings)
        self.auth_scope_registry = AuthScopeRegistry()
        self.auth_perimeter = LegacyAuthPerimeter()

        self.handlers: dict[int, Handler] = self._build_handlers()
        self.mutation_contracts = MutationContractRegistry.load(settings.mutation_contract_registry_path)
        self.mutation_firewall = MutationSafetyFirewall(self.mutation_contracts)
        self.mutation_firewall.validate_routes(self.handlers, self.protocol_registry.label)
        DeferredStatusMutationFenceValidator.validate(
            self.state.synchronization_catalogs, handlers=self.handlers,
            mutation_contracts=self.mutation_contracts,
            safe_fallback_check=self.compat.is_safe_fallback_mid,
            label_lookup=self.protocol_registry.label,
        )
        self.scalar_handlers: set[int] = {getattr(MID, "GET_PLAYER_GROUP_BY_KEY", -999999), getattr(MID, "HUNQI_GET_COLLOCATION_INFOS", -999998)}

    @staticmethod
    def _put(h: dict[int, Handler], name: str, handler: Handler) -> None:
        mid = getattr(MID, name, -1)
        if isinstance(mid, int) and mid != -1:
            h[mid] = handler

    def _build_handlers(self) -> dict[int, Handler]:
        h: dict[int, Handler] = {
            self.CENTER_DISCOVERY_MID: self.center.center_discovery,
            self.VERSION_CHECK_MID: self.center.version_check,
            MID.RETRIEVE_TOKEN: self.bootstrap.retrieve_token,
            MID.QUERY_SERVER_TIME: self.system.query_server_time,
            MID.LOAD_USER_REGIONS: self.system.load_user_regions,
            MID.LOAD_ANNOUNCE: self.system.load_announce,
            getattr(MID, "GET_PLAYER_GROUP_BY_KEY", -1): self.system.get_player_group_by_key,
            MID.LOAD_PLAYER_INFO: self.player.load_player_info,
            MID.SAVE_STORY: self.player.save_story,
            MID.LOAD_HEROS: self.heroes.load_heros,
            MID.SKIN_ON: self.heroes.skin_on,
            MID.SKIN_CANCEL: self.heroes.skin_cancel,
            MID.USE_ILLUSION_SKIN_ITEM: self.heroes.use_illusion_skin_item,
            MID.LOAD_BACKPACK: self.inventory.load_backpack,
            MID.LOAD_WORLD_MAP: self.world.load_world_map,
            MID.LOAD_TRIAL_INFOS: self.world.load_trial_infos,
            MID.LOAD_SUMMON_INFO: self.summon.load_summon_info,
            MID.LOAD_FRIENDS: self.social.load_friends,
            MID.ACTIVITIES: self.activities.activities,
            MID.LOAD_ARENA_FIGHT_RECORDS: self.arena.load_arena_fight_records,
        }

        # Boot / first lobby / early runtime.
        direct = {
            "GET_LIBRARY_INFOS": self.library.get_library_infos,
            "SET_BG": self.library.set_bg,
            "ALBUM_SPECIAL_COLLECT_INFO": self.album_special_collect_info,
            "ALBUM_SPECIAL_COLLECT_REWARD": self.album_special_collect_reward,
            "ALBUM_PARTNER_UNLOCK": self.album_partner_unlock,
            "LOAD_CHAT_ROOM_INFO": self.chat.load_chat_room_info,
            "ILLUSION_LOAD_INFO": self.illusion.load_info,
            "GET_SELF_GUILD": self.guild.get_self_guild,
            "PETS_GET": self.heroes.load_pets,
            "PET_CAMPAIGN_RED_POINT": self.pet_campaign_red_point,
            "TREASURE_LOAD_INFO": self.deferred_status.treasure_info,
            "GUILD_WAR_RED_POINT": self.deferred_status.guild_war_red_point,
            "MESSAGE_PUSH_ADD": self.message_push.add,
            "MESSAGE_PUSH_REMOVE": self.message_push.remove,
            "CHECK_GAME_STAT": self.system.check_game_stat,
            "FIRST_MAIN_TOUCH": self.player.first_main_touch,
            "SET_PLAYER_GUIDE_FUNCTION": self.player.set_player_guide_function,
            "SET_PLAYER_RETURN_ID": self.player.set_player_return_id,
            "GET_PIC_NOTICE_INFO": self.system.get_pic_notice_info,
            "QUERY_CHARGE_DATA": self.system.query_charge_data,
            "GET_VIP_AWARD": self.system.get_vip_award,
            "ADD_ENERGY": self.system.add_energy,
            "GET_BOARD_INFO": self.activities.get_board_info,
            "LOAD_ACHIEVEMENT_INFO": self.achievement.load_achievement_info,
            "GET_ACHIEVEMENT_AWARD": self.achievement.get_achievement_award,
            "LOAD_SINGLE_ACTIVITY": self.activities.load_single_activity,
            "GET_ACTIVITY_REWARD": self.activities.get_activity_reward,
            "LOAD_SIGN_INFO": self.activities.load_sign_info,
            "SIGN": self.activities.sign,
            "DAILY_CONSUNME_LOAD": self.activities.daily_consume_load,
            "DAILY_CONSUNME": self.activities.daily_consume,
            "PEAK_RECORDS": self.arena.peak_records,
            "TASK_LOAD_BY_TYPE": self.tasks.task_load_by_type,
            "TAKE_MISSION_AWARD": self.tasks.take_mission_award,
            "AWAKE_MISSION_LIST": self.tasks.awake_mission_list,
            "RED_POINT": self.red_point,
        }
        for name, handler in direct.items():
            self._put(h, name, handler)

        # Stage 2 common lobby windows / panels.
        extra = {
            "LOAD_MAIL_LIST": self.mail.load_mail_list,
            "SET_MAIL_READ": self.mail.set_mail_read,
            "MAIL_ONEKEY": self.mail.mail_onekey,
            "LOAD_SHOP": self.shop.load_shop,
            "LOAD_SHOP_LIST": self.shop.load_shop_list,
            "BUY_SHOP": self.shop.buy_shop,
            "REFRESH_SHOP": self.shop.refresh_shop,
            "CLOSE_SHOP": self.shop.close_shop,
            "MARKET_BUY": self.shop.market_buy,
            "LOAD_RUNE": self.inventory.load_rune,
            "LOAD_SCROLLS": self.inventory.load_scrolls,
            "LOAD_ESSENCES": self.inventory.load_essences,
            "SELL_ITEM": self.inventory.sell_item,
            "SELL_ITEMS": self.inventory.sell_items,
            "EXCHAGE_CODE_HERO": self.inventory.open_gift,
            "COMPOSE_ITEM": self.inventory.compose_item,
            "USE_MAGIC_ITEMS": self.inventory.use_magic_items,
            "USE_ENERGY_ITEM": self.inventory.use_energy_item,
            "USE_SKILL_POINT_ITEM": self.inventory.use_skill_point_item,
            "USE_EXP_ITEM": self.inventory.use_exp_item,
            "USE_EXP_ITEMS": self.inventory.use_exp_items,
            "BACKPACK_SORT_TYPE": self.inventory.sort_type,
            "SAVA_SORT_TYPE": self.heroes.save_sort_type,
            "LOAD_HERO": self.heroes.load_hero,
            "LOAD_COLLECTED_HEROS": self.heroes.load_collected_heros,
            "LOAD_HERO_PIECES": self.heroes.load_hero_pieces,
            "SAVE_TEAM": self.heroes.save_team,
            "SET_BOARD_HERO": self.heroes.set_board_hero,
            "BUY_SKILL_POINT": self.heroes.buy_skill_point,
            "SET_SKILL_LEVEL": self.heroes.set_skill_level,
            "SET_ALL_SKILL_LEVEL": self.heroes.set_all_skill_level,
            "CHANGE_PARTNER_SKILL": self.heroes.change_partner_skill,
            "SET_HERO_EQUIP": self.heroes.set_hero_equip,
            "ONE_CLICK_EQUIP": self.heroes.one_click_equip,
            "ONE_CLICK_JINJIE": self.heroes.one_click_promote,
            "POWERUP_HERO": self.heroes.powerup_hero,
            "EVOLVE_HERO": self.heroes.evolve_hero,
            "UPGRADE_SUPER_EQUIP": self.heroes.upgrade_super_equip,
            "FUMO": self.heroes.fumo,
            "ELEMENT_EQUIP": self.heroes.element_equip,
            "ELEMENT_LEV_UP": self.heroes.element_strengthen,
            "ELEMENT_UNLOAD": self.heroes.element_unload,
            "ELEMENT_DESTORY_ON_PARTNER": self.heroes.element_destroy_on_hero,
            "ELEMENT_DESTORY_IN_BACKPACK": self.heroes.element_destroy_backpack,
            "INSCRIPTION_INSERT": self.heroes.inscription_insert,
            "INSCRIPTION_REMOVE": self.heroes.inscription_remove,
            "BREACH_STONE_ADD": self.heroes.breach_stone_add,
            "BREACH_STONE_EVOLVE": self.heroes.breach_stone_evolve,
            "INSCRIPTION_MAKE": self.heroes.inscription_make,
            "INSCRIPTION_REBUILD": self.heroes.inscription_rebuild,
            "INSCRIPTION_RESOLVE": self.heroes.inscription_resolve,
            "EXCHANGE_MATERIALS": self.heroes.inscription_exchange_materials,
            "INSCRIPTION_SAVE_REBUILD": self.heroes.inscription_save_rebuild,
            "INSCRIPTION_ABANDON_REBUILD": self.heroes.inscription_abandon_rebuild,
            "SUMMON_HERO": self.summon.summon_hero,
            "STONE_SUMMON_HERO": self.summon.stone_summon_hero,
            "SUMMON_SUPER_HERO": self.summon.summon_super_hero,
            "SUPER_HERO_STONE_EXCHANGE": self.summon.super_hero_stone_exchange,
            "MAGIC_SUMMON_BUY": self.summon.magic_summon,
            "MAGIC_SUMMON_SWITCH_HERO": self.summon.magic_summon_switch,
            "EDIT_PLAYER_NAME": self.system.edit_player_name,
            "GENERATE_PLAYER_NAME": self.system.generate_player_name,
            "SET_AVATAR_ID": self.system.set_avatar_id,
            "EDIT_AVATAR_RRAME": self.system.edit_avatar_frame,
            "GET_COMMENT_AWARD": self.system.get_comment_award,
            "GET_MAXLEVEL": self.system.get_maxlevel,
            "SEARCH_PLAYER": self.social.search_player,
            "LOAD_FRIEND_INFO": self.social.load_friend_info,
            "LOAD_GET_REQUEST_PLAYERS": self.social.load_get_request_players,
            "REQUEST_FRIEND": self.social.request_friend,
            "WORLD_BOSS": self.world.world_boss,
            "LOAD_MARCH": self.world.load_march,
            "LOAD_INVITE_INFOS": self.invite_infos,
            "GET_INVITE_AWARD": self.rewards.awards_empty,
            "GET_AUCTION_INFO_BY_TYPE": self.arena.get_auction_info_by_type,
            "GET_OFFLINE_INFO": self.rewards.get_offline_info,
            "GET_BUILDING_LIST": self.workshop.get_building_list,
            "UPGRADE_BUILDING": self.workshop.upgrade_building,
            "CANCEL_EVOLVE_BUILDING": self.workshop.cancel_evolve_building,
            "GET_CABINET_INFO": self.workshop.get_cabinet_info,
            "LEARN_SKILL": self.workshop.learn_skill,
            "GIVE_UP_LEARN_SKILL": self.workshop.give_up_learn_skill,
            "SPEED_UP_BUILDING": self.workshop.speed_up_building,
            "SPEED_UP_SKILL": self.workshop.speed_up_skill,
            "CABINET_SKILL_CONFIRM": self.workshop.cabinet_skill_confirm,
            "CONFIRM_BUILDING_UPGRADE": self.workshop.confirm_building_upgrade,
            "GET_TEA_TALK_INFO": self.rewards.get_tea_talk_info,
            "GET_CLASS_INFO": self.rewards.get_class_info,
            "APPLY_COURSE": self.courses.apply_course,
            "GET_COURSE_INFO": self.courses.get_course_info,
            "GET_STUDYROOM_INFO": self.courses.get_studyroom_info,
            "STUDY": self.courses.study,
            "SPEED_STUDY": self.courses.speed_study,
            "ADD_SKILL": self.courses.add_skill,
            "FORGET_COURSE": self.courses.forget_course,
            "ENTER_ROOM": self.courses.enter_room,
            "LEAVE_ROOM": self.courses.leave_room,
            "GET_STUDY_INFOS": self.courses.get_study_infos,
            "CANCEL_STUDY": self.courses.cancel_study,
            "GET_GIFT_BOX_INFO": self.courses.get_gift_box_info,
            "INCR_COURESE_EXP": self.courses.incr_course_exp,
            "OPEN_GIFT_BOX": self.courses.open_gift_box,
            "CONTINUE_STUDY": self.courses.continue_study,
            "GET_COURSES_RECOMMEND": self.courses.get_courses_recommend,
            "GET_ADVENTURE_LIST": self.world.get_adventure_list,
            "GET_HERO_RECOMMEND_SCORES": self.rewards.get_hero_recommend_scores,
            "BATTLE_PASS_GET_INFO": self.rewards.battle_pass_get_info,
            "HUNQI_START_GAME_GET_INFO": self.rewards.hunqi_start_game_get_info,
            "HUNQI_START_FIGHT": self.gods_trial.start_fight,
            "HUNQI_FIGHT_RESULT": self.gods_trial.fight_result,
            "HUNQI_GET_CAMPAIGN_INFO": self.gods_trial.get_campaign_info,
            "HUNQI_AUTO_FIGHT": self.gods_trial.start_auto,
            "HUNQI_GET_AUTO_AWRAD": self.gods_trial.collect_auto,
            "HUNQI_ENHANCE": self.horcrux.strengthen,
            "HUNQI_LOCK": self.horcrux.lock,
            "HUNQI_UNLOCK": self.horcrux.unlock,
            "HUNQI_EQUIP": self.horcrux.equip,
            "HUNQI_ONE_KEY_UNEQUIP": self.horcrux.one_key_unequip,
            "HUNQI_GET_COLLOCATION_INFOS": self.horcrux.get_collocation_infos,
            "HUNQI_SAVE_COLLOCATION": self.horcrux.save_collocation,
            "DEL_COLLOCATION": self.horcrux.delete_collocation,
            "APPLY_COLLOCATION": self.horcrux.apply_collocation,
            "SWEEP_CAMPAIGN": self.world.sweep_campaign,
            "GET_RENT_HEROS": self.world.get_rent_heros,
            "RESET_CAMPAIGN": self.world.reset_campaign,
            "GET_BONUS_AWARD": self.world.get_bonus_award,
            "FIGHT": self.world.fight,
            "GET_STORY_DROP_PARTNER": self.world.get_story_drop_partner,
            "FIGHT_RESULT": self.world.fight_result,
            # Pass211 Stage F: deliberately minimal Occult dependency for the 22
            # ordinary Awakening routes. Other Occult MIDs remain fenced.
            "GET_INFO": self.occult.get_info,
            "OCCULT_SWEEP": self.occult.sweep,
        }
        for name, handler in extra.items():
            self._put(h, name, handler)

        # Stage 3 domain foundation. These families are sourced from Pass 19's
        # domain rewrite gate and use domain-owned state rather than one-off call-site
        # stubs, so unidentified variants can be added without changing architecture.
        stage3 = {
            # practice: finite dynamic family resolved in Pass 19
            "GET_PRACTICE_INFO": self.practice.hero_info,
            "PRACTICE": self.practice.hero_mutation,
            "PRACTICE_SAVE": self.practice.hero_mutation,
            "PRACTICE_AUTO": self.practice.hero_mutation,
            "WASH_BY_TICKET": self.practice.hero_mutation,
            "PET_GET_PRACTICE_INFO": self.practice.pet_info,
            "PET_PRACTICE": self.practice.pet_mutation,
            "PET_PRACTICE_SAVE": self.practice.pet_mutation,
            "PET_PRACTICE_AUTO": self.practice.pet_mutation,
            "PET_WASH_BY_TICKET": self.practice.pet_mutation,
            "PET_USE_EXP_ITEMS": self.practice.pet_use_exp_items_fail_closed,

            # battle formation/session
            "LOAD_BATTLE_FORMATION": self.battle.load_formation,
            "SET_FORMATION": self.battle.set_formation,
            "ENTER_BATTLE": self.battle.enter_battle,
            "LOAD_FRIEND_REP_HEROS": self.battle.friend_rep_heros,
            "END_BATTLE": self.battle.end_battle,
            "BATTLE_REVIVE": self.battle.end_battle,

            # missions / tasks
            "LOAD_MISSION": self.tasks.load_mission,
            "COMPLETE_MISSION": self.tasks.mission_status,
            "OPEN_AWAKE_MISSION": self.tasks.awake_open,
            "GIVE_UP_AWAKE_MISSION": self.tasks.awake_give_up,
            "OPEN_PET_AWAKE_MISSION": self.tasks.mission_status,
            "GIVE_UP_PET_AWAKE_MISSION": self.tasks.mission_status,
            "OPEN_AWAKE_TWICE_MISSION": self.tasks.awake_open,
            "GIVE_UP_AWAKE_TWICE_MISSION": self.tasks.awake_give_up,
            "GET_DAY_HUOYUE_AWARD": self.tasks.huoyue_award,
            "GET_WEEK_HUOYUE_AWARD": self.tasks.huoyue_award,
            "GET_AWAKE_ITEM": self.tasks.awake_get_item,
            "TASK_AWAKE_GIVE_UP": self.tasks.awake_give_up,
            "TASK_AWAKE_OPEN": self.tasks.awake_open,
            "UNLIMIT_START_FIGHT": self.world.unlimited_start_fight,
            "UNLIMIT_FIGHT_RESULT": self.world.unlimited_fight_result,

            # social
            "DENY_FRIEND_REQUEST": self.social.social_status_only,
            "IGNORE_FRIEND_REQUEST": self.social.social_status_only,
            "ACCEPT_FRIEND_REQUEST": self.social.social_status_only,
            "DELETE_FRIEND": self.social.social_status_only,
            "ACCEPT_ALL_FRIEND_REQUEST": self.social.social_status_only,
            "READ_NOTICE": self.social.social_status_only,
            "ADD_BLACK_LIST": self.social.social_status_only,
            "REMOVE_BLACK_LIST": self.social.social_status_only,
            "CLEAR_BLACK_LIST": self.social.social_status_only,
            "GET_RECOMMEND_FRIENDS": self.social.get_recommend_friends,

            # arena core + Pass19 dynamic record/formation family
            "LOAD_ARENA": self.arena.load_arena,
            "LOAD_ARENA_PLAYER_LIST": self.arena.player_list,
            "ARENA_REFRESH": self.arena.refresh,
            "LOAD_ARENA_NPC_LIST": self.arena.player_list,
            "LOAD_ARENA_RANK": self.arena.rank,
            "LOAD_ARENA_DEFENSE": self.arena.defense,
            "SAVE_ARENA_DEFENSE": self.arena.save_defense,
            "START_FIGHT": self.arena.start_fight,
            "ARENA_BUY_TICKET": self.arena.buy_ticket,
            "ARENA_MODE_INFO": self.arena.mode_info,
            "ARENA_MODE_ENEMY_LIST": self.arena.mode_enemy_list,
            "ARENA_MODE_DEFENCE": self.arena.save_defense,
            "ARENA_MODE_FIGHT_PRE": self.arena.start_fight,
            "ARENA_MODE_FIGHT": self.arena.start_fight,
            "ARENA_MODE_BUY_TICKET": self.arena.buy_ticket,
            "ARENA_RESET_TIMER": self.arena.mode_info,
            "LOAD_ARENA_FIGHT_REPORT": self.arena.load_arena_fight_report,
            "query_arena_formation": self.arena.query_formation,
            "ARENA_GET_RCORD_PLAYER_INFO": self.arena.query_formation,
            "ARENA_PRE_FIGHT": self.arena.start_fight,
            "ARENA_MODE_QUERY_FORMATION": self.arena.query_formation,
            "ARENA_MODE_RESET_TIME": self.arena.mode_info,
            "ARENA_MODE_RECORD_DETAIL": self.arena.record_detail,
            "ARENA_MODE_RECORD_PLAYER_INFO": self.arena.query_formation,
            "ARENA_MODE_SCHEDULE": self.arena.mode_info,

            # world / march / boss
            "CHALLENGEINFO": self.world.challenge_info,
            "RESTART_MARCH": self.world.march_action,
            "MARCH_FIGHT_RESULT": self.world.march_action,
            "MARCH_OPEN_BOX": self.world.march_action,
            "MARCH_START_FIGHT": self.world.march_action,
            "MARCH_OPEN_EXTRA_CHEST": self.world.march_action,
            "MARCH_ADVANCE_SWEEP": self.world.march_action,
            "WORLD_BOSS_BUY_TIMES": self.world.world_boss_action,
            "WORLD_BOSS_START_FIGHT": self.world.world_boss_action,
            "WORLD_BOSS_FIGHT_RESULT": self.world.world_boss_action,
            "WORLD_BOSS_SWEEP": self.world.world_boss_action,

            # guild/team broad skeletons with exact fields consumed by SelfGuild
            "LOAD_ALL_TEAMS": self.guild.guild_list,
            "LOAD_TEAM_BY_ID": self.guild.team_data,
            "LOAD_APPLY_LIST_TEAM": self.guild.guild_list,
            "PLAYER_LOAD_APPLY_LIST_TEAM": self.guild.guild_list,
            "GET_DATA_TEAM": self.guild.team_data,
            "LOAD_DRINK_INFO": self.guild.load_drink_info,
            "BUY_DRINK": self.guild.drink_action,
            "DO_DRINK": self.guild.drink_action,
            "LOAD_SENT_HEROS": self.guild.load_sent_heros,
            "RENT_HERO": self.guild.rent_hero,
            "CANCEL_RENT_HERO": self.guild.rent_hero,
            "LOAD_GUILD_CAMPAIGN_LIST": self.guild.guild_campaign_list,
            "RESET_CHAPTER": self.guild.guild_campaign_list,
            "LOAD_GUILD_MAP": self.guild.guild_map,
            "LOAD_GUILD_AWARD_LIST": self.guild.guild_awards,
            "APPLY_REWARD": self.guild.guild_awards,
            "GUILD_CHAPTER_DAMAGE_RANK": self.guild.damage_rank,
            "GUILF_ALL_SERVER_DAMAGE_RANK": self.guild.all_server_damage_rank,
            "OPEN_CHAPTER": self.guild.guild_campaign_list,
            "LOAD_GUILD_MAP_DETAIL": self.guild.guild_map,
            "GUILD_FIGHT_PREPARE": self.guild.fight_prepare,
            "GUILD_DISTRIBUTE_RECORD": self.guild.distribute_record,
            "GUILD_RANK": self.guild.guild_list,
            "EXCHANGE_DRINK": self.guild.drink_action,
            "LOAD_RENT_PET": self.guild.rent_pets,
            "RENT_PET": self.guild.rent_pets,
            "CANCEL_RENT_PET": self.guild.rent_pets,
            "LOAD_CAN_RENT_PET_LIST": self.guild.rent_pets,

            # pets
            "PET_SUMMON": self.heroes.pet_action,
            "PET_CLEAN_CD": self.heroes.pet_action,
            "PET_EQUIP": self.heroes.pet_action,
            "PET_UPGRADE_SKILL": self.heroes.pet_action,
            "PET_ADVANCE": self.heroes.pet_action,
            "PET_EVOLVE": self.heroes.pet_action,
            "PET_FEED": self.heroes.pet_action,
            "PET_BUY_BOOK": self.heroes.pet_action,
            "PET_SET_SHOW": self.heroes.pet_action,
            "PET_ONE_KEY_UP": self.heroes.pet_action,
            "PET_UPGRADE_ALL_SKILL": self.heroes.pet_action,
            "PET_ONE_KEY_EQUIP": self.heroes.pet_action,
            "PET_CAMPAIGN_LOAD_INFO": self.heroes.pet_campaign_info,
            "PET_CAMPAIGN_SWEEP": self.heroes.pet_campaign_action,
            "PET_CAMPAIGN_RECORD_SWEEP_TIME": self.heroes.pet_campaign_action,
            "PET_CAMPAIGN_FIGHT": self.heroes.pet_campaign_action,
            "PET_CAMPAIGN_BATTLE_RESULT": self.heroes.pet_campaign_action,
            "PET_CAMPAIGN_RESTART": self.heroes.pet_campaign_action,
            "PET_CAMPAIGN_AWAKE_SWEEP": self.heroes.pet_campaign_action,
            "PET_CAMPAIGN_SWEEP_SUPER": self.heroes.pet_campaign_action,
            "PET_CAMPAIGN_BUY_SUPER": self.heroes.pet_campaign_action,
            "PET_CAMPAIGN_SAVE_SUPER": self.heroes.pet_campaign_action,
            "PET_CAMPAIGN_PRACTICE": self.heroes.pet_campaign_action,

            # market + battle pass
            "SHOP_MAGIC_UNLOCK": self.shop.load_magic_shop,
            "MARKET_GET_CART": self.shop.market_cart,
            "MARKET_ADD_TO_CART": self.shop.market_cart_mutation,
            "MARKET_CLEAR_CART": self.shop.market_cart_mutation,
            "MARKET_PAY_THE_BILL": self.shop.market_cart_mutation,
            "MARKET_DELETE_ITEM": self.shop.market_cart_mutation,
            "SKIN_SHOP_INFO": self.shop.skin_shop_info,
            "BUY_SHOP_MULTI": self.shop.buy_shop,
            "BATTLE_PASS_BUY_LEVEL": self.rewards.awards_empty,
            "BATTLE_PASS_BUY_LIMIT_PURCHASE": self.rewards.awards_empty,
            "BATTLE_PASS_GET_AWARD": self.rewards.awards_empty,
            "BATTLE_PASS_GET_MISSION_AWARD": self.rewards.awards_empty,
        }
        for name, handler in stage3.items():
            self._put(h, name, handler)

        # Status-only / safe acknowledgement commands seen during early boot,
        # first-entry popups, and zlib/form result paths. More semantic state
        # can be promoted later without changing router structure.
        status_only_names = [
            "READ_PIC_NOTICE",
            "SEND_OPERATION_LOG",
            "FUNCTION_CLICK",
            "READ_NOTICE",
            "DENY_FRIEND_REQUEST",
            "IGNORE_FRIEND_REQUEST",
            "ACCEPT_FRIEND_REQUEST",
            "DELETE_FRIEND",
            "ACCEPT_ALL_FRIEND_REQUEST",
            "SEND_SOCIAL_GIFT",
            "RECEIVE_SOCIAL",
            "ARENA_FIGHT_RESULT",
            "PEAK_START_FIGHT",
            "TREASURE_SAVE_BATTLE_RESULT",
            "REARENA_END_FIGHT",
            "REGION_FIGHT_RESULT",
            "CONQUER_SCHOOL_FIGHT_RESULT",
            "SAVE_FURNITURES",
            "HUNQI_GET_CAMPAIGN_INFO",
            "POWERUP_HERO",
            "EXPAND_HERO_SLOTS",
            "DISMISS_HERO",
            "UNLOCK_DYNAMIC_CARD",
            "SHOW_DYNAMIC_CARD",
        ]
        for name in status_only_names:
            mid = getattr(MID, name, -1)
            if mid != -1 and mid not in h:
                h[mid] = self.system.status_only

        return {mid: func for mid, func in h.items() if mid != -1}

    def album_partner_unlock(self, req: dict[str, Any]) -> dict[str, Any]:
        return self.state.get_white_album_service().claim_normal(req.get("partner_id"))

    def album_special_collect_info(self, req: dict[str, Any]) -> dict[str, Any]:
        return self.state.get_white_album_service().special_info()

    def album_special_collect_reward(self, req: dict[str, Any]) -> dict[str, Any]:
        return self.state.get_white_album_service().claim_special(req.get("id"))

    def red_point(self, req: dict[str, Any]) -> list[dict[str, Any]]:
        # MID2560 is a read-only snapshot of the supported derived families.
        return self.state.get_services().generic_redmarks.snapshot()

    def pet_campaign_red_point(self, req: dict[str, Any]) -> dict[str, Any]:
        return self.state.get_services().deferred_status.response(822)

    def invite_infos(self, req: dict[str, Any]) -> dict[str, Any]:
        return self.state.get_player().invite_payload()

    def _deliver_post_commit(self, pending: dict[str, list[object]]) -> None:
        """Best-effort external-intent delivery outside StateRepository scope.

        Wave E binds the realtime.transient topic to the typed publisher.
        Delivery failure must never convert a durable gameplay commit into an
        HTTP failure.
        """
        if not pending:
            return
        sink = self._post_commit_sink
        if sink is None:
            count = sum(len(values) for values in pending.values())
            print(f"[POSTCOMMIT] no sink configured; dropped {count} committed intent(s)")
            return
        for topic in sorted(pending):
            values = tuple(pending.get(topic) or ())
            if not values:
                continue
            try:
                sink(topic, values)
            except Exception as exc:
                print(f"[POSTCOMMIT] sink failure topic={topic!r} count={len(values)} error={exc}")

    def dispatch(self, req: dict[str, Any]) -> Any:
        # Stage 4A request scope keeps the human-editable JSON refresh and any
        # handler mutation/save on one coherent PlayerState snapshot. Wave A
        # strengthens the exit path: committed external intents are drained on
        # every scoped exit, then delivered only after StateRepository releases
        # its request-wide lock/thread-local binding.
        pending_post_commit: dict[str, list[object]] = {}
        try:
            with self.state.request_scope(req):
                try:
                    result = self._dispatch_scoped(req)
                finally:
                    services = self.state.current_services_or_none()
                    if services is not None:
                        drained = services.uow.drain_post_commit()
                        for topic, values in drained.items():
                            if values:
                                pending_post_commit.setdefault(topic, []).extend(values)
                    # PostgreSQL owns a durable outbox.  Stage committed domain
                    # intents while the outer ResourceTransaction is still open;
                    # legacy JSON returns False and keeps the historical sink.
                    if self.state.persist_post_commit(pending_post_commit):
                        pending_post_commit.clear()
        except IdentityError as exc:
            self._deliver_post_commit(pending_post_commit)
            return EngineTransportResult(
                body={
                    "error_code": 1,
                    "error_class": "auth",
                    "error_kind": str(exc.error_kind),
                    "error_msg": str(exc),
                },
                status_code=int(exc.status_code),
            )
        except (ReceiptReplayConflict, StateVersionConflict) as exc:
            self._deliver_post_commit(pending_post_commit)
            error_kind = (
                "RECEIPT_REPLAY_CONFLICT"
                if isinstance(exc, ReceiptReplayConflict)
                else "STATE_VERSION_CONFLICT"
            )
            return EngineTransportResult(
                body={
                    "error_code": 1,
                    "error_class": "concurrency",
                    "error_kind": error_kind,
                    "error_msg": "Concurrent request conflict; retry with the same logical operation identity",
                },
                status_code=409,
            )
        except TransactionRetryExhausted:
            self._deliver_post_commit(pending_post_commit)
            return EngineTransportResult(
                body={
                    "error_code": 1,
                    "error_class": "concurrency",
                    "error_kind": "TRANSACTION_RETRY_EXHAUSTED",
                    "error_msg": "Database transaction could not settle; retry later",
                },
                status_code=503,
            )
        except BaseException as exc:
            # request_scope has already exited here. Preserve the original HTTP
            # exception independently from best-effort committed intent delivery.
            self._deliver_post_commit(pending_post_commit)
            if is_retryable_transaction_error(exc):
                return EngineTransportResult(
                    body={
                        "error_code": 1,
                        "error_class": "concurrency",
                        "error_kind": "TRANSACTION_RETRY_REQUIRED",
                        "error_msg": "Database transaction was rolled back; retry with the same logical operation identity",
                    },
                    status_code=503,
                )
            raise
        self._deliver_post_commit(pending_post_commit)
        return result

    def _dispatch_scoped(self, req: dict[str, Any]) -> Any:
        try:
            req_mid = int(req.get("mid", 0))
        except Exception:
            # Pass340 I1 default-deny applies even before MID classification.
            # Pre-I1 compatibility success here would let malformed/unknown
            # engine ingress bypass the explicit scope registry.
            auth_block = self.auth_perimeter.authorize(None, self.state).transport_result()
            assert auth_block is not None
            self.runtime_logger.request(
                mid=0, name="INVALID_MID", route=RouteClass.UNKNOWN.value, req=req,
                handler="auth_perimeter", response=auth_block.body, fallback=False,
            )
            print(f"[ENGINE AUTH BLOCK] nonnumeric mid request={redact(req)!r}")
            return auth_block

        route_class = classify_mid(req_mid)
        name = self.protocol_registry.label(req_mid)
        print(
            f"[ENGINE IN] mid={name} ({req_mid}) route={route_class.value} "
            f"data={json.dumps(redact(req), ensure_ascii=False, default=str)}"
        )

        # Pass340 I1: every engine HTTP request has an explicit authentication
        # scope.  Unknown routes are default-deny; known non-bootstrap routes are
        # selected-player scoped.  This check runs after the legacy request binder
        # resolved its temporary JSON credential, but before mutation/firewall,
        # projection, fallback or handler code can observe/mutate player state.
        known_engine_mid = (
            req_mid in self.handlers
            or self.compat.is_safe_fallback_mid(req_mid)
            or self.protocol_registry.record(req_mid) is not None
        )
        auth_scope = self.auth_scope_registry.resolve(
            req_mid, known_engine_mid=known_engine_mid
        )
        auth_decision = self.auth_perimeter.authorize(auth_scope, self.state)
        auth_block = auth_decision.transport_result()
        if auth_block is not None:
            self.runtime_logger.request(
                mid=req_mid, name=name, route=route_class.value, req=req,
                handler="auth_perimeter", response=auth_block.body, fallback=False,
            )
            print(
                f"[ENGINE AUTH BLOCK] status={auth_block.status_code} "
                f"scope={auth_scope.value if auth_scope else 'UNCLASSIFIED'} "
                f"{json.dumps(auth_block.body, ensure_ascii=False, separators=(',', ':'))}"
            )
            return auth_block

        # Pass105 Firewall Phase 2: source-audited non-session mutations plus
        # unsupported session preflight/start commands that do not yet have
        # durable backend/session ownership are blocked before *any* handler,
        # projector, or UoW path can run. Backend.lua derives xyd.error from
        # HTTP status, so this transport-aware result must remain non-200.
        blocked = self.mutation_firewall.evaluate(req_mid, name)
        if blocked is not None:
            self.runtime_logger.request(
                mid=req_mid, name=name, route=route_class.value, req=req,
                handler="mutation_safety_firewall", response=blocked.body, fallback=False,
            )
            print(f"[ENGINE BLOCK] status={blocked.status_code} {json.dumps(blocked.body, ensure_ascii=False, separators=(',', ':'))}")
            return blocked

        # Pass79 lazy source-day materialization happens before the response
        # snapshot and endpoint logic for requests whose canonical player is
        # already bound. Pass83 keeps MID1 as the deliberate exception: MID1 is
        # account-scoped here, then BootstrapHandlers evaluates the reset
        # immediately after resolve_or_create_player() binds the game player.
        # Only a source-compatible 05:00 trigger that actually materializes the
        # rollover receives the one-shot daily_updates projection.
        daily_reset = self.state.evaluate_daily_reset(req_mid)

        projector = ResponseProjector.capture(
            self.state.current_player_or_none(),
            resource_registry=self.resource_registry,
        )
        profile = self.projection_profiles.resolve(
            mid=req_mid,
            label=name,
            transport=self.protocol_registry.plane(req_mid) or route_class.value,
        )

        handler = self.handlers.get(req_mid)
        fallback_used = handler is None
        if fallback_used:
            if self.compat.is_safe_fallback_mid(req_mid):
                result = self.compat.fallback(req)
                handler_name = "compat.safe_fallback"
            else:
                result = self.compat.blocked(req)
                handler_name = "compat.blocked_unknown"
                blocked_unknown = EngineTransportResult(body=result, status_code=409)
                self.runtime_logger.request(
                    mid=req_mid, name=name, route=route_class.value, req=req,
                    handler=handler_name, response=result, fallback=True,
                )
                print(f"[ENGINE BLOCK] status=409 {json.dumps(result, ensure_ascii=False, separators=(',', ':'))}")
                return blocked_unknown
        else:
            result = handler(req)
            handler_name = getattr(handler, "__qualname__", repr(handler))

        # Domain handlers may fail closed with transport-aware non-200 results.
        # Backend.lua derives callback success/failure from HTTP status, so never
        # run a logical mutation failure through the normal HTTP-200 projector.
        if isinstance(result, EngineTransportResult):
            self.runtime_logger.request(
                mid=req_mid, name=name, route=route_class.value, req=req,
                handler=handler_name, response=result.body, fallback=fallback_used,
            )
            print(f"[ENGINE DOMAIN BLOCK] status={result.status_code} {json.dumps(result.body, ensure_ascii=False, separators=(',', ':'))}")
            return result

        services = self.state.current_services_or_none()
        committed_journal = []
        if services is not None:
            # Explicit semantic channels remain the compatibility bridge for
            # unmigrated owners. Typed journal projection runs afterwards and
            # wins on collision because it represents committed canonical state.
            result = services.apply_semantic_deltas(result, profile=profile)
            committed_journal = services.uow.consume_journal()
        result = projector.project(
            result,
            self.state.current_player_or_none(),
            committed_journal=committed_journal,
            profile=profile,
        )
        result = merge_daily_reset_projection(
            result, daily_reset.projection if daily_reset is not None else None
        )

        # Pass248 I6: structured Emblem runtime evidence for I7 without adding
        # internal policy/proposal state to the stock wire response.
        if services is not None and 1400 <= req_mid <= 1407:
            self.runtime_logger.emblem_event(
                mid=req_mid, name=name, response=result,
                snapshot=services.emblem.runtime_audit_snapshot(),
            )

        self.runtime_logger.request(
            mid=req_mid,
            name=name,
            route=route_class.value,
            req=req,
            handler=handler_name,
            response=result,
            fallback=fallback_used,
        )

        if req_mid in self.scalar_handlers:
            print(f"[ENGINE OUT] scalar={result!r}")
            return result

        response = engine_ok(result)
        if route_class == RouteClass.ENGINE_ZLIB_FORM and int(response.get("error_code", 0)) == 0:
            # Keep known/safe battle-result acknowledgements minimal but successful.
            response.setdefault("result", 1)
        print(f"[ENGINE OUT] {json.dumps(response, ensure_ascii=False, separators=(',', ':'), default=str)}")
        return response
