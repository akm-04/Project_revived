"""Domain-owned MID handlers."""
