"""Runtime entry point for the modular backend."""

from __future__ import annotations

import threading
import time

from gxb_backend.app_factory import create_app
from gxb_backend.config import SETTINGS
from gxb_backend.updates.local_update import load_manifest, registry_summary, prime_release_integrity_cache
from gxb_backend.version import ARTIFACT_VERSION


def _run_flask(app, port: int) -> None:
    app.run(
        host=SETTINGS.bind_host,
        port=port,
        debug=False,
        threaded=True,
        use_reloader=False,
    )


def main() -> None:
    # Pass298: maintain the two update lanes before accepting clients. Import the
    # root operator controller lazily so the runtime package has one build logic.
    if SETTINGS.auto_update_ensure:
        try:
            import update_controller
            result = update_controller.ensure_auto_releases(policy_path=SETTINGS.local_update_policy_path)
            print(f"[UPDATE-AUTO] ensure actions={result.get('actions', [])}")
        except Exception as exc:
            # Asset/update deployment is deliberately non-fatal to gameplay server
            # startup. The MID2 scheduler still fails closed around missing barriers.
            print(f"[UPDATE-AUTO][WARN] ensure failed: {exc}")
    integrity = prime_release_integrity_cache(SETTINGS)
    print(f"[UPDATE] startup release integrity verified={integrity['verified']} failed={integrity['failed']}")
    app = create_app(SETTINGS)
    print("==================================================")
    print(f" GXB modular {ARTIFACT_VERSION}")
    print(f" SDK bind    : http://{SETTINGS.bind_host}:{SETTINGS.sdk_port}")
    print(f" ENGINE bind : http://{SETTINGS.bind_host}:{SETTINGS.engine_port}")
    print(f" ADVERTISE_HOST = {SETTINGS.advertise_host}")
    print(f" SELF_URL = {SETTINGS.self_url}")
    print(f" CHAT advertised = {SETTINGS.chat_host}:{SETTINGS.chat_port}")
    print(f" BOOT_DETAIL_MODE = {SETTINGS.bootstrap_detail_mode}")
    print(f" FUNC_MODE = {SETTINGS.func_mode}")
    print(f" PROFILE = {SETTINGS.profile}")
    print(f" LEGACY_SANDBOX_DB = {SETTINGS.player_db_path}")
    print(f" MULTIUSER_ROOT = {SETTINGS.multiuser_root}")
    print(f" CLIENT_LOG_URL = {SETTINGS.client_log_url}")
    print(f" RESOURCE_GATEWAY = {SETTINGS.resource_gateway_enabled}")
    print(f" RES_DOWNLOAD_URL = {SETTINGS.res_download_url if SETTINGS.resource_gateway_enabled else '(disabled)'}")
    print(f" RESOURCE_CATALOG = {SETTINGS.resource_catalog_path}")
    print(f" ASSET_ROOT_MODE = {SETTINGS.asset_root_mode}")
    print(f" ASSET_SEARCH_ROOTS = {', '.join(str(p) for p in SETTINGS.asset_roots)}")
    print(f" ASSET_DISCOVERY_DEPTH = {SETTINGS.asset_discovery_depth}")
    print(f" RESOURCE_MD5_VERIFY = {SETTINGS.resource_verify_md5}")
    print(f" LEGACY_FALLBACK = {SETTINGS.legacy_fallback_enabled}")
    print(f" LEGACY_ALLOWLIST = {SETTINGS.legacy_fallback_allowlist_path}")
    print(f" LEGACY_OLD_RES = {SETTINGS.legacy_asset_root}")
    update_manifest = load_manifest(SETTINGS)
    print(f" LOCAL_UPDATE_MANIFEST = {SETTINGS.local_update_manifest_path}")
    print(f" LOCAL_UPDATE_REGISTRY = {SETTINGS.local_update_release_registry_path}")
    print(f" LOCAL_UPDATE_POLICY = {SETTINGS.local_update_policy_path} auto_ensure={SETTINGS.auto_update_ensure}")
    print(f" PROTOCOL_REGISTRY = {SETTINGS.protocol_registry_path}")
    update_summary = registry_summary(SETTINGS)
    if update_manifest is None:
        print(" LOCAL_UPDATE = no published release")
    else:
        print(
            f" LOCAL_UPDATE = latest_published={update_manifest['version']} "
            f"type={update_manifest.get('release_type')} volumes={update_manifest['volume']} silent={update_manifest['silent']}"
        )
    print(f" UPDATE_REGISTRY = tracks={update_summary['tracks']} published={update_summary['published']} candidates={update_summary['candidates']}")
    print("==================================================")

    realtime_runtime = app.extensions.get("gxb_realtime_runtime")
    if SETTINGS.enable_realtime_server and realtime_runtime is not None:
        realtime_runtime.start()

    t_sdk = threading.Thread(target=_run_flask, args=(app, SETTINGS.sdk_port), daemon=True, name="gxb-sdk-http")
    t_engine = threading.Thread(target=_run_flask, args=(app, SETTINGS.engine_port), daemon=True, name="gxb-engine-http")
    t_sdk.start()
    t_engine.start()

    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        print("\nStopping GXB backend.")
    finally:
        if realtime_runtime is not None:
            realtime_runtime.stop()


if __name__ == "__main__":
    main()
