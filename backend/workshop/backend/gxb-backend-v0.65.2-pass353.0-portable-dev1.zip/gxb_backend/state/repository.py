"""Request-scoped canonical state repository for the v0.8.0 multi-user backend."""

from __future__ import annotations

import threading
from contextlib import contextmanager
from pathlib import Path
from typing import Any

from gxb_backend.content import GameDataCatalog
from gxb_backend.content.summon_featured_catalog import SummonFeaturedCatalog
from gxb_backend.synchronization import SynchronizationCatalogs
from gxb_backend.auth.perimeter import AuthScopeRegistry
from gxb_backend.realtime.contracts import AuthenticatedPlayerIdentity

from .account import AccountIdentity
from .economy_repository import EconomyRepository
from .function_state_repository import FunctionStateRepository
from .hero_progression_repository import HeroProgressionRepository
from .hero_equipment_repository import HeroEquipmentRepository
from .hero_repository import HeroRepository
from .inventory_repository import InventoryRepository
from .mission_repository import MissionRepository
from .multiuser_database import (
    MultiUserDatabase,
    SANDBOX_SID,
    SANDBOX_TOKEN,
    SANDBOX_UID,
)
from .player_state import PlayerState
from .summon_repository import SummonRepository
from .world_repository import WorldRepository
from .request_services import RequestServices, RequestServiceImmutableCatalogs
from .summon_featured_rotation import SummonFeaturedRotationPolicy
from .server_clock import ServerClock, ServerDayClock
from .daily_reset import (
    DailyResetCoordinator,
    DailyResetOutcome,
    build_default_daily_reset_registry,
)
from .unit_of_work import UnitOfWork
from gxb_backend.persistence.store import LegacyJsonPlayerStateStore, PlayerStateStore


class _RequestBinding(threading.local):
    account: AccountIdentity | None = None
    session: dict[str, Any] | None = None
    player: PlayerState | None = None
    is_new_player: bool = False
    services: RequestServices | None = None


class StateRepository:
    """Own SDK identity + request-selected game player state.

    Existing gameplay handlers keep using ``get_player()`` and the domain
    repositories.  v0.8.0 changes what those calls mean: they resolve against a
    request-local authenticated player instead of one process-wide singleton.
    """

    def __init__(
        self,
        path: Path | None = None,
        profile: str = "established",
        legacy_path: Path | None = None,
        multiuser_root: Path | None = None,
        server_clock: ServerClock | None = None,
        player_state_store: PlayerStateStore | None = None,
    ) -> None:
        self._initialize_common(
            path=path,
            profile=profile,
            legacy_path=legacy_path,
            server_clock=server_clock,
        )
        root = Path(multiuser_root or ((self.path.parent if self.path else Path("data")) / "server_state"))
        self.store = MultiUserDatabase(
            root, self._data_dir(), featured_rotation=self._featured_rotation
        )
        # Pass343 I4 strangler seam. The default remains the mature JSON store;
        # PostgreSQL stores must be explicitly injected and transaction-bound.
        self._player_store: PlayerStateStore = player_state_store or LegacyJsonPlayerStateStore(self.store)
        self._player_working_set: dict[str, PlayerState] = {}
        self._player_fingerprints: dict[str, object | None] = {}
        self._sandbox_player_id: str | None = None

        with self._lock:
            sandbox_player = self.store.import_legacy_sandbox(
                self.path,
                profile=self.profile,
                legacy_state_path=self.legacy_path,
            )
            sandbox_session = self.store.ensure_sandbox_session()
            self._cache_player(sandbox_player)
            self._sandbox_player_id = str(sandbox_player.player_id)
            self._bind_session(sandbox_session)
            self._local.player = sandbox_player
            self._local.is_new_player = False

    def _initialize_common(
        self,
        *,
        path: Path | None,
        profile: str,
        legacy_path: Path | None,
        server_clock: ServerClock | None,
    ) -> None:
        """Initialize the mature domain graph without choosing persistence.

        I8 uses this seam to construct the PostgreSQL authority without ever
        constructing the legacy MultiUserDatabase.  The legacy constructor
        continues below unchanged in behaviour.
        """
        self.path = Path(path) if path else None  # v0.7 singleton migration source
        self.legacy_path = Path(legacy_path) if legacy_path else None
        self.profile = profile
        self._lock = threading.RLock()
        self._local = _RequestBinding()
        self.server_clock = server_clock or ServerClock()
        self.server_day_clock = ServerDayClock(self.server_clock)
        # Immutable source/config meaning is shared across request service graphs.
        self._catalog = GameDataCatalog.load(self._data_dir() / "game_data_catalog.json")
        self._featured_catalog = SummonFeaturedCatalog(self._data_dir())
        self._featured_rotation = SummonFeaturedRotationPolicy(
            self._data_dir(), self._featured_catalog, emit_startup_log=True
        )
        # U4B Wave A: immutable synchronization metadata is startup-fatal and
        # loaded once. It owns no player state and enables no new wire behavior.
        self._synchronization_catalogs = SynchronizationCatalogs.load(self._data_dir())
        # Pass281 bounded performance reconciliation: immutable source/config
        # catalogs are app-scoped. Player/UoW/services remain request-scoped.
        self._immutable_request_catalogs = RequestServiceImmutableCatalogs.load(
            self._data_dir(), game_data=self._catalog, featured_catalog=self._featured_catalog
        )
        self._daily_reset_registry = build_default_daily_reset_registry(self._data_dir())

    def _player_disk_fingerprint(self, player_id: Any) -> object | None:
        # Historical method name retained for compatibility. The default JSON
        # adapter returns the same (mtime_ns,size) token; relational stores are
        # deliberately non-cacheable across ResourceTransaction boundaries.
        return self._player_store.fingerprint(str(player_id))

    def _cache_player(self, player: PlayerState) -> PlayerState:
        key = str(player.player_id)
        self._player_working_set[key] = player
        self._player_fingerprints[key] = self._player_disk_fingerprint(key)
        return player

    def _save_player_canonical(self, player: PlayerState) -> None:
        self._player_store.save(player)
        self._cache_player(player)

    def _load_player_canonical(self, player_id: Any) -> PlayerState | None:
        key = str(player_id)
        cached = self._player_working_set.get(key)
        if cached is not None and bool(getattr(self._player_store, "process_cache_safe", False)):
            # Preserve historical next-request visibility of out-of-band JSON
            # edits without rebuilding PlayerState on every request. Relational
            # stores bypass this process cache so each outer transaction locks/
            # hydrates the canonical row afresh.
            if self._player_disk_fingerprint(key) == self._player_fingerprints.get(key):
                return cached
        loaded = self._player_store.load(key)
        if loaded is not None:
            self._cache_player(loaded)
        return loaded

    def _reload_player_from_disk(self, player_id: Any) -> PlayerState | None:
        # Historical name retained: I4 redirects this explicit refresh boundary
        # through the selected PlayerStateStore.
        key = str(player_id)
        loaded = self._player_store.load(key)
        if loaded is None:
            self._player_working_set.pop(key, None)
            self._player_fingerprints.pop(key, None)
            return None
        return self._cache_player(loaded)

    def _sandbox_player_canonical(self) -> PlayerState:
        if self._sandbox_player_id is not None:
            cached = self._load_player_canonical(self._sandbox_player_id)
            if cached is not None:
                return cached
        player = self.store.sandbox_player()
        self._cache_player(player)
        self._sandbox_player_id = str(player.player_id)
        return player

    # ------------------------------------------------------------------
    # Request binding
    # ------------------------------------------------------------------
    def _data_dir(self) -> Path:
        if self.path:
            return self.path.parent
        return Path("data")

    def _clear_binding(self) -> None:
        self._local.account = None
        self._local.session = None
        self._local.player = None
        self._local.is_new_player = False
        self._local.services = None

    def _bind_session(self, session: dict[str, Any] | None) -> None:
        self._local.session = session
        self._local.account = self.store.identity_from_session(session) if session else None

    def _resolve_engine_session(self, req: dict[str, Any]) -> dict[str, Any] | None:
        """Resolve only the credential class admitted by the current MID scope.

        Pass340 I1 keeps Pass299 JSON sessions as a temporary resolver, but no
        longer lets the client-wide generic ``token`` widen MID18/MID1 account
        authentication or lets ``sid/login_token`` authenticate ordinary gameplay.
        The PostgreSQL context-bound credential authority still belongs to I3.
        """
        try:
            mid = int(req.get("mid", 0) or 0)
        except (TypeError, ValueError):
            mid = 0

        if mid in AuthScopeRegistry.PUBLIC_MIDS:
            # Explicit PUBLIC_BOOTSTRAP routes never acquire actor identity from
            # opportunistically supplied credentials.
            return None
        if mid in {1, 18}:
            sid = req.get("sid")
            token = req.get("login_token")
        else:
            sid = None
            token = req.get("token")

        session = self.store.resolve_session(
            sid=str(sid) if sid else None,
            token=str(token) if token else None,
        )
        # SANDBOX_SID/SANDBOX_TOKEN are explicit known compatibility
        # credentials, not an arbitrary-invalid-token fallback.
        if session is None and (sid == SANDBOX_SID or token == SANDBOX_TOKEN):
            session = self.store.ensure_sandbox_session()
        return session

    def _bind_engine_request(self, req: dict[str, Any] | None) -> None:
        self._clear_binding()
        if not isinstance(req, dict):
            return
        session = self._resolve_engine_session(req)
        if session is None:
            return
        self._bind_session(session)

        uid = str(session.get("uid", ""))
        try:
            region = int(req.get("region", 0) or 0)
        except (TypeError, ValueError):
            region = 0

        # MID18 and MID1 intentionally run with account/session context before
        # a game player is selected/created. Other authenticated requests carry
        # region and should bind that account's existing character.
        try:
            mid = int(req.get("mid", 0) or 0)
        except (TypeError, ValueError):
            mid = 0
        if mid in {1, 18}:
            return

        # Pass340 I1 temporary selected-context seam: never let caller ``region``
        # choose an actor for ordinary gameplay. MID1 records the selected player
        # on the still-canonical legacy session; later requests resolve that exact
        # player and use any supplied region only as a consistency fence. I3
        # replaces this JSON binding with rotated context credentials/rows.
        selected_player_id = str(session.get("selected_player_id", "") or "")
        try:
            selected_region = int(session.get("selected_region", 0) or 0)
        except (TypeError, ValueError):
            selected_region = 0
        if not selected_player_id or selected_region <= 0:
            return
        if region > 0 and region != selected_region:
            return

        player = self._load_player_canonical(selected_player_id)
        if player is None or int(player.region) != selected_region:
            return
        account_uid = str(getattr(player, "account_uid", "") or "")
        if uid != SANDBOX_UID and account_uid and account_uid != uid:
            return
        self._local.player = player

    @contextmanager
    def request_scope(self, req: dict[str, Any] | None = None):
        """Serialize a request and bind the correct authenticated player."""
        with self._lock:
            previous = (
                getattr(self._local, "account", None),
                getattr(self._local, "session", None),
                getattr(self._local, "player", None),
                getattr(self._local, "is_new_player", False),
                getattr(self._local, "services", None),
            )
            self._bind_engine_request(req)
            try:
                yield
            finally:
                self._local.account, self._local.session, self._local.player, self._local.is_new_player, self._local.services = previous

    def refresh(self) -> None:
        """Reload the currently bound player from disk."""
        with self._lock:
            player = getattr(self._local, "player", None)
            if player is not None:
                loaded = self._reload_player_from_disk(str(player.player_id))
                if loaded is not None:
                    self._local.player = loaded
                    self._local.services = None

    # ------------------------------------------------------------------
    # SDK account/session service
    # ------------------------------------------------------------------
    def sdk_anonymous_identity(self, *, device: dict[str, Any] | None = None) -> AccountIdentity:
        with self._lock:
            self.store.ensure_sandbox_account()
            session = self.store.ensure_sandbox_session()
            return self.store.identity_from_session(session)

    def sdk_identity_from_sid(self, sid: str | None) -> AccountIdentity | None:
        with self._lock:
            if not sid:
                return None
            session = self.store.resolve_session(sid=str(sid))
            return self.store.identity_from_session(session) if session else None

    def resolve_realtime_identity(self, token: str, region: int) -> AuthenticatedPlayerIdentity | None:
        """Resolve a TCP login through canonical session/player indexes.

        This deliberately does not touch ``_local`` request bindings or build a
        ``RequestServices`` graph.  The repository lock is held only while the
        durable session/account/player identity is resolved; callers receive an
        immutable snapshot and must release this method before acquiring any
        realtime-session lock.
        """
        try:
            token_s = str(token)
            region_i = int(region)
        except (TypeError, ValueError):
            return None
        if not token_s or region_i <= 0:
            return None

        with self._lock:
            session = self.store.resolve_session(token=token_s)
            if session is None and token_s == SANDBOX_TOKEN:
                session = self.store.ensure_sandbox_session()
            if session is None:
                return None

            uid = str(session.get("uid", ""))
            selected_player_id = str(session.get("selected_player_id", "") or "")
            try:
                selected_region = int(session.get("selected_region", 0) or 0)
            except (TypeError, ValueError):
                selected_region = 0
            if not uid or not selected_player_id or selected_region <= 0:
                return None
            # Region is an admission assertion only; it never selects an account's
            # player. This closes stale/current-token + old-region mixtures in I1.
            if region_i != selected_region:
                return None
            player = self._load_player_canonical(selected_player_id)
            if player is None or int(player.region) != selected_region:
                return None
            account_uid = str(getattr(player, "account_uid", "") or "")
            if uid != SANDBOX_UID and account_uid and account_uid != uid:
                return None

            return AuthenticatedPlayerIdentity(
                uid=uid,
                sid=str(session.get("sid", "")),
                player_id=str(player.player_id),
                region=region_i,
                guild_id=int(player.guild_id or 0),
            )

    def current_realtime_identity(self) -> AuthenticatedPlayerIdentity | None:
        """Snapshot the already-authenticated HTTP-bound player for MID192.

        This is deliberately request-scoped and read-only. It does not resolve a
        second session, does not create a player, and is used only so HTTP room
        discovery applies the exact same room-admission policy as TCP_LOGIN.
        """
        with self._lock:
            session = getattr(self._local, "session", None)
            player = getattr(self._local, "player", None)
            if not isinstance(session, dict) or player is None:
                return None
            uid = str(session.get("uid", ""))
            sid = str(session.get("sid", ""))
            if not uid or not sid:
                return None
            account_uid = str(getattr(player, "account_uid", "") or "")
            if uid != SANDBOX_UID and account_uid and account_uid != uid:
                return None
            return AuthenticatedPlayerIdentity(
                uid=uid,
                sid=sid,
                player_id=str(player.player_id),
                region=int(player.region),
                guild_id=int(player.guild_id or 0),
            )

    def sdk_register(self, login: str, password: str) -> tuple[dict[str, Any] | None, str]:
        with self._lock:
            return self.store.register_account(login, password)

    def sdk_login(self, login: str, password: str, *, device: dict[str, Any] | None = None) -> AccountIdentity | None:
        with self._lock:
            account = self.store.verify_credentials(login, password)
            if account is None:
                return None
            session = self.store.issue_session(account, device=device)
            return self.store.identity_from_session(session)

    # ------------------------------------------------------------------
    # Account-region player lifecycle
    # ------------------------------------------------------------------
    def current_session(self) -> dict[str, Any] | None:
        return getattr(self._local, "session", None)

    def has_authenticated_session(self) -> bool:
        return getattr(self._local, "session", None) is not None and getattr(self._local, "account", None) is not None

    def current_uid(self) -> str:
        account = self.get_account()
        return str(account.uid)

    def list_account_players(self) -> list[PlayerState]:
        account = getattr(self._local, "account", None)
        if account is None:
            return []
        players: list[PlayerState] = []
        for player_id in self.store.account_player_ids(str(account.uid)):
            player = self._load_player_canonical(player_id)
            if player is not None:
                players.append(player)
        return players

    def region_player_count(self, region: int) -> int:
        return self.store.region_player_count(int(region))

    def resolve_or_create_player(self, region: int, region_name: str | None = None) -> tuple[PlayerState, bool]:
        """Resolve `(SDK uid, region)` or atomically create a fresh character."""
        session = getattr(self._local, "session", None)
        account = getattr(self._local, "account", None)
        if session is None or account is None:
            raise RuntimeError("MID1 player resolution requires an authenticated SDK session")

        uid = str(account.uid)
        region = int(region)
        region_name = str(region_name or self.region_name(region))

        if uid == SANDBOX_UID:
            player = self._sandbox_player_canonical()
            old_region = int(player.region)
            player.set_region(region)
            player.account_uid = SANDBOX_UID
            player.token = str(account.token)
            self._save_player_canonical(player)
            if old_region != region:
                self.store.move_account_region_player(SANDBOX_UID, old_region, region, str(player.player_id))
            self._local.player = player
            self._local.services = None
            self._local.is_new_player = False
            self.store.bind_session_context(session, player_id=str(player.player_id), region=int(player.region))
            return player, False

        player_id = self.store.player_id_for_account_region(uid, region)
        if player_id:
            player = self._load_player_canonical(player_id)
            if player is None:
                raise RuntimeError(f"player index points to missing player {player_id}")
            player.account_uid = uid
            self._local.player = player
            self._local.services = None
            self._local.is_new_player = False
            self.store.bind_session_context(session, player_id=str(player.player_id), region=int(player.region))
            return player, False

        player = self.store.create_fresh_player(uid=uid, region=region, region_name=region_name)
        self._cache_player(player)
        self._local.player = player
        self._local.services = None
        self._local.is_new_player = True
        self.store.bind_session_context(session, player_id=str(player.player_id), region=int(player.region))
        print(
            "[MULTIUSER] created player "
            f"uid={uid} region={region} player_id={player.player_id} name={player.player_name!r}"
        )
        return player, True

    @staticmethod
    def region_name(region: int) -> str:
        return "Deep Valley" if int(region) == 125 else f"Local-{int(region)}"

    # ------------------------------------------------------------------
    # Existing gameplay-facing repository interface
    # ------------------------------------------------------------------
    def get_account(self) -> AccountIdentity:
        account = getattr(self._local, "account", None)
        if account is not None:
            return account
        session = self.store.ensure_sandbox_session()
        return self.store.identity_from_session(session)

    def current_player_or_none(self) -> PlayerState | None:
        """Return only the request-bound player, without sandbox fallback.

        Response projection uses this to avoid diffing bootstrap/account-selection
        requests against the implicit AdminRoot sandbox.
        """
        return getattr(self._local, "player", None)

    def get_player(self) -> PlayerState:
        player = getattr(self._local, "player", None)
        if player is not None:
            return player
        # Public/pre-auth handlers historically assume a player object. Keep the
        # sandbox fallback, but authenticated credential mutations only bind an
        # actual player after MID1 has selected the account-region character.
        return self._sandbox_player_canonical()

    def get_player_by_id(self, player_id: Any) -> PlayerState | None:
        with self._lock:
            return self._load_player_canonical(str(player_id))

    def current_services_or_none(self) -> RequestServices | None:
        services = getattr(self._local, "services", None)
        player = getattr(self._local, "player", None)
        return services if services is not None and services.player is player else None

    @property
    def synchronization_catalogs(self) -> SynchronizationCatalogs:
        return self._synchronization_catalogs

    def get_services(self) -> RequestServices:
        player = getattr(self._local, "player", None)
        if player is None:
            raise RuntimeError("request-scoped services require a bound canonical player")
        services = getattr(self._local, "services", None)
        if services is None or services.player is not player:
            services = RequestServices(
                player,
                self._data_dir(),
                lambda: self._save_player_canonical(player),
                catalog=self._catalog,
                featured_rotation=self._featured_rotation,
                server_clock=self.server_clock,
                synchronization_catalogs=self._synchronization_catalogs,
                immutable_catalogs=self._immutable_request_catalogs,
            )
            self._local.services = services
        return services

    def save(self) -> None:
        with self._lock:
            player = getattr(self._local, "player", None)
            if player is None:
                return
            services = getattr(self._local, "services", None)
            if services is not None and services.player is player:
                services.uow.request_save()
            else:
                self._save_player_canonical(player)

    def persist_post_commit(self, pending: dict[str, list[object]]) -> bool:
        """Persistence-owned post-commit seam.

        Legacy JSON has no durable outbox and retains its existing best-effort
        sink.  The PostgreSQL runtime overrides this and stages intents before
        the outer ResourceTransaction commits.
        """
        del pending
        return False

    def evaluate_daily_reset(self, trigger_mid: int | None = None) -> DailyResetOutcome | None:
        """Materialize one bound player's source day before domain handling.

        This stays lightweight and independent from the full RequestServices
        graph so bootstrap/player-info requests do not load every gameplay
        catalog merely to enforce a day boundary. Participant failure rolls the
        whole reset back and is retried on the next request.
        """
        player = getattr(self._local, "player", None)
        if player is None:
            return None
        uow = UnitOfWork(player, lambda: self._save_player_canonical(player))
        coordinator = DailyResetCoordinator(
            player, uow, self.server_day_clock, self._daily_reset_registry
        )
        try:
            return coordinator.evaluate(trigger_mid)
        except Exception as exc:
            print(
                f"[DAILY_RESET] rollback/retry player={player.player_id} "
                f"mid={trigger_mid} error={exc}"
            )
            return None

    # Compatibility façades: callers keep their old repository accessors while
    # every accessor now resolves to the same memoized request service graph.
    def get_hero_repository(self) -> HeroRepository:
        return self.get_services().heroes

    def get_skin_ownership_service(self):
        return self.get_services().skin_ownership

    def get_inventory_repository(self) -> InventoryRepository:
        return self.get_services().inventory

    def get_summon_repository(self) -> SummonRepository:
        return self.get_services().summon

    def get_hero_progression_repository(self) -> HeroProgressionRepository:
        return self.get_services().hero_progression

    def get_hero_equipment_repository(self) -> HeroEquipmentRepository:
        return self.get_services().hero_equipment

    def get_hero_advanced_progression_repository(self):
        return self.get_services().hero_advanced

    def get_emblem_service(self):
        return self.get_services().emblem

    def get_white_album_service(self):
        return self.get_services().white_album

    def get_course_service(self):
        return self.get_services().courses

    def get_workshop_building_service(self):
        return self.get_services().workshop_buildings

    def get_cabinet_research_service(self):
        return self.get_services().cabinet_research

    def get_function_state_repository(self) -> FunctionStateRepository:
        return self.get_services().function_state

    def get_function_unlock_repository(self) -> FunctionStateRepository:
        return self.get_services().function_state

    def get_economy_repository(self) -> EconomyRepository:
        return self.get_services().economy

    def get_mission_repository(self) -> MissionRepository:
        return self.get_services().missions

    def get_awakening_mission_service(self):
        return self.get_services().awakening_missions

    def get_awakening_equipment_coordinator(self):
        return self.get_services().awakening_equipment

    def get_kongming_awake_skill_service(self):
        return self.get_services().kongming_awake_skills

    def get_world_repository(self) -> WorldRepository:
        return self.get_services().world

    def set_region(self, region: int) -> None:
        """Compatibility shim.

        Credential-player region is an ownership key and is not freely mutated.
        The sandbox retains the old behavior. If a credential account already
        owns the requested region, bind that player instead.
        """
        with self._lock:
            account = getattr(self._local, "account", None)
            if account is None or str(account.uid) == SANDBOX_UID:
                player = self.get_player()
                old_region = int(player.region)
                player.set_region(int(region))
                self._save_player_canonical(player)
                if old_region != int(region):
                    self.store.move_account_region_player(SANDBOX_UID, old_region, int(region), str(player.player_id))
                return
            player_id = self.store.player_id_for_account_region(str(account.uid), int(region))
            if player_id:
                player = self._load_player_canonical(player_id)
                if player is not None:
                    self._local.player = player
                    self._local.services = None
