"""Runtime observability helpers."""
