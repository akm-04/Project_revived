"""Chat compatibility helpers."""
